package engine;

import engine.strategy.BotStrategy;
import io.EnigmaLoader;
import io.EventConfigLoader;
import io.MapLoader;
import model.*;
import Lists.DoublyLinkedList;
import Lists.ListADT;

/**
 * Núcleo do Labirinto da Glória.
 *
 * <p>Suporta 1 a N jogadores. Com 1 jogador:</p>
 * <ul>
 *   <li>Combate PvP nunca ocorre</li>
 *   <li>A única condição de vitória é chegar ao objetivo</li>
 *   <li>{@link #nextTurn()} funciona correctamente (mod 1 = 0)</li>
 * </ul>
 *
 * <h2>Sistema de dificuldade ({@link GameDifficulty})</h2>
 * <p>A dificuldade é aplicada em todos os pontos de dano via
 * {@link #takeDamageWithDifficulty(Player, int)}. O multiplicador
 * ({@link GameDifficulty#damageMultiplier}) é aplicado antes de
 * chamar {@link Player#takeDamage(int)}.</p>
 *
 * <h2>Contador de respawns por jogador</h2>
 * <p>Cada jogador tem um contador de respawns ({@code "playerId"})
 * indexado numa {@link DoublyLinkedList}. Ao morrer:</p>
 * <ol>
 *   <li>O contador é incrementado.</li>
 *   <li>Se {@link GameDifficulty#canRespawn(int)} for {@code false}
 *       (HARDCORE ou limite atingido), o jogador é eliminado e o jogo
 *       pode terminar.</li>
 *   <li>Caso contrário, chama {@link Player#respawn()} e
 *       {@link #clearProgressOnRespawn(Player)}.</li>
 * </ol>
 *
 * <h2>Sistema de enigmas por dangerLevel</h2>
 * <p>O campo {@code enigmaId} foi removido das salas. Quando um jogador
 * entra numa sala com {@code dangerLevel >= 1}, o engine pede ao
 * {@link EnigmaPool} um enigma com o mesmo nível. O pool garante:
 * <ul>
 *   <li>Dois jogadores diferentes nunca respondem ao mesmo enigma na mesma sala</li>
 *   <li>Na mesma visita, o jogador recebe sempre o mesmo enigma</li>
 *   <li>Ao morrer, o histórico é limpo e pode receber enigma diferente</li>
 * </ul>
 * </p>
 *
 * <h2>Salas de Alavanca ({@link LeverRoom})</h2>
 * <p>Salas com {@code role == LEVER_ROOM} apresentam portas ao jogador.
 * O engine gera e armazena em cache um {@link LeverRoom} por sala.
 * O número de portas é determinado pelo {@code dangerLevel} da sala
 * (conforme {@code event_config.json}), não pela dificuldade.</p>
 *
 * <h2>Seleção dinâmica de evento por sala DUNGEON</h2>
 * <p>Salas com {@code role == DUNGEON} e {@code dangerLevel >= 1} recebem
 * um tipo de evento determinado em runtime pelo engine na primeira visita
 * de cada jogador, usando as probabilidades lidas de
 * {@code event_config.json} via {@link EventConfigLoader}:</p>
 * <ul>
 *   <li>dangerLevel == 1 → sempre {@link EventType#ENIGMA}</li>
 *   <li>dangerLevel >= 2 → {@code level_2_plus_enigma_chance} de
 *       {@link EventType#ENIGMA}, restante de {@link EventType#LEVER}</li>
 * </ul>
 * <p>O resultado é guardado no {@link LocationState} e reutilizado em
 * todas as revisitas do mesmo jogador.</p>
 *
 * <h2>Atalhos e Rapto ({@link ShortcutEdge})</h2>
 * <p>O {@link MapLoader} gera atalhos entre salas de nível 2 e nível 4.
 * Quando um {@link KidnapEvent} é activado, o jogador é teleportado
 * para uma localização aleatória com as probabilidades definidas em
 * {@code event_config.json} ({@code kidnap_near_chance} /
 * {@code kidnap_far_chance}).</p>
 */
public class GameEngine {

    // ── Constantes de dano ────────────────────────────────────────────

    /** Dano base por ponto de dangerLevel ao errar um enigma. */
    private static final int ENIGMA_FAIL_DAMAGE_PER_LEVEL = 8;

    /** Dano mínimo ao errar um enigma. */
    private static final int ENIGMA_FAIL_DAMAGE_MIN = 5;

    /**
     * Dano fixo (antes do multiplicador) ao visitar uma sala já visitada.
     */
    public static final int REVISIT_DAMAGE = 8;

    // ── Dependências ────────────────────────────────────────────────

    private final GameMap         map;
    private final Location        objective;
    private final CombatResolver  combatResolver;
    private final EnigmaResolver  enigmaResolver;
    private final EnigmaPool      enigmaPool;

    /** Nível de dificuldade atual da sessão. */
    private GameDifficulty        difficulty;

    /**
     * Configuração de eventos lida de {@code event_config.json}.
     *
     * <p>Substitui as antigas constantes {@code static final} hardcoded.
     * Os valores são carregados no construtor e imutáveis durante a sessão.</p>
     */
    private final EventConfigLoader eventConfig;

    /** Estados dinâmicos indexados por {@code "playerId:locationId"}. */
    private final DoublyLinkedList<LocationStateEntry> locationStates;

    private final DoublyLinkedList<Player> players;

    /** Contadores de respawns por jogador (chave: playerId). */
    private final DoublyLinkedList<RespawnEntry> respawnCounters;

    private int     currentPlayerIndex;
    private boolean running;
    private Player  winner;

    /**
     * Distância máxima entre quaisquer dois vértices do mapa.
     */
    private double maxMapDistance = 1.0;

    /** Gerador aleatório com seed para reprodutibilidade. */
    private final SimpleRandom rng;

    /**
     * Cache de lever rooms geradas, indexado por locationId.
     * Usa {@link KeyValueEntry} para evitar java.util.HashMap.
     */
    private final DoublyLinkedList<KeyValueEntry<String, LeverRoom>> leverRooms;

    /** Atalhos entre salas de nível 2 e nível 4 gerados pelo MapLoader. */
    private final DoublyLinkedList<ShortcutEdge> shortcuts;

    // ── Construtores ───────────────────────────────────────────────

    /**
     * Cria uma sessão de jogo com dificuldade específica.
     *
     * <p>Carrega o ficheiro {@code event_config.json} via
     * {@link EventConfigLoader}. Se o ficheiro não for encontrado,
     * os valores de fallback mantêm o comportamento anterior.</p>
     *
     * @param map         mapa do jogo
     * @param objective   localização objetivo
     * @param enigmasPath caminho para o ficheiro enigmas.json
     * @param difficulty  nível de dificuldade da sessão
     */
    public GameEngine(GameMap map, Location objective, String enigmasPath,
                      GameDifficulty difficulty) {
        this.map            = map;
        this.objective      = objective;
        this.difficulty     = (difficulty != null) ? difficulty : GameDifficulty.NORMAL;
        this.combatResolver = new CombatResolver();
        this.enigmaResolver = new EnigmaResolver();
        ListADT<Event> allEvents = EnigmaLoader.load(enigmasPath);
        this.enigmaPool     = new EnigmaPool(allEvents);
        this.eventConfig    = new EventConfigLoader();
        this.locationStates = new DoublyLinkedList<>();
        this.players        = new DoublyLinkedList<>();
        this.respawnCounters = new DoublyLinkedList<>();
        this.rng            = new SimpleRandom();
        this.leverRooms     = new DoublyLinkedList<>();
        this.shortcuts      = MapLoader.generateShortcuts(map, System.nanoTime());
        this.running        = false;
        this.winner         = null;
        this.currentPlayerIndex = 0;
    }

    /**
     * Cria uma sessão de jogo com dificuldade {@link GameDifficulty#NORMAL}.
     *
     * @param map         mapa do jogo
     * @param objective   localização objetivo
     * @param enigmasPath caminho para o ficheiro enigmas.json
     */
    public GameEngine(GameMap map, Location objective, String enigmasPath) {
        this(map, objective, enigmasPath, GameDifficulty.NORMAL);
    }

    // ── Setup ───────────────────────────────────────────────

    /**
     * Adiciona um jogador à sessão. Deve ser chamado antes de {@link #start()}.
     *
     * @param player jogador a adicionar
     */
    public void addPlayer(Player player) {
        players.addLast(player);
        respawnCounters.addLast(new RespawnEntry(player.getId()));
    }

    /**
     * Inicia o jogo. Requer pelo menos 1 jogador.
     *
     * @throws IllegalStateException se não houver jogadores
     */
    public void start() {
        if (players.isEmpty()) {
            throw new IllegalStateException("Não é possível iniciar sem jogadores.");
        }
        running = true;
        winner  = null;
        currentPlayerIndex = 0;

        for (Player p : players) {
            Location start = p.getCurrentLocation();
            if (start != null) {
                getOrCreateState(p, start.getId()).markVisited();
            }
        }

        maxMapDistance = computeMaxMapDistance();
    }

    // ── Dificuldade ───────────────────────────────────────────────

    /**
     * Devolve o nível de dificuldade da sessão.
     *
     * @return dificuldade atual
     */
    public GameDifficulty getDifficulty() { return difficulty; }

    /**
     * Altera a dificuldade (só deve ser chamado antes de {@link #start()}).
     *
     * @param difficulty nova dificuldade
     */
    public void setDifficulty(GameDifficulty difficulty) {
        this.difficulty = (difficulty != null) ? difficulty : GameDifficulty.NORMAL;
    }

    /**
     * Aplica dano ao jogador com o multiplicador da dificuldade atual.
     *
     * <p>O dano final é: {@code (int) Math.ceil(base * difficulty.damageMultiplier)}.
     * Garante que o dano mínimo é 1 para qualquer {@code baseDamage > 0}.</p>
     *
     * @param player     jogador a receber dano
     * @param baseDamage dano base antes do multiplicador
     */
    public void takeDamageWithDifficulty(Player player, int baseDamage) {
        int adjusted = difficulty.applyDamage(baseDamage);
        player.takeDamage(Math.max(1, adjusted));
    }

    // ── Respawns ───────────────────────────────────────────────

    /**
     * Devolve o número de respawns já usados por um jogador.
     *
     * @param player jogador a consultar
     * @return número de respawns consumidos
     */
    public int getRespawnsUsed(Player player) {
        for (RespawnEntry re : respawnCounters) {
            if (re.playerId.equals(player.getId())) return re.count;
        }
        return 0;
    }

    /**
     * Incrementa o contador de respawns do jogador.
     *
     * @param player jogador
     */
    private void incrementRespawnCount(Player player) {
        for (RespawnEntry re : respawnCounters) {
            if (re.playerId.equals(player.getId())) {
                re.count++;
                return;
            }
        }
        RespawnEntry re = new RespawnEntry(player.getId());
        re.count = 1;
        respawnCounters.addLast(re);
    }

    /**
     * Tenta efectuar o respawn de um jogador morto.
     *
     * <ul>
     *   <li>HARDCORE ou limite de respawns atingido → devolve {@code false}
     *       (game-over para este jogador)</li>
     *   <li>Caso contrário → incrementa contador, chama
     *       {@link Player#respawn()} e
     *       {@link #clearProgressOnRespawn(Player)}, devolve {@code true}</li>
     * </ul>
     *
     * @param player jogador morto
     * @return {@code true} se o respawn foi efectuado com sucesso
     */
    private boolean tryRespawn(Player player) {
        int used = getRespawnsUsed(player);
        if (!difficulty.canRespawn(used)) {
            running = false;
            return false;
        }
        incrementRespawnCount(player);
        player.respawn();
        clearProgressOnRespawn(player);
        return true;
    }

    // ── Multiplicador de proximidade ──────────────────────────────────

    /**
     * Calcula o multiplicador de perigo baseado na proximidade do jogador
     * ao objetivo.
     *
     * @param player jogador
     * @return multiplicador em [{@value CombatResolver#MULTIPLIER_MIN},
     *         {@value CombatResolver#MULTIPLIER_MAX}]
     */
    public double getProximityMultiplier(Player player) {
        Location pos = player.getCurrentLocation();
        if (pos == null || pos.equals(objective)) {
            return CombatResolver.MULTIPLIER_MAX;
        }

        double dist = map.shortestPathCost(pos, objective);
        if (Double.isInfinite(dist) || maxMapDistance <= 0) {
            return CombatResolver.MULTIPLIER_MIN;
        }

        double ratio     = Math.min(1.0, dist / maxMapDistance);
        double proximity = 1.0 - ratio;
        return CombatResolver.MULTIPLIER_MIN
                + proximity * (CombatResolver.MULTIPLIER_MAX - CombatResolver.MULTIPLIER_MIN);
    }

    private double computeMaxMapDistance() {
        ListADT<Location> all = map.getAllLocations();
        double max = 1.0;
        for (Location a : all) {
            for (Location b : all) {
                if (a.equals(b)) continue;
                double d = map.shortestPathCost(a, b);
                if (!Double.isInfinite(d) && d > max) {
                    max = d;
                }
            }
        }
        return max;
    }

    // ── Seleção de evento por sala DUNGEON ─────────────────────────────────

    /**
     * Determina o tipo de evento para uma sala DUNGEON com base no seu
     * {@code dangerLevel}, usando as probabilidades lidas de
     * {@code event_config.json} via {@link EventConfigLoader}.
     *
     * <ul>
     *   <li>dangerLevel == 1 → {@link EventType#ENIGMA} com
     *       {@code level_1_enigma_chance} (nominalmente 100%)</li>
     *   <li>dangerLevel >= 2 → {@link EventType#ENIGMA} com
     *       {@code level_2_plus_enigma_chance}, {@link EventType#LEVER}
     *       com {@code level_2_plus_lever_chance}</li>
     * </ul>
     *
     * <p>O resultado é guardado no {@link LocationState} passado como
     * argumento. Se o estado já tiver um tipo atribuído, devolve-o
     * imediatamente (garante determinismo por par jogador/sala).</p>
     *
     * @param dangerLevel nível de perigo da sala
     * @param state       estado da localização para este jogador
     * @return tipo de evento selecionado
     */
    private EventType pickRoomEventType(int dangerLevel, LocationState state) {
        if (state.getAssignedEventType() != null) {
            return state.getAssignedEventType();
        }
        EventType chosen;
        if (dangerLevel == 1) {
            chosen = (rng.nextDouble() < eventConfig.level1EnigmaChance)
                     ? EventType.ENIGMA
                     : EventType.LEVER;
        } else {
            chosen = (rng.nextDouble() < eventConfig.level2PlusEnigmaChance)
                     ? EventType.ENIGMA
                     : EventType.LEVER;
        }
        state.setAssignedEventType(chosen);
        return chosen;
    }

    // ── Movimento ───────────────────────────────────────────────

    /**
     * Tenta mover o jogador para um destino adjacente.
     *
     * <p>Pipeline:</p>
     * <ol>
     *   <li>Guarda imediata se o jogo já terminou</li>
     *   <li>Validações de pré-condição (adjacência)</li>
     *   <li>Deteção de atalho com evento — delega em
     *       {@link #resolveShortcutEvent} se o destino for atingível
     *       via {@link ShortcutEdge} com evento associado</li>
     *   <li>Lever Room estática (role == LEVER_ROOM) — regista posição e
     *       devolve as portas à UI</li>
     *   <li>Sala DUNGEON — seleciona evento em runtime via
     *       {@link #pickRoomEventType}:
     *       <ul>
     *         <li>LEVER → gera lever room dinâmica e devolve à UI</li>
     *         <li>ENIGMA → processa enigma pendente (lógica existente)</li>
     *       </ul>
     *   </li>
     *   <li>Dano de revisita — ajustado pela dificuldade</li>
     *   <li>Executa movimento e marca sala como visitada</li>
     *   <li>Combate PvP (só com 2+ jogadores na mesma sala)</li>
     *   <li>Verifica vitória</li>
     * </ol>
     *
     * @param player       jogador a mover
     * @param destination  destino
     * @param enigmaAnswer resposta ao enigma (pode ser {@code null})
     * @return resultado do movimento
     */
    public MoveResult moveTo(Player player, Location destination, String enigmaAnswer) {

        if (!running) {
            return MoveResult.blocked(MoveResult.BlockReason.GAME_OVER);
        }
        if (!map.areConnected(player.getCurrentLocation(), destination)) {
            return MoveResult.blocked(MoveResult.BlockReason.NOT_ADJACENT);
        }
        double cost = map.getDistance(player.getCurrentLocation(), destination);
        if (Double.isInfinite(cost)) {
            return MoveResult.blocked(MoveResult.BlockReason.NOT_ADJACENT);
        }

        // ── Atalho com evento ───────────────────────────────────────────────
        ShortcutEdge usedShortcut = findShortcut(player.getCurrentLocation(), destination);
        if (usedShortcut != null && usedShortcut.getEvent() != null) {
            return resolveShortcutEvent(player, destination, usedShortcut, enigmaAnswer);
        }

        LocationState destState = getOrCreateState(player, destination.getId());

        // ── Lever Room estática (role == LEVER_ROOM) ─────────────────────────
        if (destination.isLeverRoom()) {
            LeverRoom lr = getOrGenerateLeverRoom(destination);
            player.moveTo(destination);
            return MoveResult.withLeverRoom(destination, lr.getDoors());
        }

        // ── Sala DUNGEON: seleção dinâmica de evento ───────────────────────
        if (destination.getRole() == Location.LocationRole.DUNGEON
                && destination.getDangerLevel() >= 1) {

            EventType roomEvent = pickRoomEventType(destination.getDangerLevel(), destState);

            if (roomEvent == EventType.LEVER) {
                // Lever room dinâmica — mesmo fluxo que LEVER_ROOM estática
                LeverRoom lr = getOrGenerateLeverRoom(destination);
                player.moveTo(destination);
                return MoveResult.withLeverRoom(destination, lr.getDoors());
            }

            // roomEvent == ENIGMA → cai para a lógica de enigma abaixo
        }

        // ── Enigma pendente ───────────────────────────────────────────────
        if (destination.hasEnigmaByLevel() && !destState.isEnigmaResolved()) {
            Enigma enigma = enigmaPool.pickFor(player, destination.getId(),
                                               destination.getDangerLevel());
            if (enigma != null) {
                EnigmaResolver.EnigmaResult enigmaResult =
                    enigmaResolver.resolve(enigma, enigmaAnswer);

                if (enigmaResult.isCorrect()) {
                    destState.resolveEnigma();
                } else {
                    int baseEnigmaDamage = Math.max(
                        ENIGMA_FAIL_DAMAGE_MIN,
                        destination.getDangerLevel() * ENIGMA_FAIL_DAMAGE_PER_LEVEL
                    );
                    int finalDamage = difficulty.applyDamage(baseEnigmaDamage);
                    player.takeDamage(finalDamage);

                    if (player.isDead()) {
                        boolean respawned = tryRespawn(player);
                        if (!respawned) {
                            return MoveResult.blocked(MoveResult.BlockReason.GAME_OVER);
                        }
                        return MoveResult.withRespawn(player.getSpawnLocation(), finalDamage);
                    }
                    return MoveResult.withEnigmaAndDamage(destination, enigmaResult, finalDamage);
                }
            }
        }

        // ── Dano de revisita ──────────────────────────────────────────────
        int revisitDamage = 0;
        if (destState.isVisited()) {
            int baseDamage = REVISIT_DAMAGE;
            revisitDamage  = difficulty.applyDamage(baseDamage);
            player.takeDamage(revisitDamage);

            if (player.isDead()) {
                boolean respawned = tryRespawn(player);
                if (!respawned) {
                    return MoveResult.blocked(MoveResult.BlockReason.GAME_OVER);
                }
                return MoveResult.withRespawn(player.getSpawnLocation(), revisitDamage);
            }
        }

        // ── Executa o movimento ─────────────────────────────────────────────
        player.moveTo(destination);
        destState.markVisited();

        // ── Combate PvP com multiplicador de proximidade ─────────────────────
        CombatResolver.CombatResult combatResult = null;
        if (players.size() > 1) {
            boolean sharedNode = false;
            for (Player other : players) {
                if (!other.equals(player) &&
                    other.getCurrentLocation().equals(destination)) {
                    sharedNode = true;
                    break;
                }
            }
            if (sharedNode) {
                double multiplier = getProximityMultiplier(player);
                combatResult = combatResolver.resolve(player, destination, multiplier);
            }
        }

        if (destination.equals(objective)) {
            winner  = player;
            running = false;
        }

        if (combatResult != null && combatResult.wasEncountered()) {
            return MoveResult.withCombat(destination, combatResult);
        }
        if (revisitDamage > 0) {
            return MoveResult.successWithDamage(destination, revisitDamage);
        }
        return MoveResult.success(destination);
    }

    // ── Respawn ──────────────────────────────────────────────────────

    /**
     * Limpa o progresso de sala de um jogador após morte.
     *
     * @param player jogador cujo progresso deve ser limpo
     */
    public void clearProgressOnRespawn(Player player) {
        String prefix = player.getId() + ":";
        for (LocationStateEntry entry : locationStates) {
            if (entry.id.startsWith(prefix)) {
                entry.state.reset();
            }
        }
        enigmaPool.clearPlayerHistory(player);

        Location spawn = player.getSpawnLocation();
        if (spawn != null) {
            getOrCreateState(player, spawn.getId()).markVisited();
        }
    }

    // ── Lever Rooms ───────────────────────────────────────────────

    /**
     * Obtém ou gera um {@link LeverRoom} para uma localização.
     *
     * <p>As lever rooms são armazenadas em cache para que o jogador
     * veja sempre as mesmas portas numa revisita. O número de portas
     * é determinado pelo {@code dangerLevel} da sala via
     * {@link EventConfigLoader#doorsFor(int)}, respeitando o JSON.</p>
     *
     * @param loc localização com role LEVER_ROOM ou DUNGEON com evento LEVER
     * @return lever room existente ou recém-gerada
     */
    private LeverRoom getOrGenerateLeverRoom(Location loc) {
        for (KeyValueEntry<String, LeverRoom> kv : leverRooms) {
            if (kv.key.equals(loc.getId())) return kv.value;
        }
        LeverRoom lr = LeverRoom.generate(loc, map, rng);
        leverRooms.addLast(new KeyValueEntry<>(loc.getId(), lr));
        return lr;
    }

    /**
     * Resolve a escolha de uma porta numa lever room.
     *
     * <p>Chamado pela UI após o jogador escolher uma porta.
     * Resultados possíveis:</p>
     * <ul>
     *   <li>Porta correcta → avança para o destino normalmente</li>
     *   <li>Porta com {@link EventType#LEVER} → apresenta enigma do nível
     *       da sala; se falhar, move o jogador para trás e aplica dano</li>
     *   <li>Porta com {@link EventType#KIDNAP} → aplica lógica de rapto
     *       ({@link #resolveKidnap})</li>
     *   <li>Porta com {@link EventType#DAMAGE} → aplica dano directo sem
     *       interação e move para a localização corrente do jogador</li>
     *   <li>Porta com nested lever room → devolve nova lever room</li>
     * </ul>
     *
     * <p><b>Condição de vitória:</b> em todos os ramos onde
     * {@code player.moveTo(dest)} é chamado, o resultado é imediatamente
     * testado contra {@link #objective}. Isto garante que a vitória é
     * detectada mesmo que o caminho passe por uma lever room.</p>
     *
     * @param player      jogador que escolheu
     * @param locationId  id da sala de alavanca
     * @param doorId      id da porta escolhida
     * @param enigmaAnswer resposta ao enigma (para portas com alavanca)
     * @return resultado da resolução
     */
    public MoveResult resolveLeverDoor(Player player, String locationId,
                                       String doorId, String enigmaAnswer) {
        if (!running) return MoveResult.blocked(MoveResult.BlockReason.GAME_OVER);

        LeverRoom lr = null;
        for (KeyValueEntry<String, LeverRoom> kv : leverRooms) {
            if (kv.key.equals(locationId)) { lr = kv.value; break; }
        }
        if (lr == null) return MoveResult.blocked(MoveResult.BlockReason.NOT_ADJACENT);

        Door chosen = lr.findDoor(doorId);
        if (chosen == null) return MoveResult.blocked(MoveResult.BlockReason.NOT_ADJACENT);

        // Porta correcta → avança normalmente
        if (chosen.isCorrect()) {
            Location dest = chosen.getDestination();
            player.moveTo(dest);
            getOrCreateState(player, dest.getId()).markVisited();
            if (dest.equals(objective)) {
                winner = player;
                running = false;
            }
            return MoveResult.success(dest);
        }

        // Porta errada com evento
        Event event = chosen.getEvent();
        if (event == null) {
            return MoveResult.blocked(MoveResult.BlockReason.ENIGMA_PENDING);
        }

        // ── KIDNAP ─────────────────────────────────────────────────────
        if (event.getType() == EventType.KIDNAP) {
            return resolveKidnap(player);
        }

        // ── DAMAGE ─────────────────────────────────────────────────────
        if (event.getType() == EventType.DAMAGE) {
            int baseDamage  = Math.max(ENIGMA_FAIL_DAMAGE_MIN,
                    lr.getLocation().getDangerLevel() * ENIGMA_FAIL_DAMAGE_PER_LEVEL);
            int finalDamage = difficulty.applyDamage(baseDamage);
            player.takeDamage(finalDamage);
            if (player.isDead()) {
                boolean respawned = tryRespawn(player);
                if (!respawned) {
                    return MoveResult.blocked(MoveResult.BlockReason.GAME_OVER);
                }
                return MoveResult.withRespawn(player.getSpawnLocation(), finalDamage);
            }
            return MoveResult.successWithDamage(player.getCurrentLocation(), finalDamage);
        }

        // ── LEVER ─────────────────────────────────────────────────────
        if (event.getType() == EventType.LEVER) {
            if (lr.hasNestedRoom() && doorId.equals(lr.getNestedDoorId())) {
                return MoveResult.withLeverRoom(
                        lr.getLocation(), lr.getNestedRoom().getDoors());
            }

            // Alavanca normal (incluindo a terceira porta em salas dangerLevel >= 3)
            // → apresentar enigma do nível da sala
            Enigma enigma = enigmaPool.pickFor(player, locationId,
                    lr.getLocation().getDangerLevel());

            if (enigma == null) {
                // Sem enigma disponível: avança directamente (fallback)
                Location dest = chosen.getDestination();
                player.moveTo(dest);
                getOrCreateState(player, dest.getId()).markVisited();
                if (dest.equals(objective)) { winner = player; running = false; }
                return MoveResult.success(dest);
            }

            if (enigmaAnswer != null) {
                EnigmaResolver.EnigmaResult result =
                        enigmaResolver.resolve(enigma, enigmaAnswer);

                if (result.isCorrect()) {
                    Location dest = chosen.getDestination();
                    player.moveTo(dest);
                    getOrCreateState(player, dest.getId()).markVisited();
                    // B7: verificar vitória após mover o jogador via porta LEVER
                    if (dest.equals(objective)) {
                        winner = player;
                        running = false;
                    }
                    return MoveResult.success(dest);
                } else {
                    int stepsBack = lr.getLocation().getDangerLevel();
                    Location backDest = moveBackSteps(player, stepsBack);

                    int baseDamage = Math.max(ENIGMA_FAIL_DAMAGE_MIN,
                            stepsBack * ENIGMA_FAIL_DAMAGE_PER_LEVEL);
                    int finalDamage = difficulty.applyDamage(baseDamage);
                    player.takeDamage(finalDamage);

                    if (player.isDead()) {
                        boolean respawned = tryRespawn(player);
                        if (!respawned) {
                            return MoveResult.blocked(MoveResult.BlockReason.GAME_OVER);
                        }
                        return MoveResult.withRespawn(player.getSpawnLocation(), finalDamage);
                    }
                    return MoveResult.successWithDamage(backDest, finalDamage);
                }
            }
            return MoveResult.withEnigmaAndDamage(
                    lr.getLocation(),
                    new EnigmaResolver.EnigmaResult(enigma.getId(), false, null),
                    0);
        }

        return MoveResult.blocked(MoveResult.BlockReason.NOT_ADJACENT);
    }

    // ── Kidnap (Rapto) ──────────────────────────────────────────────

    /**
     * Aplica a lógica de rapto a um jogador.
     *
     * <p>As probabilidades são lidas de {@code event_config.json} via
     * {@link EventConfigLoader}:</p>
     * <ul>
     *   <li>roll &lt; {@code kidnap_near_chance} → teleporta para a sala
     *       mais próxima do objetivo</li>
     *   <li>roll &gt;= {@code kidnap_near_chance} → teleporta para uma
     *       sala aleatória a pelo menos 3 arestas do objetivo</li>
     * </ul>
     *
     * @param player jogador a raptar
     * @return resultado do teleporte
     */
    public MoveResult resolveKidnap(Player player) {
        double roll = rng.nextDouble();
        Location teleportDest;

        if (roll < eventConfig.kidnapNearChance) {
            teleportDest = findNearestToGoal();
        } else {
            teleportDest = findFarFromGoal(3);
        }

        if (teleportDest == null) {
            for (Location loc : map.getAllLocations()) {
                if (!loc.equals(objective) && !loc.equals(player.getCurrentLocation())) {
                    teleportDest = loc;
                    break;
                }
            }
        }
        if (teleportDest == null) teleportDest = player.getSpawnLocation();

        Location kidnapMarker = new Location(
                "kidnap_" + rng.nextInt(100000),
                "Rapto",
                Location.LocationRole.SPAWN,
                0, "Teleportado por rapto", "🌀",
                0, 0,
                null, null);
        player.getFullPathHistory().addLast(kidnapMarker);

        player.moveTo(teleportDest);
        getOrCreateState(player, teleportDest.getId()).markVisited();

        return MoveResult.withKidnap(teleportDest, 0);
    }

    /**
     * Encontra a sala mais próxima do objetivo (excluindo o próprio objetivo).
     *
     * @return localização mais próxima, ou {@code null} se não encontrada
     */
    private Location findNearestToGoal() {
        Location nearest = null;
        double bestCost = Double.POSITIVE_INFINITY;

        for (Location loc : map.getAllLocations()) {
            if (loc.equals(objective)) continue;
            double cost = map.shortestPathCost(loc, objective);
            if (!Double.isInfinite(cost) && cost < bestCost) {
                bestCost = cost;
                nearest = loc;
            }
        }
        return nearest;
    }

    /**
     * Encontra uma sala aleatória que esteja a pelo menos {@code minEdges}
     * arestas de distância do objetivo.
     *
     * @param minEdges distância mínima em arestas
     * @return localização encontrada, ou {@code null}
     */
    private Location findFarFromGoal(int minEdges) {
        DoublyLinkedList<Location> candidates = new DoublyLinkedList<>();

        for (Location loc : map.getAllLocations()) {
            if (loc.equals(objective)) continue;
            ListADT<Location> path = map.shortestPath(loc, objective);
            if (path.size() > 0 && (path.size() - 1) >= minEdges) {
                candidates.addLast(loc);
            }
        }

        if (candidates.isEmpty()) return null;
        int idx = rng.nextInt(candidates.size());
        int i = 0;
        for (Location loc : candidates) {
            if (i == idx) return loc;
            i++;
        }
        return null;
    }

    /**
     * Move o jogador para trás N passos usando o {@code movementHistory}.
     *
     * @param player jogador
     * @param steps  número de passos para trás
     * @return localização final após o recuo
     */
    private Location moveBackSteps(Player player, int steps) {
        for (int i = 0; i < steps; i++) {
            if (!player.goBack()) break;
        }
        return player.getCurrentLocation();
    }

    // ── Atalhos (Shortcuts) ─────────────────────────────────────────────

    /**
     * Devolve a lista de atalhos gerados para este mapa.
     *
     * @return lista de {@link ShortcutEdge}
     */
    public DoublyLinkedList<ShortcutEdge> getShortcuts() {
        return shortcuts;
    }

    /**
     * Devolve apenas os atalhos visíveis para o jogador.
     *
     * @return lista filtrada de atalhos visíveis
     */
    public DoublyLinkedList<ShortcutEdge> getVisibleShortcuts() {
        DoublyLinkedList<ShortcutEdge> visible = new DoublyLinkedList<>();
        for (ShortcutEdge se : shortcuts) {
            if (se.isVisible()) visible.addLast(se);
        }
        return visible;
    }

    /**
     * Procura o atalho que liga {@code from} a {@code to} (bidireccional).
     *
     * @param from localização de origem
     * @param to   localização de destino
     * @return o {@link ShortcutEdge} encontrado, ou {@code null} se não existir
     */
    private ShortcutEdge findShortcut(Location from, Location to) {
        for (ShortcutEdge sc : shortcuts) {
            if ((sc.getFrom().equals(from) && sc.getTo().equals(to))
             || (sc.getFrom().equals(to)   && sc.getTo().equals(from))) {
                return sc;
            }
        }
        return null;
    }

    /**
     * Resolve o evento associado a um atalho visível.
     *
     * @param player       jogador a mover
     * @param destination  destino do atalho
     * @param shortcut     atalho com evento associado
     * @param enigmaAnswer resposta ao enigma (pode ser {@code null})
     * @return resultado do movimento
     */
    private MoveResult resolveShortcutEvent(Player player, Location destination,
                                             ShortcutEdge shortcut, String enigmaAnswer) {
        Event event = shortcut.getEvent();

        if (event.getType() == EventType.ENIGMA) {
            Enigma enigma = (Enigma) event;
            if (enigmaAnswer == null) {
                return MoveResult.withEnigmaAndDamage(destination,
                        new EnigmaResolver.EnigmaResult(enigma.getId(), false, null), 0);
            }
            EnigmaResolver.EnigmaResult result = enigmaResolver.resolve(enigma, enigmaAnswer);
            if (result.isCorrect()) {
                player.moveTo(destination);
                getOrCreateState(player, destination.getId()).markVisited();
                if (destination.equals(objective)) { winner = player; running = false; }
                return MoveResult.success(destination);
            } else {
                int dmg = difficulty.applyDamage(Math.max(ENIGMA_FAIL_DAMAGE_MIN,
                              destination.getDangerLevel() * ENIGMA_FAIL_DAMAGE_PER_LEVEL));
                player.takeDamage(dmg);
                if (player.isDead()) {
                    boolean respawned = tryRespawn(player);
                    if (!respawned) return MoveResult.blocked(MoveResult.BlockReason.GAME_OVER);
                    return MoveResult.withRespawn(player.getSpawnLocation(), dmg);
                }
                return MoveResult.withEnigmaAndDamage(destination, result, dmg);
            }
        }

        if (event.getType() == EventType.LEVER) {
            LeverRoom lr = getOrGenerateLeverRoom(destination);
            player.moveTo(destination);
            return MoveResult.withLeverRoom(destination, lr.getDoors());
        }

        if (event.getType() == EventType.KIDNAP) {
            return resolveKidnap(player);
        }

        player.moveTo(destination);
        getOrCreateState(player, destination.getId()).markVisited();
        if (destination.equals(objective)) { winner = player; running = false; }
        return MoveResult.success(destination);
    }

    /**
     * Devolve o {@link Enigma} associado ao atalho entre {@code from} e {@code to},
     * ou {@code null} se o atalho não existir, não tiver evento, ou o evento
     * não for um enigma.
     *
     * @param from localização de origem
     * @param to   localização de destino
     * @return enigma do atalho, ou {@code null}
     */
    public Enigma getShortcutEnigma(Location from, Location to) {
        ShortcutEdge sc = findShortcut(from, to);
        if (sc == null || sc.getEvent() == null) return null;
        if (sc.getEvent().getType() != EventType.ENIGMA) return null;
        return (Enigma) sc.getEvent();
    }

    // ── Bots ───────────────────────────────────────────────────

    /**
     * Calcula e executa o próximo movimento de um bot.
     *
     * <p>Pipeline de decisão:</p>
     * <ol>
     *   <li>A estratégia escolhe o próximo destino.</li>
     *   <li>Se existir um atalho com evento ENIGMA para esse destino,
     *       o bot resolve-o directamente via {@link #moveTo}.</li>
     *   <li>Se existir um atalho com evento LEVER, pré-gera a lever room
     *       em cache (sem mover o jogador) e delega em
     *       {@link #resolveLeverDoor} para a porta correcta — que se
     *       encarrega de mover o jogador uma única vez.</li>
     *   <li>Se o {@link LocationState} do destino já tiver
     *       {@code assignedEventType == LEVER} (evento dinâmico sorteado
     *       numa visita anterior) ou a sala for {@code LEVER_ROOM}, segue
     *       o mesmo padrão: pré-gera cache e delega em
     *       {@link #resolveLeverDoor}.</li>
     *   <li>Caso contrário, chama {@link #moveTo} normalmente. Se o
     *       resultado for {@code LEVER_ROOM} (evento sorteado pela primeira
     *       vez), o bot resolve imediatamente via {@link #resolveLeverDoor}.</li>
     * </ol>
     *
     * <p><strong>Invariante:</strong> {@code player.moveTo()} é chamado
     * exactamente uma vez por turno de bot, sempre dentro de
     * {@link #resolveLeverDoor} ou {@link #moveTo} — nunca no corpo
     * deste método.</p>
     *
     * @param player   jogador bot
     * @param strategy estratégia de decisão
     * @return resultado do movimento
     */
    public MoveResult getBotMove(Player player, BotStrategy strategy) {
        Location next = strategy.chooseNextLocation(player, map, objective);
        if (next == null) return MoveResult.blocked(MoveResult.BlockReason.NOT_ADJACENT);

        // ── Atalho com evento ──────────────────────────────────────────────
        ShortcutEdge sc = findShortcut(player.getCurrentLocation(), next);
        if (sc != null && sc.getEvent() != null) {
            if (sc.getEvent().getType() == EventType.ENIGMA) {
                String scAnswer = strategy.solveEnigma((Enigma) sc.getEvent());
                return moveTo(player, next, scAnswer);
            }
            if (sc.getEvent().getType() == EventType.LEVER) {
                // Pré-gera a lever room em cache; NÃO move o jogador aqui.
                // resolveLeverDoor() trata do player.moveTo() para a porta correcta.
                LeverRoom lr = getOrGenerateLeverRoom(next);
                for (Door door : lr.getDoors()) {
                    if (door.isCorrect()) {
                        return resolveLeverDoor(player, next.getId(), door.getId(), null);
                    }
                }
                return MoveResult.success(next);
            }
        }

        // ── Evento dinâmico LEVER já atribuído ao destino ──────────────────
        LocationState nextState = getOrCreateState(player, next.getId());
        EventType assignedEvent = nextState.getAssignedEventType();

        if (assignedEvent == EventType.LEVER || next.isLeverRoom()) {
            // Pré-gera a lever room em cache; NÃO move o jogador aqui.
            // resolveLeverDoor() trata do player.moveTo() para a porta correcta.
            LeverRoom lr = getOrGenerateLeverRoom(next);
            for (Door door : lr.getDoors()) {
                if (door.isCorrect()) {
                    return resolveLeverDoor(player, next.getId(), door.getId(), null);
                }
            }
            return MoveResult.success(next);
        }

        // ── Movimento normal (enigma estático ou sala sem evento) ──────────
        String answer = null;
        if (next.hasEnigmaByLevel() && !nextState.isEnigmaResolved()) {
            Enigma enigma = enigmaPool.pickFor(player, next.getId(), next.getDangerLevel());
            if (enigma != null) answer = strategy.solveEnigma(enigma);
        }

        MoveResult result = moveTo(player, next, answer);

        // ── Fallback: evento LEVER sorteado pela primeira vez nesta chamada ──
        if (result.isLeverRoom()) {
            LeverRoom lr = getOrGenerateLeverRoom(next);
            for (Door door : lr.getDoors()) {
                if (door.isCorrect()) {
                    return resolveLeverDoor(player, next.getId(), door.getId(), null);
                }
            }
            return MoveResult.success(next);
        }

        return result;
    }

    // ── Turnos ───────────────────────────────────────────────

    /**
     * Avança para o próximo jogador.
     *
     * @return jogador que deve jogar a seguir
     */
    public Player nextTurn() {
        if (players.isEmpty()) return null;
        currentPlayerIndex = (currentPlayerIndex + 1) % players.size();
        return getCurrentPlayer();
    }

    /**
     * Devolve o jogador que deve jogar no turno atual.
     *
     * @return jogador atual, ou {@code null} se não houver jogadores
     */
    public Player getCurrentPlayer() {
        int i = 0;
        for (Player p : players) {
            if (i == currentPlayerIndex) return p;
            i++;
        }
        return null;
    }

    // ── Estado ───────────────────────────────────────────────

    /** @return {@code true} enquanto não houver vencedor */
    public boolean isRunning() { return running; }

    /** @return vencedor, ou {@code null} se o jogo ainda não acabou */
    public Player getWinner() { return winner; }

    /** @return mapa do jogo */
    public GameMap getMap() { return map; }

    /** @return localização objetivo */
    public Location getObjective() { return objective; }

    /** @return lista de jogadores ativos */
    public ListADT<Player> getPlayers() { return players; }

    /**
     * Devolve a configuração de eventos carregada de
     * {@code event_config.json}. Útil para testes e para a UI.
     *
     * @return instância imutável de {@link EventConfigLoader}
     */
    public EventConfigLoader getEventConfig() { return eventConfig; }

    // ── Estado por jogador e por localização ──────────────────────────

    /**
     * Devolve o {@link LocationState} para um par (jogador, localização),
     * criando-o se ainda não existir.
     *
     * @param player     jogador cujo estado é consultado
     * @param locationId id da localização
     * @return estado da localização para este jogador
     */
    public LocationState getOrCreateState(Player player, String locationId) {
        String key = player.getId() + ":" + locationId;
        for (LocationStateEntry entry : locationStates) {
            if (entry.id.equals(key)) return entry.state;
        }
        LocationState state = new LocationState();
        locationStates.addLast(new LocationStateEntry(key, state));
        return state;
    }

    /**
     * Sobrecarga de compatibilidade sem isolamento por jogador.
     *
     * @deprecated Use {@link #getOrCreateState(Player, String)}
     * @param locationId id da localização
     * @return estado global da localização
     */
    @Deprecated
    public LocationState getOrCreateState(String locationId) {
        for (LocationStateEntry entry : locationStates) {
            if (entry.id.equals(locationId)) return entry.state;
        }
        LocationState state = new LocationState();
        locationStates.addLast(new LocationStateEntry(locationId, state));
        return state;
    }

    // ── API de enigmas (público para a UI) ─────────────────────────────

    /**
     * Devolve o {@link Enigma} que será apresentado ao jogador para uma sala.
     *
     * @param player     jogador
     * @param locationId id da localização
     * @return enigma selecionado, ou {@code null} se a sala não tiver enigma
     */
    public Enigma getEnigmaForPlayer(Player player, String locationId) {
        Location loc;
        try { loc = map.getById(locationId); }
        catch (IllegalArgumentException e) { return null; }
        if (loc == null || !loc.hasEnigmaByLevel()) return null;
        return enigmaPool.pickFor(player, locationId, loc.getDangerLevel());
    }

    /**
     * @deprecated Use {@link #getEnigmaForPlayer(Player, String)}.
     * @return sempre {@code null}
     */
    @Deprecated
    public Enigma findEnigmaByLocationId(String locationId) {
        return null;
    }

    // ── Classes internas ───────────────────────────────────────────────

    private static class LocationStateEntry {
        final String        id;
        final LocationState state;
        LocationStateEntry(String id, LocationState state) {
            this.id    = id;
            this.state = state;
        }
    }

    /**
     * Contador de respawns por jogador.
     */
    private static class RespawnEntry {
        final String playerId;
        int          count;

        RespawnEntry(String playerId) {
            this.playerId = playerId;
            this.count    = 0;
        }
    }

    /**
     * Par chave-valor genérico para simular um mapa usando
     * {@link DoublyLinkedList} (evita java.util.HashMap).
     *
     * @param <K> tipo da chave
     * @param <V> tipo do valor
     */
    static class KeyValueEntry<K, V> {
        final K key;
        V       value;

        KeyValueEntry(K key, V value) {
            this.key   = key;
            this.value = value;
        }
    }
}