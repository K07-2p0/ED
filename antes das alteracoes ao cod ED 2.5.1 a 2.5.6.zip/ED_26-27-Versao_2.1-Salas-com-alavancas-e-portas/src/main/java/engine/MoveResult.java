package engine;

import Lists.DoublyLinkedList;
import model.Door;
import model.Location;

/**
 * Resultado de uma tentativa de movimento no {@link GameEngine}.
 *
 * <p>Encapsula o sucesso ou falha do movimento, o motivo de bloqueio
 * (se aplicável), e os efeitos desencadeados (combate, enigma, respawn,
 * lever room, kidnap).</p>
 *
 * <p>O {@code GameEngine} devolve um {@link MoveResult} a cada chamada
 * a {@code moveTo()}, permitindo à UI reagir sem conhecer os detalhes
 * internos do engine.</p>
 *
 * <h2>Campo {@code damageTaken}</h2>
 * <p>Transporta o dano sofrido pelo jogador nesta acção (0 se não houve).</p>
 *
 * <h2>Respawn</h2>
 * <p>Quando o jogador morre (HP chega a 0), o engine chama
 * {@link model.Player#respawn()} e devolve um resultado com
 * {@link #respawned()} {@code == true}. A UI deve mover o token do
 * jogador para {@link #getRespawnLocation()} e mostrar feedback de morte.</p>
 *
 * <h2>Lever Room (Sala de Alavanca)</h2>
 * <p>Quando o destino é uma {@link model.Location} com
 * {@code role == LEVER_ROOM}, o resultado contém a lista de portas
 * via {@link #getPendingDoors()}. A UI deve apresentar as portas ao
 * jogador e chamar {@code GameEngine.resolveLeverDoor()} com a escolha.</p>
 *
 * <h2>Kidnap (Rapto)</h2>
 * <p>Quando o jogador é raptado por um {@link model.EventoRapto},
 * {@link #wasKidnapped()} devolve {@code true} e o destino é a nova
 * localização para onde foi teleportado.</p>
 */
public class MoveResult {

    /** Motivo de bloqueio do movimento. */
    public enum BlockReason {
        /** O destino não é adjacente ao jogador. */
        NOT_ADJACENT,
        /** O enigma da localização ainda não foi resolvido. */
        ENIGMA_PENDING,
        /** O jogo já terminou (há um vencedor). */
        GAME_OVER,
        /** A sala é uma lever room — o jogador deve escolher uma porta. */
        LEVER_ROOM_PENDING,
        /** Nenhum bloqueio (movimento bem-sucedido ou respawn). */
        NONE
    }

    private final boolean                          success;
    private final BlockReason                      blockReason;
    private final Location                         destination;
    private final CombatResolver.CombatResult      combatResult;
    private final EnigmaResolver.EnigmaResult      enigmaResult;
    private final int                              damageTaken;

    /**
     * {@code true} se o jogador morreu e foi recolocado na sala de spawn
     * como resultado desta acção. A {@link #destination} continua a ser
     * o spawn (localização actual após respawn).
     */
    private final boolean  respawned;

    /**
     * Localização de spawn para onde o jogador foi teleportado.
     * Apenas relevante quando {@link #respawned()} é {@code true}.
     */
    private final Location respawnLocation;

    /**
     * Lista de portas pendentes de uma lever room.
     * {@code null} se o resultado não envolve uma sala de alavanca.
     */
    private final DoublyLinkedList<Door> pendingDoors;

    /**
     * {@code true} se o jogador foi raptado (teleportado) por um
     * {@link model.EventoRapto}.
     */
    private final boolean kidnapped;

    // ── Construtor privado ───────────────────────────────────────────────────

    private MoveResult(boolean success, BlockReason blockReason,
                       Location destination,
                       CombatResolver.CombatResult combatResult,
                       EnigmaResolver.EnigmaResult enigmaResult,
                       int damageTaken,
                       boolean respawned,
                       Location respawnLocation,
                       DoublyLinkedList<Door> pendingDoors,
                       boolean kidnapped) {
        this.success         = success;
        this.blockReason     = blockReason;
        this.destination     = destination;
        this.combatResult    = combatResult;
        this.enigmaResult    = enigmaResult;
        this.damageTaken     = Math.max(0, damageTaken);
        this.respawned       = respawned;
        this.respawnLocation = respawnLocation;
        this.pendingDoors    = pendingDoors;
        this.kidnapped       = kidnapped;
    }

    // ── Factory methods ──────────────────────────────────────────────────────

    /**
     * Movimento bloqueado sem dano.
     *
     * @param reason motivo do bloqueio
     * @return resultado de bloqueio
     */
    public static MoveResult blocked(BlockReason reason) {
        return new MoveResult(false, reason, null, null, null, 0, false, null, null, false);
    }

    /**
     * Movimento bem-sucedido sem eventos.
     *
     * @param destination localização de destino
     * @return resultado de sucesso simples
     */
    public static MoveResult success(Location destination) {
        return new MoveResult(true, BlockReason.NONE, destination, null, null, 0, false, null, null, false);
    }

    /**
     * Movimento bem-sucedido com dano (ex: revisita de sala).
     *
     * @param destination localização de destino
     * @param damageTaken dano sofrido
     * @return resultado de sucesso com dano
     */
    public static MoveResult successWithDamage(Location destination, int damageTaken) {
        return new MoveResult(true, BlockReason.NONE, destination, null, null, damageTaken, false, null, null, false);
    }

    /**
     * Movimento bem-sucedido com combate.
     *
     * @param destination  localização de destino
     * @param combatResult resultado do combate
     * @return resultado com combate
     */
    public static MoveResult withCombat(Location destination,
                                        CombatResolver.CombatResult combatResult) {
        return new MoveResult(true, BlockReason.NONE, destination, combatResult, null, 0, false, null, null, false);
    }

    /**
     * Movimento bloqueado por enigma pendente, sem dano.
     * Mantido por retrocompatibilidade.
     *
     * @param destination  localização de destino
     * @param enigmaResult resultado da tentativa ao enigma
     * @return resultado com enigma
     */
    public static MoveResult withEnigma(Location destination,
                                        EnigmaResolver.EnigmaResult enigmaResult) {
        return withEnigmaAndDamage(destination, enigmaResult, 0);
    }

    /**
     * Movimento bloqueado por enigma errado com dano aplicado.
     *
     * @param destination  localização de destino
     * @param enigmaResult resultado da tentativa
     * @param damageTaken  dano sofrido (já aplicado ao Player)
     * @return resultado com enigma e dano
     */
    public static MoveResult withEnigmaAndDamage(Location destination,
                                                  EnigmaResolver.EnigmaResult enigmaResult,
                                                  int damageTaken) {
        boolean resolved = enigmaResult.isCorrect();
        return new MoveResult(
            resolved,
            resolved ? BlockReason.NONE : BlockReason.ENIGMA_PENDING,
            destination,
            null,
            enigmaResult,
            resolved ? 0 : damageTaken,
            false,
            null,
            null,
            false
        );
    }

    /**
     * O jogador morreu e foi recolocado automaticamente no spawn.
     *
     * <p>O dano fatal já foi aplicado ao {@link model.Player} e
     * {@link model.Player#respawn()} já foi chamado antes de criar
     * este resultado. A UI deve:</p>
     * <ol>
     *   <li>Mostrar mensagem de morte e dano sofrido</li>
     *   <li>Mover o token do jogador para {@link #getRespawnLocation()}</li>
     *   <li>Atualizar HP (voltou a 100)</li>
     * </ol>
     *
     * @param respawnLocation sala de spawn do jogador
     * @param damageTaken     dano que causou a morte
     * @return resultado de respawn
     */
    public static MoveResult withRespawn(Location respawnLocation, int damageTaken) {
        return new MoveResult(
            true,              // O "movimento" foi executado (para o spawn)
            BlockReason.NONE,
            respawnLocation,   // destino = spawn
            null, null,
            damageTaken,
            true,              // flag de respawn ativa
            respawnLocation,
            null,
            false
        );
    }

    /**
     * A sala destino é uma lever room — o jogador deve escolher uma porta.
     *
     * <p>O movimento não é executado; a UI deve apresentar as portas ao
     * jogador e chamar {@code GameEngine.resolveLeverDoor()} com a escolha.</p>
     *
     * @param destination  localização da lever room
     * @param pendingDoors lista de portas disponíveis
     * @return resultado com portas pendentes
     */
    public static MoveResult withLeverRoom(Location destination,
                                            DoublyLinkedList<Door> pendingDoors) {
        return new MoveResult(
            false,
            BlockReason.LEVER_ROOM_PENDING,
            destination,
            null, null,
            0,
            false,
            null,
            pendingDoors,
            false
        );
    }

    /**
     * O jogador foi raptado e teleportado para uma localização aleatória.
     *
     * @param teleportDest localização de destino do teleporte
     * @param damageTaken  dano sofrido (0 se nenhum)
     * @return resultado de kidnap
     */
    public static MoveResult withKidnap(Location teleportDest, int damageTaken) {
        return new MoveResult(
            true,
            BlockReason.NONE,
            teleportDest,
            null, null,
            damageTaken,
            false,
            null,
            null,
            true
        );
    }

    // ── Getters ──────────────────────────────────────────────────────────────

    /** @return {@code true} se o movimento foi executado com sucesso */
    public boolean isSuccess()     { return success; }

    /** @return motivo de bloqueio, ou {@link BlockReason#NONE} se sucesso */
    public BlockReason getBlockReason() { return blockReason; }

    /** @return localização de destino (ou spawn em caso de respawn) */
    public Location getDestination() { return destination; }

    /** @return resultado de combate, ou {@code null} se não houve */
    public CombatResolver.CombatResult getCombatResult() { return combatResult; }

    /** @return resultado de enigma, ou {@code null} se não havia enigma */
    public EnigmaResolver.EnigmaResult getEnigmaResult() { return enigmaResult; }

    /** @return dano sofrido ({@code >= 0}) */
    public int getDamageTaken() { return damageTaken; }

    /** @return {@code true} se este resultado inclui dano sofrido */
    public boolean tookDamage() { return damageTaken > 0; }

    /** @return {@code true} se houve combate neste movimento */
    public boolean hadCombat()  { return combatResult != null && combatResult.wasEncountered(); }

    /** @return {@code true} se havia enigma neste movimento */
    public boolean hadEnigma()  { return enigmaResult != null; }

    /**
     * @return {@code true} se o jogador morreu e foi recolocado no spawn
     *         como consequência desta acção
     */
    public boolean respawned() { return respawned; }

    /**
     * @return localização de spawn para onde o jogador foi teleportado,
     *         ou {@code null} se não houve respawn
     */
    public Location getRespawnLocation() { return respawnLocation; }

    /**
     * Lista de portas de uma lever room que aguardam a escolha do jogador.
     *
     * @return lista de portas, ou {@code null} se não é uma lever room
     */
    public DoublyLinkedList<Door> getPendingDoors() { return pendingDoors; }

    /**
     * Indica se o resultado envolve uma lever room com portas pendentes.
     *
     * @return {@code true} se o jogador está numa sala de alavanca
     */
    public boolean isLeverRoom() { return pendingDoors != null; }

    /**
     * Indica se o jogador foi raptado e teleportado.
     *
     * @return {@code true} se houve kidnap
     */
    public boolean wasKidnapped() { return kidnapped; }

    @Override
    public String toString() {
        if (kidnapped) {
            String dmgSuffix = damageTaken > 0 ? " | 💔 -" + damageTaken + " HP" : "";
            return "🌀 Raptado! Teleportado para " + destination.getName() + dmgSuffix;
        }
        if (isLeverRoom()) {
            return "🚪 Sala de Alavanca: " + destination.getName()
                + " | " + pendingDoors.size() + " portas";
        }
        if (respawned) {
            return "☠️ Morreu! Respawn em " + respawnLocation.getName()
                + " | 💔 -" + damageTaken + " HP fatais | ❤ restaurado para 100";
        }
        if (!success) {
            String dmgSuffix = damageTaken > 0 ? " | 💔 -" + damageTaken + " HP" : "";
            return "🚫 Bloqueado: " + blockReason + dmgSuffix;
        }
        StringBuilder sb = new StringBuilder("✅ Moveu para " + destination.getName());
        if (damageTaken > 0) sb.append(" | 💔 -").append(damageTaken).append(" HP");
        if (hadCombat())  sb.append(" | ").append(combatResult);
        if (hadEnigma())  sb.append(" | ").append(enigmaResult);
        return sb.toString();
    }
}
