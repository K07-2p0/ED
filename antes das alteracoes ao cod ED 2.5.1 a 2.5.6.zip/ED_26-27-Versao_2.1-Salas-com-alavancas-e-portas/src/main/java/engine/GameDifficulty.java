package engine;

import model.Location.LocationRole;

/**
 * Níveis de dificuldade do Labirinto da Glória.
 *
 * <p>Cada constante encapsula um conjunto de parâmetros que modificam
 * o comportamento do {@link GameEngine}:</p>
 * <ul>
 *   <li>{@code damageMultiplier} — fator aplicado em todos os danos
 *       ({@link GameEngine#takeDamageWithDifficulty(model.Player, int)})</li>
 *   <li>{@code maxRespawns} — número máximo de respawns; {@code -1} = ilimitado</li>
 *   <li>{@code keepItemsOnDeath} — se {@code true}, o inventário é preservado
 *       após morte</li>
 *   <li>{@code respawnPoint} — papel da sala para onde o jogador renasce</li>
 * </ul>
 *
 * <h2>Resumo dos valores</h2>
 * <pre>
 * │ Nível    │ mult │ respawns │ keepItems │ respawnPoint │
 * │ EASY     │ 0.5  │ ∞        │ true      │ DUNGEON      │
 * │ NORMAL   │ 1.0  │ ∞        │ false     │ SPAWN        │
 * │ HARD     │ 1.5  │ 5        │ false     │ SPAWN        │
 * │ HARDCORE │ 1.5  │ 0        │ false     │ SPAWN        │
 * </pre>
 *
 * <p>HARDCORE tem {@code maxRespawns == 0}, o que significa game-over
 * imediato na primeira morte — sem qualquer respawn.</p>
 */
public enum GameDifficulty {

    /**
     * Fácil: dano reduzido, respawns ilimitados, itens preservados
     * e regresso à sala anterior ({@link LocationRole#DUNGEON}).
     */
    EASY    (0.5,  -1, true,  LocationRole.DUNGEON),

    /**
     * Normal: dano base, respawns ilimitados, itens perdidos na morte,
     * regresso ao spawn ({@link LocationRole#SPAWN}).
     */
    NORMAL  (1.0,  -1, false, LocationRole.SPAWN),

    /**
     * Difícil: dano aumentado, máximo 5 respawns, itens perdidos,
     * regresso ao spawn ({@link LocationRole#SPAWN}).
     */
    HARD    (1.5,   5, false, LocationRole.SPAWN),

    /**
     * Hardcore: dano aumentado, 0 respawns (game-over imediato ao morrer),
     * itens perdidos, regresso ao spawn ({@link LocationRole#SPAWN}, nunca ocorre).
     */
    HARDCORE(1.5,   0, false, LocationRole.SPAWN);

    // ── Campos ───────────────────────────────────────────────────

    /**
     * Multiplicador de dano. Aplicado em todos os {@code takeDamage}:
     * {@code dano_final = (int) Math.ceil(base * damageMultiplier)}.
     */
    public final double       damageMultiplier;

    /**
     * Número máximo de respawns por jogador nesta sessão.
     * {@code -1} significa ilimitado.
     */
    public final int          maxRespawns;

    /**
     * Se {@code true}, o jogador mantém o inventário ao morrer.
     * Se {@code false}, o inventário é limpo no respawn.
     */
    public final boolean      keepItemsOnDeath;

    /**
     * Papel ({@link LocationRole}) da sala de respawn.
     * Em EASY é {@link LocationRole#DUNGEON} (sala anterior);
     * nos restantes é {@link LocationRole#SPAWN} (spawn inicial definido no mapa).
     */
    public final LocationRole respawnPoint;

    // ── Construtor ────────────────────────────────────────────────

    /**
     * Inicializa uma constante de dificuldade.
     *
     * @param damageMultiplier multiplicador de dano
     * @param maxRespawns      máximo de respawns ({@code -1} = ilimitado)
     * @param keepItemsOnDeath preserva inventário ao morrer
     * @param respawnPoint     papel da sala de respawn
     */
    GameDifficulty(double damageMultiplier, int maxRespawns,
                   boolean keepItemsOnDeath, LocationRole respawnPoint) {
        this.damageMultiplier = damageMultiplier;
        this.maxRespawns      = maxRespawns;
        this.keepItemsOnDeath = keepItemsOnDeath;
        this.respawnPoint     = respawnPoint;
    }

    // ── Utilitários ───────────────────────────────────────────────

    /**
     * Aplica o multiplicador de dano e arredonda para cima.
     *
     * @param baseDamage dano base
     * @return dano ajustado pela dificuldade
     */
    public int applyDamage(int baseDamage) {
        return (int) Math.ceil(baseDamage * damageMultiplier);
    }

    /**
     * Indica se o jogador ainda pode renascer dado o número de respawns
     * já usados.
     *
     * @param respawnsUsed número de respawns já consumidos por este jogador
     * @return {@code true} se ainda tem respawns disponíveis
     */
    public boolean canRespawn(int respawnsUsed) {
        if (maxRespawns < 0) return true;      // ilimitado
        return respawnsUsed < maxRespawns;
    }

    /**
     * Indica se esta dificuldade é HARDCORE (game-over imediato).
     *
     * @return {@code true} se for HARDCORE
     */
    public boolean isHardcore() {
        return this == HARDCORE;
    }
}
