package engine;

import model.Location;
import model.Player;

/**
 * Resolve encontros de combate baseados no {@code dangerLevel}
 * da {@link Location} atual do jogador, escalados por um
 * {@code proximityMultiplier} calculado pelo {@link GameEngine}.
 *
 * <p>Fórmulas:</p>
 * <ul>
 *   <li>Probabilidade = {@code dangerLevel × ENCOUNTER_CHANCE_PER_LEVEL × proximityMultiplier}%
 *       (limitada a 100%)</li>
 *   <li>Dano base     = {@code dangerLevel × DAMAGE_PER_LEVEL}</li>
 *   <li>Dano final    = {@code (dano base ± 20%) × proximityMultiplier}</li>
 * </ul>
 *
 * <p>O multiplicador vem de {@link GameEngine#getProximityMultiplier(Player)}
 * e situa-se no intervalo [{@value #MULTIPLIER_MIN}, {@value #MULTIPLIER_MAX}]:</p>
 * <ul>
 *   <li>{@value #MULTIPLIER_MIN} quando o jogador está muito longe do objetivo</li>
 *   <li>1.0 a meio do mapa</li>
 *   <li>{@value #MULTIPLIER_MAX} quando o jogador está muito perto do objetivo</li>
 * </ul>
 */
public class CombatResolver {

    /** Percentagem de probabilidade de encontro por nível de perigo. */
    private static final int ENCOUNTER_CHANCE_PER_LEVEL = 15;

    /** Dano base por nível de perigo. */
    private static final int DAMAGE_PER_LEVEL = 10;

    /** Variação máxima do dano (±20% do dano base). */
    private static final double DAMAGE_VARIANCE = 0.20;

    /** Valor mínimo do multiplicador de proximidade (jogador muito longe). */
    public static final double MULTIPLIER_MIN = 0.5;

    /** Valor máximo do multiplicador de proximidade (jogador muito perto). */
    public static final double MULTIPLIER_MAX = 2.0;

    /** Limiar acima do qual a UI deve mostrar alerta de perigo elevado. */
    public static final double HIGH_DANGER_THRESHOLD = 1.5;

    private final SimpleRandom random;

    /**
     * Cria um {@code CombatResolver} com semente aleatória.
     */
    public CombatResolver() {
        this.random = new SimpleRandom();
    }

    /**
     * Cria um {@code CombatResolver} com semente determinística (útil para testes).
     *
     * @param seed semente do gerador
     */
    public CombatResolver(long seed) {
        this.random = new SimpleRandom(seed);
    }

    /**
     * Tenta um encontro de combate sem multiplicador de proximidade.
     *
     * <p>Atalho para {@link #resolve(Player, Location, double)} com
     * multiplicador 1.0 (comportamento neutro).</p>
     *
     * @param player   jogador que chegou à localização
     * @param location localização atual (fonte do dangerLevel)
     * @return resultado do encontro
     */
    public CombatResult resolve(Player player, Location location) {
        return resolve(player, location, 1.0);
    }

    /**
     * Tenta um encontro de combate aplicando o multiplicador de proximidade.
     *
     * <p>O {@code proximityMultiplier} escala tanto a probabilidade de encontro
     * como o dano final, tornando as consequências mais severas conforme o
     * jogador se aproxima do objetivo.</p>
     *
     * @param player              jogador que chegou à localização
     * @param location            localização atual (fonte do dangerLevel)
     * @param proximityMultiplier fator de escala em [{@value #MULTIPLIER_MIN},
     *                            {@value #MULTIPLIER_MAX}]; obtido via
     *                            {@link GameEngine#getProximityMultiplier(Player)}
     * @return resultado do encontro
     */
    public CombatResult resolve(Player player, Location location, double proximityMultiplier) {
        int danger = location.getDangerLevel();

        // dangerLevel 0 = zona segura, nunca há encontro
        if (danger == 0) {
            return CombatResult.noEncounter();
        }

        // Probabilidade escalada pelo multiplicador, clamped a 100%
        int encounterChance = (int) Math.min(100,
                danger * ENCOUNTER_CHANCE_PER_LEVEL * proximityMultiplier);
        boolean encountered = random.nextInt(100) < encounterChance;

        if (!encountered) {
            return CombatResult.noEncounter();
        }

        // Dano base com variação aleatória ±20%, depois escalado pelo multiplicador
        int    baseDamage  = danger * DAMAGE_PER_LEVEL;
        double variance    = 1.0 + (random.nextDouble() * 2 * DAMAGE_VARIANCE - DAMAGE_VARIANCE);
        int    finalDamage = (int) Math.round(baseDamage * variance * proximityMultiplier);

        player.takeDamage(finalDamage);
        return CombatResult.encounter(finalDamage);
    }

    // ── Classe interna de resultado ─────────────────────────────────────────────

    /**
     * Resultado de uma tentativa de combate.
     */
    public static class CombatResult {

        private final boolean encountered;
        private final int     damage;

        private CombatResult(boolean encountered, int damage) {
            this.encountered = encountered;
            this.damage      = damage;
        }

        /**
         * Cria um resultado de não-encontro.
         *
         * @return resultado sem combate
         */
        public static CombatResult noEncounter() {
            return new CombatResult(false, 0);
        }

        /**
         * Cria um resultado de encontro com dano.
         *
         * @param damage dano aplicado
         * @return resultado com combate
         */
        public static CombatResult encounter(int damage) {
            return new CombatResult(true, damage);
        }

        /** @return {@code true} se houve encontro */
        public boolean wasEncountered() { return encountered; }

        /** @return dano recebido (0 se não houve encontro) */
        public int getDamage() { return damage; }

        @Override
        public String toString() {
            return encountered
                ? String.format("⚔ Combate! Dano: %d", damage)
                : "✅ Sem encontro";
        }
    }
}
