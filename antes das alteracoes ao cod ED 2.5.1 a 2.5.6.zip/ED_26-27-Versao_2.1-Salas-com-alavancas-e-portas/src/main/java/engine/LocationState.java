package engine;

import model.EventType;

/**
 * Estado externo e mutável de uma {@link model.Location} durante uma sessão de jogo.
 *
 * <p>Por design, {@link model.Location} é imutável — não guarda estado de
 * jogo. Esta classe mantém o estado dinâmico indexado pelo id da localização
 * no {@link GameEngine}, usando uma estrutura de dados da API_ED como mapa.</p>
 *
 * <p>Campos por localização:</p>
 * <ul>
 *   <li>{@link #visited} — o jogador atual já entrou aqui nesta sessão</li>
 *   <li>{@link #enigmaResolved} — o enigma desta localização já foi
 *       resolvido (a localização fica desbloqueada para movimentos futuros)</li>
 *   <li>{@link #assignedEventType} — tipo de evento determinado em runtime
 *       para salas DUNGEON (calculado uma vez por par jogador/sala e depois
 *       reutilizado em revisitas). {@code null} enquanto ainda não foi
 *       atribuído.</li>
 * </ul>
 *
 * <h2>Respawn</h2>
 * <p>Quando um jogador morre e faz respawn, o {@link GameEngine} chama
 * {@link #reset()} em todos os estados desse jogador. Isto permite que ele
 * volte a entrar nas salas já visitadas sem custo de revisita e que os
 * enigmas sejam novamente pedidos. O histórial de movimento
 * ({@link model.Player#getMovementHistory()}) e o registo completo para o
 * relatório final não são afectados.</p>
 */
public class LocationState {

    private boolean   visited;
    private boolean   enigmaResolved;

    /**
     * Tipo de evento atribuído em runtime a esta sala para este jogador.
     * {@code null} enquanto ainda não foi determinado pelo engine.
     *
     * @see GameEngine#pickRoomEventType(int)
     */
    private EventType assignedEventType;

    /**
     * Cria o estado inicial de uma localização (não visitada, enigma pendente,
     * tipo de evento ainda não atribuído).
     */
    public LocationState() {
        this.visited           = false;
        this.enigmaResolved    = false;
        this.assignedEventType = null;
    }

    // ── Getters / Setters ───────────────────────────────────────────────────

    /** @return {@code true} se a localização já foi visitada nesta sessão */
    public boolean isVisited() { return visited; }

    /** Marca a localização como visitada. */
    public void markVisited() { this.visited = true; }

    /**
     * @return {@code true} se o enigma desta localização já foi resolvido
     *         ou se não tem enigma
     */
    public boolean isEnigmaResolved() { return enigmaResolved; }

    /** Marca o enigma como resolvido. */
    public void resolveEnigma() { this.enigmaResolved = true; }

    /**
     * Devolve o tipo de evento atribuído em runtime a esta localização para
     * este jogador, ou {@code null} se ainda não foi determinado.
     *
     * @return {@link EventType} atribuído, ou {@code null}
     */
    public EventType getAssignedEventType() { return assignedEventType; }

    /**
     * Guarda o tipo de evento determinado em runtime pelo engine para este
     * par (jogador, localização). Chamado no máximo uma vez por par.
     *
     * @param t tipo de evento a guardar (não deve ser {@code null})
     */
    public void setAssignedEventType(EventType t) { this.assignedEventType = t; }

    /**
     * Repoe o estado desta localização ao valor inicial.
     *
     * <p>Chamado pelo {@link GameEngine#clearProgressOnRespawn(model.Player)}
     * quando o jogador morre e faz respawn. Após o reset:</p>
     * <ul>
     *   <li>A sala já não é considerada visitada — entrar nela não custa HP</li>
     *   <li>O enigma volta a estar pendente — o jogador terá de o resolver novamente</li>
     *   <li>O tipo de evento atribuído é limpo — um novo roll será feito
     *       quando o jogador entrar novamente na sala</li>
     * </ul>
     *
     * <p><b>Não</b> apaga o histórial de movimento do {@link model.Player} nem
     * os dados do relatório final — esses são mantidos separadamente.</p>
     */
    public void reset() {
        this.visited           = false;
        this.enigmaResolved    = false;
        this.assignedEventType = null;
    }

    @Override
    public String toString() {
        return String.format("[visitada=%b | enigma=%s | evento=%s]",
            visited,
            enigmaResolved ? "resolvido" : "pendente",
            assignedEventType != null ? assignedEventType.name() : "n/a");
    }
}
