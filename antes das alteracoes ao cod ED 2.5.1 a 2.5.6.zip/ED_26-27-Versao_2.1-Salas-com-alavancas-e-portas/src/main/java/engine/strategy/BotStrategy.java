package engine.strategy;

import model.Enigma;
import model.GameMap;
import model.Location;
import model.Player;

/**
 * Estratégia de decisão de um jogador automático (bot).
 *
 * <p>Cada implementação define:</p>
 * <ul>
 *   <li>{@link #chooseNextLocation} — para onde o bot se move</li>
 *   <li>{@link #solveEnigma}        — como o bot responde a enigmas</li>
 * </ul>
 *
 * <p>O comportamento diferencia os bots em termos de dificuldade:</p>
 * <ul>
 *   <li>{@link RandomBot}   — move-se aleatoriamente, nunca acerta enigmas</li>
 *   <li>{@link HybridBot}   — move-se de forma inteligente, acerta enigmas 70% das vezes</li>
 *   <li>{@link DijkstraBot} — usa Dijkstra para o caminho óptimo e resolve sempre enigmas</li>
 * </ul>
 */
public interface BotStrategy {

    /**
     * Escolhe a próxima localização para o bot se mover.
     *
     * @param player    jogador bot que vai mover
     * @param map       mapa do jogo
     * @param objective localização objetivo
     * @return próxima localização, ou {@code null} se não houver movimento possível
     */
    Location chooseNextLocation(Player player, GameMap map, Location objective);

    /**
     * Devolve a resposta do bot a um enigma.
     *
     * <p>Cada implementação define o comportamento:</p>
     * <ul>
     *   <li>{@link RandomBot}   — devolve sempre {@code "???"} (nunca acerta)</li>
     *   <li>{@link HybridBot}   — devolve a resposta correta com 70% de probabilidade</li>
     *   <li>{@link DijkstraBot} — devolve sempre {@code enigma.getAnswer()} (omnisciente)</li>
     * </ul>
     *
     * <p>O método default devolve {@code null} para garantir compatibilidade
     * com implementações anteriores à adição deste método.</p>
     *
     * @param enigma enigma a resolver
     * @return resposta do bot (pode ser incorreta)
     */
    default String solveEnigma(Enigma enigma) {
        return null;
    }
}
