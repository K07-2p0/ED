package engine.strategy;

import model.Enigma;
import model.GameMap;
import model.Location;
import model.Player;
import Lists.ListADT;
import engine.SimpleRandom;

/**
 * Bot que se move aleatoriamente pelo mapa e resolve enigmas com 50% de probabilidade.
 *
 * <p>Em cada turno escolhe um vizinho aleatório da localização atual.
 * Para enigmas, tem 50% de hipótese de acertar — representa um bot
 * que "chuta" com sorte média.</p>
 *
 * <p>Para testes determinísticos usa o construtor {@link #RandomBot(long)}
 * com uma seed fixa.</p>
 */
public class RandomBot implements BotStrategy {

    private final SimpleRandom random;

    /**
     * Construtor padrão com seed aleatória.
     */
    public RandomBot() {
        this.random = new SimpleRandom();
    }

    /**
     * Construtor com seed fixa — útil para testes determinísticos.
     *
     * @param seed seed do gerador de números aleatórios
     */
    public RandomBot(long seed) {
        this.random = new SimpleRandom(seed);
    }

    /**
     * Escolhe um vizinho aleatório da localização atual.
     *
     * @param player    jogador bot
     * @param map       mapa do jogo
     * @param objective destino final (ignorado por este bot)
     * @return vizinho aleatório, ou {@code null} se não houver vizinhos
     */
    @Override
    public Location chooseNextLocation(Player player, GameMap map, Location objective) {
        ListADT<Location> neighbors = map.getNeighbors(player.getCurrentLocation());
        if (neighbors.isEmpty()) return null;
        int target = random.nextInt(neighbors.size());
        int idx    = 0;
        for (Location n : neighbors) {
            if (idx++ == target) return n;
        }
        return null;
    }

    /**
     * O RandomBot tem 50% de hipótese de acertar no enigma.
     * Representa um bot que "chuta" — às vezes tem sorte, às vezes não.
     *
     * @param enigma enigma a resolver
     * @return resposta correta (50%) ou {@code "???"} (50%)
     */
    @Override
    public String solveEnigma(Enigma enigma) {
        return random.nextDouble() < 0.50
            ? enigma.getAnswer()
            : "???";
    }
}
