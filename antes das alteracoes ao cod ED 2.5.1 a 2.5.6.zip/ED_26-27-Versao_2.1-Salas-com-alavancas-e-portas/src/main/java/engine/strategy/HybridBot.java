package engine.strategy;

import model.Enigma;
import model.GameMap;
import model.Location;
import model.Player;
import Lists.ListADT;
import engine.SimpleRandom;

/**
 * Bot híbrido: usa Dijkstra com probabilidade de 70%, caso contrário
 * escolhe um vizinho aleatório. Para enigmas, acerta com 70% de probabilidade.
 *
 * <p>Simula um jogador que “quase sempre” sabe o que está a fazer mas
 * comete erros ocasionais — nível de dificuldade médio.</p>
 */
public class HybridBot implements BotStrategy {

    private static final double SMART_PROBABILITY  = 0.70;
    private static final double ENIGMA_PROBABILITY = 0.70;
    private final SimpleRandom random = new SimpleRandom();

    /**
     * Escolhe a próxima localização com lógica híbrida:
     * 70% Dijkstra (caminho óptimo), 30% vizinho aleatório.
     *
     * @param player    jogador bot
     * @param map       mapa do jogo
     * @param objective destino final
     * @return próxima localização
     */
    @Override
    public Location chooseNextLocation(Player player, GameMap map, Location objective) {
        Location current = player.getCurrentLocation();

        if (random.nextDouble() < SMART_PROBABILITY) {
            ListADT<Location> path = map.shortestPath(current, objective);
            if (!path.isEmpty()) {
                int i = 0;
                for (Location loc : path) {
                    if (i == 1) return loc;
                    i++;
                }
            }
        }

        // Aleatório
        ListADT<Location> neighbors = map.getNeighbors(current);
        if (neighbors.isEmpty()) return null;
        int target = random.nextInt(neighbors.size());
        int idx    = 0;
        for (Location n : neighbors) {
            if (idx++ == target) return n;
        }
        return null;
    }

    /**
     * O HybridBot acerta no enigma com 70% de probabilidade.
     * Nos restantes 30% devolve {@code "???"} (resposta inválida).
     *
     * @param enigma enigma a resolver
     * @return resposta correta ou {@code "???"}
     */
    @Override
    public String solveEnigma(Enigma enigma) {
        return random.nextDouble() < ENIGMA_PROBABILITY
            ? enigma.getAnswer()
            : "???";
    }
}
