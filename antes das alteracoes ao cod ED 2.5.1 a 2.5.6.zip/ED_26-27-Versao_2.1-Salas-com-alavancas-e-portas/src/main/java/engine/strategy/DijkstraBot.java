package engine.strategy;

import model.Enigma;
import model.GameMap;
import model.Location;
import model.Player;
import Lists.ListADT;

/**
 * Bot que usa Dijkstra para calcular o caminho óptimo até ao objetivo.
 *
 * <p>Em cada turno pede ao {@link GameMap#shortestPath(Location, Location)}
 * o caminho mínimo e segue o primeiro passo. Se o caminho estiver vazio
 * (objetivo inatingível) cai no comportamento do {@link RandomBot}.</p>
 *
 * <p>Para enigmas, o DijkstraBot é <b>omnisciente</b>: devolve sempre
 * a resposta correta via {@link Enigma#getAnswer()}.</p>
 */
public class DijkstraBot implements BotStrategy {

    /**
     * Escolhe o primeiro passo do caminho mínimo até ao objetivo.
     *
     * @param player    jogador bot
     * @param map       mapa do jogo
     * @param objective destino final
     * @return próxima localização no caminho óptimo, ou aleatória se indisponível
     */
    @Override
    public Location chooseNextLocation(Player player, GameMap map, Location objective) {
        Location current = player.getCurrentLocation();
        ListADT<Location> path = map.shortestPath(current, objective);

        if (!path.isEmpty()) {
            // path[0] é o nó atual; o próximo passo é path[1] se existir
            int i = 0;
            for (Location loc : path) {
                if (i == 1) return loc;
                i++;
            }
        }

        // Fallback: vizinho aleatório (caminhos partilhados com RandomBot)
        ListADT<Location> neighbors = map.getNeighbors(current);
        if (neighbors.isEmpty()) return null;
        return neighbors.iterator().next();
    }

    /**
     * O DijkstraBot é omnisciente: devolve sempre a resposta correta.
     *
     * @param enigma enigma a resolver
     * @return resposta correta do enigma
     */
    @Override
    public String solveEnigma(Enigma enigma) {
        return enigma.getAnswer();
    }
}
