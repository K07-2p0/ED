package engine;

import Exceptions.EmptyCollectionException;
import Lists.DoublyLinkedList;
import Lists.ListADT;
import model.Enigma;
import model.EventType;
import model.Event;
import model.Player;

/**
 * Gere a seleção aleatória de eventos do tipo {@link EventType#ENIGMA}
 * por nível de dificuldade, com isolamento por jogador para garantir
 * que dois jogadores nunca respondem ao mesmo enigma na mesma sala
 * na mesma partida.
 *
 * <h2>Mudança face à versão anterior</h2>
 * <p>O pool aceita agora {@code ListADT<Event>} em vez de
 * {@code ListADT<Enigma>}, filtrando apenas os eventos com
 * {@code type == ENIGMA} quando necessário. A API pública permanece
 * compatível — os métodos devolvem {@link Enigma} (downcast seguro
 * garantido pela filtragem interna).</p>
 *
 * <h2>Regras de seleção</h2>
 * <ol>
 *   <li>Ao entrar numa sala com {@code dangerLevel = N}, o engine pede
 *       {@link #pickFor(Player, String, int)} com esse nível.</li>
 *   <li>O pool filtra todos os eventos com
 *       {@code type == ENIGMA && dangerLevel == N}.</li>
 *   <li>De entre esses, exclui os já atribuídos a <em>outros</em>
 *       jogadores para a <b>mesma sala</b> (chave {@code locationId}).</li>
 *   <li>Escolhe um aleatoriamente dos restantes.</li>
 *   <li>Se todos já tiverem sido usados, recai sobre qualquer enigma do
 *       mesmo nível (repetição preferível a ausência).</li>
 *   <li>O enigma escolhido é registado como "em uso" para esse par
 *       {@code (locationId, enigma.id)}.</li>
 * </ol>
 *
 * <h2>Histórico por jogador</h2>
 * <p>O histórico é por par {@code (playerId, locationId)}. Ao morrer,
 * {@link engine.GameEngine#clearProgressOnRespawn(Player)} chama
 * {@link #clearPlayerHistory(Player)}, limpando o histórico para que
 * o jogador receba um novo enigma ao revisitar a sala.</p>
 *
 * <h2>Sem coleções nativas</h2>
 * <p>Toda a gestão interna usa {@link DoublyLinkedList} da API_ED.
 * O método {@code clear()} não existe na API_ED, por isso a limpeza
 * é feita com {@link #drainList(DoublyLinkedList)}.</p>
 */
public class EnigmaPool {

    /** Lista completa de eventos (qualquer tipo) carregados do JSON. */
    private final ListADT<Event>                       allEvents;
    private final SimpleRandom                          rng;

    /**
     * Registo: para cada par {@code (locationId, enigmaId)}, quais os
     * jogadores a quem já foi atribuído.
     */
    private final DoublyLinkedList<AssignmentEntry>     assignments;

    /**
     * Cache: para cada chave {@code "playerId:locationId"}, qual o enigma
     * já atribuído (para reutilizar na mesma visita sem re-sortear).
     */
    private final DoublyLinkedList<PlayerLocationEntry> playerCache;

    // ── Construtor ─────────────────────────────────────────────────────────

    /**
     * Cria o pool com a lista completa de eventos carregados do JSON.
     *
     * <p>Aceita {@code ListADT<Event>} — apenas os eventos com
     * {@code type == ENIGMA} serão utilizados pelo pool; os restantes
     * (ALAVANCA, RAPTO) são ignorados silenciosamente.</p>
     *
     * @param allEvents lista de todos os eventos disponíveis
     */
    public EnigmaPool(ListADT<Event> allEvents) {
        this.allEvents   = allEvents;
        this.rng         = new SimpleRandom();
        this.assignments = new DoublyLinkedList<>();
        this.playerCache = new DoublyLinkedList<>();
    }


    // ── API pública ────────────────────────────────────────────────────────

    /**
     * Seleciona (ou reutiliza) o enigma a apresentar ao jogador para uma sala.
     *
     * <p>Filtra apenas eventos com {@code type == ENIGMA}. Se o jogador já
     * recebeu um enigma para esta sala nesta vida, devolve o mesmo.
     * Caso contrário sorteia um novo, garantindo que é diferente dos
     * atribuídos a outros jogadores para a mesma sala.</p>
     *
     * @param player      jogador que entra na sala
     * @param locationId  id da sala
     * @param dangerLevel nível de dificuldade da sala
     * @return enigma selecionado, ou {@code null} se não existir nenhum
     *         do tipo ENIGMA para esse nível
     */
    public Enigma pickFor(Player player, String locationId, int dangerLevel) {
        String cacheKey = player.getId() + ":" + locationId;

        // Reutiliza enigma já atribuído nesta vida
        for (PlayerLocationEntry e : playerCache) {
            if (e.key.equals(cacheKey)) return e.enigma;
        }

        // Filtra eventos do tipo ENIGMA com o nível correto
        DoublyLinkedList<Enigma> candidates = filterEnigmasByLevel(dangerLevel);
        if (candidates.isEmpty()) return null;

        // Exclui os já usados por outros jogadores nesta sala
        DoublyLinkedList<Enigma> preferred = excludeUsedInRoom(candidates, locationId, player.getId());

        // Se pool esgotado, usa todos os do nível (com repetição aceitável)
        DoublyLinkedList<Enigma> pool = preferred.isEmpty() ? candidates : preferred;

        Enigma chosen = pickRandom(pool);

        // Regista atribuição
        registerAssignment(locationId, chosen.getId(), player.getId());
        playerCache.addLast(new PlayerLocationEntry(cacheKey, chosen));

        return chosen;
    }

    /**
     * Limpa o histórico de enigmas atribuídos a um jogador (chamado no respawn).
     *
     * <p>O jogador voltará a receber um enigma (possivelmente diferente)
     * ao revisitar salas após renascer.</p>
     *
     * @param player jogador cujo histórico deve ser limpo
     */
    public void clearPlayerHistory(Player player) {
        String prefix = player.getId() + ":";
        DoublyLinkedList<PlayerLocationEntry> toKeep = new DoublyLinkedList<>();
        for (PlayerLocationEntry e : playerCache) {
            if (!e.key.startsWith(prefix)) {
                toKeep.addLast(e);
            }
        }

        drainList(playerCache);

        for (PlayerLocationEntry e : toKeep) {
            playerCache.addLast(e);
        }

        // Limpa também os registos de assignment onde este jogador aparecia
        for (AssignmentEntry ae : assignments) {
            ae.removePlayer(player.getId());
        }
    }

    // ── Helpers privados ──────────────────────────────────────────────────

    /**
     * Remove todos os elementos de uma {@link DoublyLinkedList} um a um.
     *
     * @param <T>  tipo dos elementos
     * @param list lista a esvaziar
     */
    private static <T> void drainList(DoublyLinkedList<T> list) {
        try {
            while (!list.isEmpty()) {
                list.removeFirst();
            }
        } catch (EmptyCollectionException e) {
            // Guard isEmpty() torna isto improvável; tratado por segurança
        }
    }

    /**
     * Filtra os eventos da lista global pelo tipo {@link EventType#ENIGMA}
     * e pelo nível de dificuldade indicado.
     *
     * <p>O downcast para {@link Enigma} é seguro porque o filtro de tipo
     * garante que apenas eventos {@code ENIGMA} chegam aqui.</p>
     *
     * @param dangerLevel nível alvo
     * @return lista de {@link Enigma} com esse nível
     */
    private DoublyLinkedList<Enigma> filterEnigmasByLevel(int dangerLevel) {
        DoublyLinkedList<Enigma> result = new DoublyLinkedList<>();
        for (Event ev : allEvents) {
            if (ev.getType() == EventType.ENIGMA && ev.getDangerLevel() == dangerLevel) {
                result.addLast((Enigma) ev);
            }
        }
        return result;
    }

    /**
     * Exclui da lista os enigmas já usados por outros jogadores nesta sala.
     *
     * @param candidates  lista inicial de candidatos
     * @param locationId  id da sala
     * @param currentPId  id do jogador atual
     * @return lista filtrada
     */
    private DoublyLinkedList<Enigma> excludeUsedInRoom(
            DoublyLinkedList<Enigma> candidates, String locationId, String currentPId) {

        DoublyLinkedList<String> usedEnigmaIds = getUsedEnigmaIds(locationId, currentPId);
        DoublyLinkedList<Enigma> result = new DoublyLinkedList<>();
        for (Enigma e : candidates) {
            if (!contains(usedEnigmaIds, e.getId())) result.addLast(e);
        }
        return result;
    }

    /**
     * Devolve os ids de enigmas já atribuídos a outros jogadores para uma sala.
     *
     * @param locationId id da sala
     * @param excludePId id do jogador a ignorar (o atual)
     * @return lista de ids de enigmas já usados na sala por outros jogadores
     */
    private DoublyLinkedList<String> getUsedEnigmaIds(String locationId, String excludePId) {
        DoublyLinkedList<String> usedIds = new DoublyLinkedList<>();
        for (AssignmentEntry ae : assignments) {
            if (ae.locationId.equals(locationId) && ae.hasOtherPlayer(excludePId)) {
                usedIds.addLast(ae.enigmaId);
            }
        }
        return usedIds;
    }

    /**
     * Regista que um enigma foi atribuído a um jogador para uma sala.
     *
     * @param locationId id da sala
     * @param enigmaId   id do enigma
     * @param playerId   id do jogador
     */
    private void registerAssignment(String locationId, String enigmaId, String playerId) {
        for (AssignmentEntry ae : assignments) {
            if (ae.locationId.equals(locationId) && ae.enigmaId.equals(enigmaId)) {
                ae.addPlayer(playerId);
                return;
            }
        }
        AssignmentEntry ae = new AssignmentEntry(locationId, enigmaId);
        ae.addPlayer(playerId);
        assignments.addLast(ae);
    }

    /**
     * Escolhe aleatoriamente um elemento de uma lista.
     *
     * @param list lista não vazia
     * @return elemento aleatório
     */
    private Enigma pickRandom(DoublyLinkedList<Enigma> list) {
        int index = rng.nextInt(list.size());
        int i = 0;
        for (Enigma e : list) {
            if (i == index) return e;
            i++;
        }
        return null;
    }

    /**
     * Verifica se uma lista de Strings contém um valor.
     *
     * @param list  lista a pesquisar
     * @param value valor a procurar
     * @return {@code true} se encontrado
     */
    private boolean contains(DoublyLinkedList<String> list, String value) {
        for (String s : list) {
            if (s.equals(value)) return true;
        }
        return false;
    }

    // ── Classes internas de dados ──────────────────────────────────────────

    /**
     * Associação entre uma sala, um enigma e os jogadores a quem foi atribuído.
     */
    private static class AssignmentEntry {
        final String locationId;
        final String enigmaId;
        final DoublyLinkedList<String> playerIds;

        AssignmentEntry(String locationId, String enigmaId) {
            this.locationId = locationId;
            this.enigmaId   = enigmaId;
            this.playerIds  = new DoublyLinkedList<>();
        }

        void addPlayer(String playerId) {
            for (String pid : playerIds) {
                if (pid.equals(playerId)) return;
            }
            playerIds.addLast(playerId);
        }

        /**
         * Remove um jogador da lista de atribuições.
         *
         * @param playerId id do jogador a remover
         */
        void removePlayer(String playerId) {
            DoublyLinkedList<String> remaining = new DoublyLinkedList<>();
            for (String pid : playerIds) {
                if (!pid.equals(playerId)) remaining.addLast(pid);
            }
            drainList(playerIds);
            for (String pid : remaining) playerIds.addLast(pid);
        }

        /** @return {@code true} se houver pelo menos um jogador diferente de {@code excludePId} */
        boolean hasOtherPlayer(String excludePId) {
            for (String pid : playerIds) {
                if (!pid.equals(excludePId)) return true;
            }
            return false;
        }
    }

    /**
     * Cache de enigma atribuído a um par (jogador, sala).
     */
    private static class PlayerLocationEntry {
        final String key;     // "playerId:locationId"
        final Enigma enigma;

        PlayerLocationEntry(String key, Enigma enigma) {
            this.key    = key;
            this.enigma = enigma;
        }
    }
}
