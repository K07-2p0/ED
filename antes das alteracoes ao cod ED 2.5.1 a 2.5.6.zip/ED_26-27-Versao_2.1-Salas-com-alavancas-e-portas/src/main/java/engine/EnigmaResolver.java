package engine;

import model.Enigma;

/**
 * Valida respostas a enigmas durante o jogo.
 *
 * <p>Delega a comparação para {@link Enigma#isCorrect(String)},
 * que já normaliza maiúsculas/minúsculas e espaços.</p>
 *
 * <p>O {@code GameEngine} chama este resolver quando o jogador
 * entra numa {@link model.Location} com {@code enigmaId} não nulo
 * e o enigma ainda não foi resolvido (verificado via
 * {@code LocationState} externo ao modelo).</p>
 */
public class EnigmaResolver {

    /**
     * Construtor padrão.
     */
    public EnigmaResolver() {}

    /**
     * Verifica se a resposta do jogador resolve o enigma.
     *
     * @param enigma       enigma a resolver
     * @param playerAnswer resposta fornecida pelo jogador
     * @return resultado da tentativa
     */
    public EnigmaResult resolve(Enigma enigma, String playerAnswer) {
        boolean correct = enigma.isCorrect(playerAnswer);
        return new EnigmaResult(enigma.getId(), correct,
            correct ? null : (enigma.hasHint() ? enigma.getHint() : null));
    }

    // ── Classe interna de resultado ──────────────────────────────────────────

    /**
     * Resultado de uma tentativa de resolução de enigma.
     */
    public static class EnigmaResult {

        private final String  enigmaId;
        private final boolean correct;
        private final String  hint;   // null se correto ou sem dica

        /**
         * Cria um resultado de tentativa.
         *
         * @param enigmaId id do enigma
         * @param correct  {@code true} se a resposta foi correta
         * @param hint     dica a mostrar em caso de erro, ou {@code null}
         */
        public EnigmaResult(String enigmaId, boolean correct, String hint) {
            this.enigmaId = enigmaId;
            this.correct  = correct;
            this.hint     = hint;
        }

        /** @return id do enigma */
        public String  getEnigmaId() { return enigmaId; }

        /** @return {@code true} se a resposta foi correta */
        public boolean isCorrect()   { return correct; }

        /** @return dica ou {@code null} */
        public String  getHint()     { return hint; }

        /** @return {@code true} se há dica disponível */
        public boolean hasHint()     { return hint != null; }

        @Override
        public String toString() {
            if (correct) return "✅ Enigma resolvido!";
            return hasHint() ? "❌ Errado. Dica: " + hint : "❌ Errado.";
        }
    }
}
