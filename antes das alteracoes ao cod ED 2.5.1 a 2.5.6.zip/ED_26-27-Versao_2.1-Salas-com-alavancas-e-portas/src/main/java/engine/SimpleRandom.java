package engine;

/**
 * Gerador de números pseudo-aleatórios com seed configurável.
 *
 * <p>Substitui {@code java.util.Random} em toda a lógica de jogo,
 * garantindo reprodutibilidade e evitando o uso directo de coleções
 * nativas do Java.</p>
 *
 * <p>Implementa um <b>Linear Congruential Generator</b> (LCG) com os
 * mesmos parâmetros de {@code java.util.Random}:
 * {@code seed = (seed * 0x5DEECE66DL + 0xBL) & ((1L << 48) - 1)}.</p>
 *
 * <h2>Uso típico</h2>
 * <pre>{@code
 * SimpleRandom rng = new SimpleRandom(42L);
 * int dice = rng.nextInt(6);     // 0..5
 * double p = rng.nextDouble();   // 0.0..1.0
 * }</pre>
 */
public class SimpleRandom {

    /** Máscara de 48 bits. */
    private static final long MASK       = (1L << 48) - 1;
    private static final long MULTIPLIER = 0x5DEECE66DL;
    private static final long INCREMENT  = 0xBL;

    /** Estado interno do gerador (48 bits). */
    private long seed;

    // ── Construtores ────────────────────────────────────────────────────

    /**
     * Cria um gerador com seed explícita (reprodutível).
     *
     * @param seed seed inicial
     */
    public SimpleRandom(long seed) {
        this.seed = (seed ^ MULTIPLIER) & MASK;
    }

    /**
     * Cria um gerador com seed baseada no tempo atual (não reprodutível).
     */
    public SimpleRandom() {
        this(System.nanoTime());
    }

    // ── API pública ─────────────────────────────────────────────────────

    /**
     * Gera os próximos {@code bits} bits aleatórios.
     *
     * @param bits número de bits (1–32)
     * @return valor aleatório com {@code bits} bits
     */
    private int next(int bits) {
        seed = (seed * MULTIPLIER + INCREMENT) & MASK;
        return (int) (seed >>> (48 - bits));
    }

    /**
     * Gera um inteiro aleatório em {@code [0, bound)}.
     *
     * @param bound limite superior exclusivo (deve ser positivo)
     * @return inteiro aleatório em [0, bound)
     * @throws IllegalArgumentException se {@code bound <= 0}
     */
    public int nextInt(int bound) {
        if (bound <= 0) throw new IllegalArgumentException("bound deve ser positivo: " + bound);

        // Potência de 2 — atalho rápido
        if ((bound & (bound - 1)) == 0) {
            return (int) ((bound * (long) next(31)) >> 31);
        }

        // Caso geral — rejeita valores com enviesamento
        int bits, val;
        do {
            bits = next(31);
            val  = bits % bound;
        } while (bits - val + (bound - 1) < 0);
        return val;
    }

    /**
     * Gera um double aleatório em {@code [0.0, 1.0)}.
     *
     * @return valor double em [0.0, 1.0)
     */
    public double nextDouble() {
        return (((long) next(26) << 27) + next(27)) / (double) (1L << 53);
    }

    /**
     * Gera um boolean aleatório.
     *
     * @return {@code true} ou {@code false} com probabilidade ~50%
     */
    public boolean nextBoolean() {
        return next(1) != 0;
    }
}
