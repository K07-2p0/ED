package io;

import Lists.DoublyLinkedList;
import model.Enigma;
import model.Event;
import model.LeverEvent;
import model.Location;
import model.Location.LocationRole;
import model.GameMap;
import model.ShortcutEdge;
import engine.SimpleRandom;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * Carrega um {@link GameMap} a partir de um ficheiro JSON.
 *
 * <p>O ficheiro descreve as salas (vértices) e as ligações (arestas) do mapa.
 * O campo {@code "enigmaId"} nas salas é ignorado — a seleção de enigmas é
 * feita pela {@link engine.EnigmaPool} com base no {@code dangerLevel}.</p>
 *
 * <h2>Retrocompatibilidade de roles</h2>
 * <p>Os valores antigos ({@code "ENTRY"}, {@code "INTERMEDIATE"}, {@code "GOAL"})
 * e os novos ({@code "SPAWN"}, {@code "DUNGEON"}, {@code "ENDGAME"}) são
 * aceites simultaneamente. Ficheiros JSON antigos funcionam sem alterações.</p>
 *
 * <h2>Estrutura esperada do JSON</h2>
 * <pre>{@code
 * {
 *   "name": "...",
 *   "biome_types": ["desert", "nether", "ice_plains"],
 *   "locations": [
 *     {
 *       "id": "desert",
 *       "name": "Desert",
 *       "role": "SPAWN",
 *       "dangerLevel": 0,
 *       "biome": "desert",
 *       "color": "#F5D76E",
 *       "description": "...",
 *       "icon": "🏜️",
 *       "mapX": 0.10,
 *       "mapY": 0.10
 *     }
 *   ],
 *   "edges": [
 *     { "from": "desert", "to": "desert_village", "weight": 2.0 }
 *   ]
 * }
 * }</pre>
 */
public class MapLoader {

    /** Construtor privado — classe utilitária, não instanciável. */
    private MapLoader() {}

    /**
     * Lê um ficheiro JSON e devolve um {@link GameMap} construído.
     *
     * @param resourcePath caminho do ficheiro (ex: {@code "maps/map_default.json"})
     * @return mapa carregado
     */
    public static GameMap load(String resourcePath) {
        GameMap map = new GameMap();
        load(resourcePath, map);
        return map;
    }

    /**
     * Lê um ficheiro JSON e preenche o {@link GameMap} fornecido.
     * Sobrecarga que aceita um mapa já criado externamente.
     *
     * @param resourcePath caminho do ficheiro
     * @param map          mapa a preencher
     */
    public static void load(String resourcePath, GameMap map) {
        String     content = readFile(resourcePath);
        JSONObject root    = new JSONObject(content);

        JSONArray locations = root.getJSONArray("locations");
        for (int i = 0; i < locations.length(); i++) {
            JSONObject obj = locations.getJSONObject(i);

            String id          = obj.getString("id");
            String name        = obj.getString("name");
            int    dangerLevel = obj.optInt("dangerLevel", 0);
            String icon        = obj.optString("icon", "🗺️");
            String description = obj.optString("description", "");
            double mapX        = obj.optDouble("mapX", 0.5);
            double mapY        = obj.optDouble("mapY", 0.5);
            String color       = obj.optString("color", null);
            String biome       = obj.optString("biome", null);
            // "enigmaId" is intentionally ignored — selection is done by EnigmaPool
            // "type" and "roomTheme" are no longer read — removed in Phase A1

            // Aceita tanto os nomes novos (SPAWN, DUNGEON, ENDGAME) como os
            // antigos (ENTRY, INTERMEDIATE, GOAL) para retrocompatibilidade.
            LocationRole role = LocationRole.DUNGEON;
            if (obj.has("role")) {
                String roleStr = obj.getString("role");
                role = switch (roleStr) {
                    case "SPAWN",   "ENTRY"        -> LocationRole.SPAWN;
                    case "DUNGEON", "INTERMEDIATE" -> LocationRole.DUNGEON;
                    case "ENDGAME", "GOAL"         -> LocationRole.ENDGAME;
                    case "LEVER_ROOM"              -> LocationRole.LEVER_ROOM;
                    default                        -> LocationRole.DUNGEON;
                };
            }

            Location location = new Location(
                id, name, role,
                dangerLevel, description, icon,
                mapX, mapY,
                color, biome
            );
            map.addLocation(location);
        }

        JSONArray edges = root.optJSONArray("edges");
        if (edges != null) {
            for (int i = 0; i < edges.length(); i++) {
                JSONObject edge = edges.getJSONObject(i);
                String from   = edge.getString("from");
                String to     = edge.getString("to");
                double weight = edge.optDouble("weight", 1.0);
                try {
                    Location locFrom = map.getById(from);
                    Location locTo   = map.getById(to);
                    map.addEdge(locFrom, locTo, weight);
                } catch (IllegalArgumentException e) {
                    System.err.println("[MapLoader] Aresta ignorada — ID não encontrado: "
                        + from + " -> " + to + " (" + e.getMessage() + ")");
                }
            }
        }

        // biome_types opcionais — usados pelo renderer para selecionar fundos
        JSONArray biomeTypes = root.optJSONArray("biome_types");
        if (biomeTypes != null) {
            map.setBiomeTypes(biomeTypes);
        }
    }

    // ── Geração de atalhos ─────────────────────────────────────────────

    /**
     * Gera atalhos entre salas de {@code dangerLevel == 2} e as salas
     * de {@code dangerLevel == 4} mais próximas.
     *
     * <h2>Algoritmo</h2>
     * <ol>
     *   <li>Recolhe todos os pares nível-2 → nível-4 mais próximos.</li>
     *   <li>Guarda-os numa lista temporária com {@code visible=false}.</li>
     *   <li>Embaralha os índices com Fisher-Yates ({@link SimpleRandom})
     *       e marca exatamente {@code total/2} atalhos como visíveis.</li>
     *   <li>Só os atalhos visíveis são adicionados ao grafo
     *       (peso {@code 0.1}); os invisíveis não existem como caminho
     *       jogável.</li>
     *   <li>Cada atalho visível recebe aleatoriamente um {@link LeverEvent}
     *       ou um {@link Enigma}; os invisíveis ficam com {@code event=null}.</li>
     * </ol>
     *
     * <p>O array {@code int[]} utilizado internamente para o shuffle é
     * uma estrutura algorítmica temporária, não uma coleção de dados
     * do jogo — o seu uso é permitido pelas regras do projeto.</p>
     *
     * <p>Se não existirem salas de nível 2 ou nível 4, devolve uma
     * lista vazia sem alterações ao mapa.</p>
     *
     * @param map  mapa carregado
     * @param seed seed para o gerador aleatório (garante reprodutibilidade)
     * @return lista de todos os atalhos gerados (visíveis e invisíveis)
     */
    public static DoublyLinkedList<ShortcutEdge> generateShortcuts(GameMap map, long seed) {
        SimpleRandom rng = new SimpleRandom(seed);

        // ── Passo 1: recolher salas de nível 2 e nível 4 ────────────────
        DoublyLinkedList<Location> level2 = new DoublyLinkedList<>();
        DoublyLinkedList<Location> level4 = new DoublyLinkedList<>();

        for (Location loc : map.getAllLocations()) {
            if      (loc.getDangerLevel() == 2) level2.addLast(loc);
            else if (loc.getDangerLevel() == 4) level4.addLast(loc);
        }

        if (level2.isEmpty() || level4.isEmpty()) {
            return new DoublyLinkedList<>();
        }

        // ── Passo 2: gerar todos os pares (visible=false por omissão) ──
        DoublyLinkedList<Location> fromList = new DoublyLinkedList<>();
        DoublyLinkedList<Location> toList   = new DoublyLinkedList<>();

        for (Location from : level2) {
            Location nearest  = null;
            double   bestCost = Double.POSITIVE_INFINITY;

            for (Location to : level4) {
                double cost = map.shortestPathCost(from, to);
                if (cost < bestCost) {
                    bestCost = cost;
                    nearest  = to;
                }
            }

            if (nearest != null && !Double.isInfinite(bestCost)) {
                fromList.addLast(from);
                toList.addLast(nearest);
            }
        }

        int total = fromList.size();
        if (total == 0) return new DoublyLinkedList<>();

        // ── Passo 3: calcular metade exata ──────────────────────────────
        int half = total / 2;

        // ── Passo 4: Fisher-Yates sobre array de índices (int[] nativo) ─
        // int[] é uma estrutura algorítmica temporária, não uma coleção
        // de dados do jogo — o seu uso é explicitamente permitido.
        int[] indices = new int[total];
        for (int i = 0; i < total; i++) {
            indices[i] = i;
        }
        for (int i = total - 1; i > 0; i--) {
            int j      = rng.nextInt(i + 1);
            int tmp    = indices[i];
            indices[i] = indices[j];
            indices[j] = tmp;
        }

        // ── Passo 5: marcar os primeiros `half` como visíveis ─────────────
        boolean[] visible = new boolean[total];
        for (int i = 0; i < half; i++) {
            visible[indices[i]] = true;
        }

        // ── Passos 6-7: construir ShortcutEdge finais ────────────────────
        DoublyLinkedList<ShortcutEdge> shortcuts = new DoublyLinkedList<>();

        java.util.Iterator<Location> itFrom = fromList.iterator();
        java.util.Iterator<Location> itTo   = toList.iterator();

        for (int idx = 0; idx < total; idx++) {
            Location from  = itFrom.next();
            Location to    = itTo.next();
            boolean  isVis = visible[idx];

            Event event = null;
            if (isVis) {
                int dl = from.getDangerLevel();
                if (rng.nextBoolean()) {
                    event = new LeverEvent(
                            "sc_lever_" + from.getId(),
                            dl,
                            dl);
                } else {
                    event = new Enigma(
                            "sc_enigma_" + rng.nextInt(10000),
                            "Que preço tem a passagem?",
                            "livre",
                            null,
                            dl);
                }
                map.addEdge(from, to, 0.1);
            }

            String scId = "sc_" + from.getId() + "_to_" + to.getId();
            shortcuts.addLast(new ShortcutEdge(scId, from, to, isVis, event));
        }

        return shortcuts;
    }

    // ── Helpers ────────────────────────────────────────────────────

    private static String readFile(String path) {
        String cpPath = path.startsWith("/") ? path.substring(1) : path;
        InputStream is = MapLoader.class.getClassLoader().getResourceAsStream(cpPath);
        if (is != null) return readStream(is);

        is = MapLoader.class.getResourceAsStream(path.startsWith("/") ? path : "/" + path);
        if (is != null) return readStream(is);

        File f = new File("src/main/resources/" + cpPath);
        if (f.exists()) {
            try { return readStream(new FileInputStream(f)); }
            catch (Exception ignored) {}
        }

        f = new File(path);
        if (f.exists()) {
            try { return readStream(new FileInputStream(f)); }
            catch (Exception ignored) {}
        }

        throw new RuntimeException("Ficheiro de mapa não encontrado: " + path);
    }

    private static String readStream(InputStream is) {
        try {
            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new RuntimeException("Erro ao ler stream", e);
        }
    }
}
