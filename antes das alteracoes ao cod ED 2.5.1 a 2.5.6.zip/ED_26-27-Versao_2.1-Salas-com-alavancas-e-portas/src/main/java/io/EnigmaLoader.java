package io;

import Lists.ArrayUnorderedList;
import Lists.DoublyLinkedList;
import Lists.ListADT;
import Lists.UnorderedListADT;
import model.Enigma;
import model.Event;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * Carrega enigmas a partir de um ficheiro JSON.
 *
 * <h2>Estrutura esperada</h2>
 * <pre>{@code
 * [
 *   {
 *     "id": "e1",
 *     "question": "Qual é ...",
 *     "answer": "A",
 *     "hint": "Pensa ...",
 *     "dangerLevel": 1,
 *     "options": ["Opção A", "Opção B", "Opção C", "Opção D"]
 *   }
 * ]
 * }</pre>
 *
 * <p>O campo {@code "options"} é opcional — enigmas sem este campo
 * funcionam em modo legado (resposta por texto livre).</p>
 *
 * <p>Nenhuma coleção nativa do Java é usada nesta classe.
 * Todas as estruturas provêm da API_ED.</p>
 */
public class EnigmaLoader {

    /** Construtor privado — classe utilitária, não instanciável. */
    private EnigmaLoader() {}

    /**
     * Lê um ficheiro JSON de enigmas e devolve uma {@link ListADT} da API_ED.
     *
     * @param resourcePath caminho do ficheiro de enigmas
     * @return lista de enigmas carregados; lista vazia se o ficheiro não for encontrado
     */
    public static ListADT<Event> load(String resourcePath) {
        DoublyLinkedList<Event> result = new DoublyLinkedList<>();
        try {
            String content = readFile(resourcePath);
            JSONArray arr  = new JSONArray(content);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);

                String id          = obj.optString("id", "e" + i);
                String question    = obj.getString("question");
                String answer      = obj.getString("answer");
                String hint        = obj.optString("hint", null);
                int    dangerLevel = obj.optInt("dangerLevel", 1);

                // Lê opções (múltipla escolha) — usa ArrayUnorderedList da API_ED
                UnorderedListADT<String> options = new ArrayUnorderedList<>();
                if (obj.has("options")) {
                    JSONArray optsArr = obj.getJSONArray("options");
                    for (int j = 0; j < optsArr.length(); j++) {
                        options.addToRear(optsArr.getString(j));
                    }
                }

                Enigma enigma = new Enigma(id, question, answer, hint, dangerLevel, options);
                result.addLast(enigma);
            }
        } catch (RuntimeException e) {
            System.err.println("[EnigmaLoader] Ficheiro não encontrado ou inválido: "
                + resourcePath + " — " + e.getMessage());
        }
        return result;
    }

    // ── Helpers ──────────────────────────────────────────────────────────

    private static String readFile(String path) {
        String cpPath = path.startsWith("/") ? path.substring(1) : path;
        InputStream is = EnigmaLoader.class.getClassLoader().getResourceAsStream(cpPath);
        if (is != null) return readStream(is);

        is = EnigmaLoader.class.getResourceAsStream(path.startsWith("/") ? path : "/" + path);
        if (is != null) return readStream(is);

        File f = new File("src/main/resources/" + cpPath);
        if (f.exists()) {
            try { return readStream(new FileInputStream(f)); }
            catch (Exception ignored) {}
        }

        f = new File(path);
        if (f.exists()) {
            try { return readStream(new FileInputStream(f)); }
            catch (Exception ignored) {}
        }

        throw new RuntimeException("Ficheiro de enigmas não encontrado: " + path);
    }

    private static String readStream(InputStream is) {
        try {
            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new RuntimeException("Erro ao ler stream de enigmas", e);
        }
    }
}
