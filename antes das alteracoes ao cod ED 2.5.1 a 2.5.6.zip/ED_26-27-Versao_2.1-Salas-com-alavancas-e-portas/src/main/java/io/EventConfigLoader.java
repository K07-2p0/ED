package io;

import org.json.JSONObject;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * Lê o ficheiro {@code event_config.json} a partir do classpath e expõe os
 * valores de probabilidade como campos imutáveis.
 *
 * <h2>Filosofia</h2>
 * <p>Todos os valores de configuração de eventos estão centralizados neste
 * loader. O {@link engine.GameEngine} constrói uma instância no seu construtor
 * e substitui as antigas constantes {@code static final} por campos de
 * instância inicializados a partir daqui. Alterar o JSON tem efeito imediato
 * sem recompilar o código Java.</p>
 *
 * <h2>Caminho do recurso</h2>
 * <p>O ficheiro é carregado via {@code ClassLoader.getResourceAsStream}
 * com o caminho {@code "event_config.json"}. O Maven copia
 * {@code src/main/resources/} para o classpath, portanto o ficheiro está
 * disponível tanto em desenvolvimento como em JARs empacotados — sem
 * caminhos absolutos.</p>
 *
 * <h2>Valores padrão</h2>
 * <p>Se o ficheiro não for encontrado ou contiver um campo ausente, os
 * valores de fallback replicam o comportamento anterior ao bug:</p>
 * <ul>
 *   <li>{@code level1EnigmaChance}    = 1.00</li>
 *   <li>{@code level2PlusEnigmaChance}= 0.70</li>
 *   <li>{@code level2PlusLeverChance} = 0.30</li>
 *   <li>{@code kidnapFarChance}       = 0.90</li>
 *   <li>{@code kidnapNearChance}      = 0.10</li>
 *   <li>{@code doorsForDangerLevel2}  = 2</li>
 *   <li>{@code doorsForDangerLevel3}  = 3</li>
 *   <li>{@code doorsForDangerLevel4}  = 4</li>
 *   <li>{@code doorsForDangerLevel5}  = 4</li>
 *   <li>{@code thirdDoorEnigmaFromLevel} = 3</li>
 * </ul>
 */
public final class EventConfigLoader {

    // ── Probabilidades de evento por sala ────────────────────────────────

    /**
     * Probabilidade de enigma em salas DUNGEON de dangerLevel 1 (deve ser 1.0).
     */
    public final double level1EnigmaChance;

    /**
     * Probabilidade de enigma em salas DUNGEON de dangerLevel >= 2.
     */
    public final double level2PlusEnigmaChance;

    /**
     * Probabilidade de lever room em salas DUNGEON de dangerLevel >= 2.
     * Complementar a {@link #level2PlusEnigmaChance}.
     */
    public final double level2PlusLeverChance;

    // ── Probabilidades de rapto ──────────────────────────────────────────

    /**
     * Probabilidade de teleportar longe do objetivo num evento de rapto.
     */
    public final double kidnapFarChance;

    /**
     * Probabilidade de teleportar perto do objetivo num evento de rapto.
     */
    public final double kidnapNearChance;

    // ── Configuração de lever doors ──────────────────────────────────────

    /**
     * Número de portas para salas com dangerLevel 2.
     */
    public final int doorsForDangerLevel2;

    /**
     * Número de portas para salas com dangerLevel 3.
     */
    public final int doorsForDangerLevel3;

    /**
     * Número de portas para salas com dangerLevel 4.
     */
    public final int doorsForDangerLevel4;

    /**
     * Número de portas para salas com dangerLevel 5.
     */
    public final int doorsForDangerLevel5;

    /**
     * A partir deste dangerLevel, a terceira porta da lever room é um enigma.
     */
    public final int thirdDoorEnigmaFromLevel;

    // ── Construtor ───────────────────────────────────────────────────────

    /**
     * Carrega {@code event_config.json} do classpath.
     *
     * <p>Se o ficheiro não for encontrado ou ocorrer qualquer erro de
     * parsing, todos os campos ficam com os valores de fallback descritos
     * na documentação da classe. O erro é silenciado para não impedir o
     * arranque do jogo.</p>
     */
    public EventConfigLoader() {
        double l1e = 1.00, l2e = 0.70, l2l = 0.30;
        double kFar = 0.90, kNear = 0.10;
        int d2 = 2, d3 = 3, d4 = 4, d5 = 4, tdl = 3;

        try (InputStream is = EventConfigLoader.class
                .getClassLoader()
                .getResourceAsStream("event_config.json")) {

            if (is != null) {
                String raw = new String(is.readAllBytes(), StandardCharsets.UTF_8);
                JSONObject root = new JSONObject(raw);

                // room_events
                if (root.has("room_events")) {
                    JSONObject re = root.getJSONObject("room_events");
                    l1e  = re.optDouble("level_1_enigma_chance",       l1e);
                    l2e  = re.optDouble("level_2_plus_enigma_chance",  l2e);
                    l2l  = re.optDouble("level_2_plus_lever_chance",   l2l);
                }

                // consequence_events
                if (root.has("consequence_events")) {
                    JSONObject ce = root.getJSONObject("consequence_events");
                    kFar  = ce.optDouble("kidnap_far_chance",  kFar);
                    kNear = ce.optDouble("kidnap_near_chance", kNear);
                }

                // lever_doors
                if (root.has("lever_doors")) {
                    JSONObject ld = root.getJSONObject("lever_doors");
                    tdl = ld.optInt("third_door_is_enigma_from_level", tdl);
                    if (ld.has("doors_per_danger_level")) {
                        JSONObject dpd = ld.getJSONObject("doors_per_danger_level");
                        d2 = dpd.optInt("2", d2);
                        d3 = dpd.optInt("3", d3);
                        d4 = dpd.optInt("4", d4);
                        d5 = dpd.optInt("5", d5);
                    }
                }
            }
        } catch (Exception ignored) {
            // Fallback silencioso — valores padrão mantêm-se
        }

        this.level1EnigmaChance       = l1e;
        this.level2PlusEnigmaChance   = l2e;
        this.level2PlusLeverChance    = l2l;
        this.kidnapFarChance          = kFar;
        this.kidnapNearChance         = kNear;
        this.doorsForDangerLevel2     = d2;
        this.doorsForDangerLevel3     = d3;
        this.doorsForDangerLevel4     = d4;
        this.doorsForDangerLevel5     = d5;
        this.thirdDoorEnigmaFromLevel = tdl;
    }

    // ── Utilitário ───────────────────────────────────────────────────────

    /**
     * Devolve o número de portas configurado para um dado dangerLevel.
     *
     * <p>Se o dangerLevel estiver fora do intervalo [2, 5], devolve 2
     * como valor seguro.</p>
     *
     * @param dangerLevel nível de perigo da sala
     * @return número de portas
     */
    public int doorsFor(int dangerLevel) {
        switch (dangerLevel) {
            case 2: return doorsForDangerLevel2;
            case 3: return doorsForDangerLevel3;
            case 4: return doorsForDangerLevel4;
            case 5: return doorsForDangerLevel5;
            default: return 2;
        }
    }
}
