package io;

import model.GameMap;
import model.Location;
import Lists.DoublyLinkedList;
import Lists.ListADT;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.FileWriter;
import java.io.IOException;

/**
 * Serializa um {@link GameMap} para um ficheiro JSON.
 *
 * <p>Usado pelo Map Editor para guardar mapas criados ou editados
 * pelo utilizador. O formato gerado é compatível com o lido pelo
 * {@link MapLoader}.</p>
 *
 * <p>Para evitar gravar a mesma aresta duas vezes (A→B e B→A),
 * usa uma {@link DoublyLinkedList}{@code <String>} de chaves
 * no formato {@code "minId_maxId"} — sem recorrer a nenhuma
 * estrutura nativa do Java ({@code java.util.HashSet}).</p>
 *
 * <p><b>Dependência:</b> {@code lib/json-20251224.jar}.</p>
 */
public class MapSaver {

    /** Construtor privado — classe utilitária, não instanciável. */
    private MapSaver() {}

    /**
     * Guarda o {@link GameMap} no caminho indicado.
     *
     * @param map      mapa a serializar
     * @param mapName  nome legível do mapa (campo {@code "name"} no JSON)
     * @param filePath caminho de destino (absoluto ou relativo ao working dir)
     * @throws IOException se ocorrer erro ao escrever o ficheiro
     */
    public static void save(GameMap map, String mapName, String filePath)
            throws IOException {

        JSONObject root = new JSONObject();
        root.put("name",      mapName);
        root.put("locations", buildLocationsArray(map));
        root.put("edges",     buildEdgesArray(map));

        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write(root.toString(2));
        }
    }

    // ── Métodos privados ────────────────────────────────────────────────────

    /**
     * Constrói o array JSON de localizações a partir do mapa.
     *
     * <p>Inclui o campo {@code color} quando definido e o campo
     * {@code biome} quando presente, garantindo que o ficheiro gerado
     * é completamente data-driven e compatível com {@link MapLoader}.
     * O campo {@code enigmaId} foi removido — a seleção de enigmas
     * é feita pela {@code EnigmaPool} com base no {@code dangerLevel}.</p>
     *
     * @param map mapa fonte
     * @return {@link JSONArray} com todas as localizações
     */
    private static JSONArray buildLocationsArray(GameMap map) {
        JSONArray array = new JSONArray();
        for (Location loc : map.getAllLocations()) {
            JSONObject obj = new JSONObject();
            obj.put("id",          loc.getId());
            obj.put("name",        loc.getName());
            obj.put("role",        loc.getRole().name());
            obj.put("dangerLevel", loc.getDangerLevel());
            obj.put("description", loc.getDescription() != null ? loc.getDescription() : "");
            obj.put("icon",        loc.getIcon() != null ? loc.getIcon() : "");
            obj.put("mapX",        loc.getMapX());
            obj.put("mapY",        loc.getMapY());

            // Campos data-driven: só escreve se existirem no modelo
            if (loc.hasColor()) {
                obj.put("color", loc.getColor());
            }
            if (loc.getBiome() != null && !loc.getBiome().isBlank()) {
                obj.put("biome", loc.getBiome());
            }

            array.put(obj);
        }
        return array;
    }

    /**
     * Constrói o array JSON de arestas a partir do mapa.
     *
     * <p>Como o grafo é não-dirigido, cada par (A, B) é registado
     * apenas uma vez. Usa uma {@link DoublyLinkedList}{@code <String>}
     * de chaves {@code "minId_maxId"} para detetar duplicados — sem
     * recorrer a {@code java.util.HashSet}. A operação é O(n²) mas
     * irrelevante para mapas com dezenas de localizações.</p>
     *
     * @param map mapa fonte
     * @return {@link JSONArray} com todas as arestas únicas
     */
    private static JSONArray buildEdgesArray(GameMap map) {
        JSONArray array = new JSONArray();
        DoublyLinkedList<String> seen = new DoublyLinkedList<>();

        for (Location loc : map.getAllLocations()) {
            ListADT<Location> neighbors = map.getNeighbors(loc);
            for (Location neighbor : neighbors) {
                String key = edgeKey(loc.getId(), neighbor.getId());
                if (seen.contains(key)) continue;
                seen.addLast(key);

                JSONObject edge = new JSONObject();
                edge.put("from",   loc.getId());
                edge.put("to",     neighbor.getId());
                edge.put("weight", map.getDistance(loc, neighbor));
                array.put(edge);
            }
        }
        return array;
    }

    /**
     * Gera uma chave única para um par de localizações,
     * independente da direção (A-B == B-A).
     *
     * @param a id da primeira localização
     * @param b id da segunda localização
     * @return chave no formato {@code "minId_maxId"}
     */
    private static String edgeKey(String a, String b) {
        return (a.compareTo(b) < 0) ? a + "_" + b : b + "_" + a;
    }
}
