package ui;

import engine.GameEngine;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.Player;
import ui.game.GameViewController;
import ui.gameover.GameOverController;

import java.io.IOException;

/**
 * Ponto de entrada da aplicação JavaFX.
 *
 * <p>Responsável <b>exclusivamente</b> por:</p>
 * <ul>
 *   <li>Abrir a janela principal</li>
 *   <li>Expor métodos estáticos de navegação entre ecrãs</li>
 * </ul>
 *
 * <p>Não conhece lógica de jogo — apenas troca FXMLs.</p>
 */
public class MainApp extends Application {

    /** Janela principal da aplicação. */
    private static Stage primaryStage;

    // ── JavaFX lifecycle ──────────────────────────────────────────────────────

    @Override
    public void start(Stage stage) {
        primaryStage = stage;
        primaryStage.setTitle("Labirinto da Glória");
        primaryStage.setResizable(true);
        showSetup();
        primaryStage.show();
    }

    /**
     * Ponto de entrada da JVM.
     *
     * @param args argumentos da linha de comandos (não usados)
     */
    public static void main(String[] args) {
        launch(args);
    }

    // ── Navegação ─────────────────────────────────────────────────────────────

    /**
     * Mostra o ecrã de configuração de jogo (Ecrã 1).
     * Pode ser chamado de qualquer classe para reiniciar o fluxo.
     */
    public static void showSetup() {
        loadScene("/ui/setup.fxml", 700, 520);
    }

    /**
     * Mostra o ecrã de jogo (Ecrã 2), passando o engine inicializado.
     *
     * @param engine instância do {@link GameEngine} pronta a correr
     */
    public static void showGame(GameEngine engine) {
        FXMLLoader loader = buildLoader("/ui/game.fxml");
        try {
            Parent root = loader.load();
            GameViewController controller = loader.getController();
            controller.initEngine(engine);
            applyScene(root, 1100, 720);
        } catch (IOException e) {
            throw new RuntimeException("Erro ao carregar game.fxml", e);
        }
    }

    /**
     * Mostra o ecrã de fim de jogo (Ecrã 3).
     *
     * @param winner jogador vencedor
     * @param engine engine da partida terminada (para estatísticas)
     */
    public static void showGameOver(Player winner, GameEngine engine) {
        FXMLLoader loader = buildLoader("/ui/gameover.fxml");
        try {
            Parent root = loader.load();
            GameOverController controller = loader.getController();
            controller.initResult(winner, engine);
            applyScene(root, 700, 500);
        } catch (IOException e) {
            throw new RuntimeException("Erro ao carregar gameover.fxml", e);
        }
    }

    // ── Helpers privados ──────────────────────────────────────────────────────

    /**
     * Carrega um FXML simples (sem dados a injetar no controller).
     *
     * @param fxmlPath caminho relativo ao classpath
     * @param width    largura inicial da janela
     * @param height   altura inicial da janela
     */
    private static void loadScene(String fxmlPath, double width, double height) {
        FXMLLoader loader = buildLoader(fxmlPath);
        try {
            Parent root = loader.load();
            applyScene(root, width, height);
        } catch (IOException e) {
            throw new RuntimeException("Erro ao carregar " + fxmlPath, e);
        }
    }

    /**
     * Cria um {@link FXMLLoader} com o URL correto do classpath.
     *
     * @param fxmlPath caminho relativo ao classpath
     * @return loader pronto para chamar {@code load()}
     */
    private static FXMLLoader buildLoader(String fxmlPath) {
        return new FXMLLoader(MainApp.class.getResource(fxmlPath));
    }

    /**
     * Aplica uma nova cena à janela principal.
     *
     * @param root   raiz do layout carregado
     * @param width  largura da janela
     * @param height altura da janela
     */
    private static void applyScene(Parent root, double width, double height) {
        if (primaryStage.getScene() == null) {
            primaryStage.setScene(new Scene(root, width, height));
        } else {
            primaryStage.getScene().setRoot(root);
            primaryStage.setWidth(width);
            primaryStage.setHeight(height);
        }
    }
}
