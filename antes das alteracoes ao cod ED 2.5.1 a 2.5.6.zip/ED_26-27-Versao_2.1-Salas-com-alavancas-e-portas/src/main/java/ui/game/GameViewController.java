package ui.game;

import engine.CombatResolver;
import model.EventType;
import engine.GameEngine;
import engine.LocationState;
import engine.MoveResult;
import engine.strategy.BotStrategy;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.util.Duration;
import model.Door;
import model.Enigma;
import model.Location;
import model.Player;
import model.ShortcutEdge;
import ui.MainApp;
import Lists.ArrayUnorderedList;
import Lists.DoublyLinkedList;
import Lists.ListADT;
import Lists.UnorderedListADT;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.function.Consumer;

/**
 * Controller do Ecrã 2 — Jogo.
 *
 * <p>Responsabilidades:</p>
 * <ul>
 *   <li>Receber o {@link GameEngine} do setup</li>
 *   <li>Gerir o loop de turnos (bot vs humano) sem bloquear a UI thread</li>
 *   <li>Chamar {@link MapCanvasRenderer} para atualizar o canvas</li>
 *   <li>Apresentar enigmas com botões de opção (A/B/C/D) em overlay sobre o canvas</li>
 *   <li>Verificar fim de jogo e navegar para o ecrã de resultados</li>
 *   <li>Permitir pausa e controlo de velocidade em partidas Bot vs Bot</li>
 *   <li>Apresentar portas de lever rooms e tratar escolhas do jogador</li>
 *   <li>Apresentar mensagem de rapto quando o jogador é teleportado</li>
 * </ul>
 *
 * <h2>Painel de enigma em overlay</h2>
 * <p>Quando um jogador humano encontra um enigma, o painel de overlay
 * é exibido sobre o mapa com a pergunta e botões A/B/C/D.
 * O jogo fica pausado até o jogador selecionar uma opção.
 * Para enigmas legados (sem opções) é apresentado um {@link TextField}.</p>
 *
 * <h2>Lever Rooms</h2>
 * <p>Quando {@link MoveResult#isLeverRoom()} é verdadeiro, o controller
 * guarda o {@code locationId} em {@link #pendingLeverRoomLocationId} e
 * chama {@link #showLeverRoomUI(Location, DoublyLinkedList)} para mostrar
 * os botões das portas. A escolha do jogador é processada por
 * {@link #handleDoorChoice(String)}, que trata recursividade (nested rooms),
 * enigmas de alavanca e avanços normais.</p>
 *
 * <h2>Bots e Lever Rooms (B8)</h2>
 * <p>Quando {@link #playBotTurn(Player)} recebe um {@link MoveResult#isLeverRoom()},
 * o bot resolve imediatamente a lever room ao escolher a porta correcta via
 * {@link GameEngine#resolveLeverDoor}. Isto evita que o bot fique preso
 * silenciosamente na sua posição anterior enquanto o turno avança.</p>
 *
 * <h2>visitedIds lazy-rebuild (B9)</h2>
 * <p>{@link #clearPlayerVisitedIds(Player)} limpa apenas a lista individual
 * do jogador que fez respawn. O campo {@link #visitedIdsList} deixa de ser
 * a fonte de verdade do canvas — essa responsabilidade é transferida para
 * {@link #refreshCanvas()}, que reconstrói a união de todos os
 * {@link PlayerVisited#ids} em cada render. Isto garante que as salas
 * visitadas por outros jogadores nunca desaparecem do canvas quando um
 * jogador morre.</p>
 *
 * <h2>Atalhos visíveis no mapa</h2>
 * <p>Após construir o {@link MapCanvasRenderer}, o controller passa a lista
 * de {@link model.ShortcutEdge} visíveis via
 * {@link MapCanvasRenderer#setVisibleShortcuts(DoublyLinkedList)}, para que
 * {@code drawShortcuts()} os pinte com linha tracejada laranja sobre o mapa.
 * Os atalhos também são listados no log de eventos no arranque do jogo.</p>
 *
 * <h2>Integração com MapCanvasRenderer</h2>
 * <p>{@link #refreshCanvas()} converte as estruturas internas de posições
 * e ids visitados para {@link DoublyLinkedList} da API_ED antes de chamar
 * {@link MapCanvasRenderer#render(Lists.ListADT, Lists.ListADT)},
 * cumprindo a restrição de não usar a API de coleções nativa no renderer.</p>
 *
 * <p>Nenhuma coleção nativa do Java (ArrayList, LinkedHashMap, etc.) é
 * usada nesta classe. Todas as estruturas provêm da API_ED.</p>
 */
public class GameViewController implements Initializable {

    // ── FXML bindings ──────────────────────────────────────────────────

    @FXML private Pane      mapPane;
    @FXML private Label     turnLabel;
    @FXML private Label     currentPlayerLabel;
    @FXML private HBox      allPlayersBar;
    @FXML private TextArea  eventLog;
    @FXML private FlowPane  actionButtons;

    @FXML private VBox        player1Card;
    @FXML private VBox        player2Card;
    @FXML private Label       player1NameLabel;
    @FXML private Label       player2NameLabel;
    @FXML private Label       player1HpLabel;
    @FXML private Label       player2HpLabel;
    @FXML private ProgressBar hp1Bar;
    @FXML private ProgressBar hp2Bar;

    @FXML private Slider speedSlider;
    @FXML private Button pauseButton;
    @FXML private Label  dangerLabel;

    // ── Cores dos jogadores ──────────────────────────────────────────────

    private static final String[] PLAYER_CSS_COLORS = {
        "#00E5FF", "#FF6B35", "#69FF47", "#FFD700"
    };

    // ── Estilos do indicador de perigo ───────────────────────────────────

    private static final String DANGER_STYLE_NEUTRAL =
            "-fx-text-fill: #A0A0A0; -fx-font-size: 11; -fx-font-weight: normal;";
    private static final String DANGER_STYLE_WARNING =
            "-fx-text-fill: #FFD700; -fx-font-size: 12; -fx-font-weight: bold;";
    private static final String DANGER_STYLE_HIGH =
            "-fx-text-fill: #FF3B3B; -fx-font-size: 13; -fx-font-weight: bold;";

    // ── Estrutura interna de par jogador/localização ──────────────────────

    /**
     * Par imutável (Player, Location) para substituir o Map nativo.
     * Usado em {@link #playerPositions} e {@link #playerVisitedIds}.
     */
    private static final class PlayerEntry {
        final Player   player;
        Location       location;
        PlayerEntry(Player player, Location location) {
            this.player   = player;
            this.location = location;
        }
    }

    /**
     * Par imutável (Player, lista de IDs visitados) para substituir o
     * Map&lt;Player, List&lt;String&gt;&gt; nativo.
     */
    private static final class PlayerVisited {
        final Player                  player;
        final UnorderedListADT<String> ids;
        PlayerVisited(Player player) {
            this.player = player;
            this.ids    = new ArrayUnorderedList<>();
        }
    }

    private record PlayerCardRef(
            VBox card, Label nameLabel, Label hpLabel, ProgressBar hpBar) {}

    // ── Estado dinâmico — todos com API_ED ────────────────────────────────

    /** Cards visuais dos jogadores. */
    private final UnorderedListADT<PlayerCardRef> playerCards     = new ArrayUnorderedList<>();
    /** Posição actual de cada jogador (pares Player→Location). */
    private final UnorderedListADT<PlayerEntry>   playerPositions = new ArrayUnorderedList<>();
    /**
     * IDs de salas visitadas — union acumulativa usada por {@link #trackVisited}.
     * Desde B9, {@link #refreshCanvas()} já não lê este campo directamente:
     * a união é reconstruída na altura do render a partir de
     * {@link #playerVisitedIds}. Este campo continua a ser actualizado por
     * {@link #trackVisited} para manter retrocompatibilidade com qualquer
     * código que o inspeccione externamente.
     */
    private final UnorderedListADT<String>         visitedIdsList  = new ArrayUnorderedList<>();
    /** Ordem de jogadores. */
    private final UnorderedListADT<Player>         orderedPlayers  = new ArrayUnorderedList<>();
    /** Historial de salas visitadas por jogador — fonte de verdade do canvas (B9). */
    private final UnorderedListADT<PlayerVisited>  playerVisitedIds = new ArrayUnorderedList<>();

    private GameEngine        engine;
    private MapCanvasRenderer renderer;
    private int               turnCount = 0;
    private volatile boolean  paused    = false;

    /**
     * ID da localização de lever room onde o jogador actual está aguardando
     * a escolha de uma porta. {@code null} se não estiver em lever room.
     */
    private String pendingLeverRoomLocationId = null;

    /** Timeline de pulsação do {@code dangerLabel}. */
    private Timeline dangerPulseTimeline;

    private static final double BASE_BOT_DELAY = 1.0;

    // ── Inicialização ──────────────────────────────────────────────

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        eventLog.setEditable(false);
        eventLog.setWrapText(true);
        if (speedSlider != null) {
            speedSlider.setMin(0.25);
            speedSlider.setMax(3.0);
            speedSlider.setValue(1.0);
            speedSlider.setMajorTickUnit(0.75);
            speedSlider.setShowTickLabels(true);
            speedSlider.setShowTickMarks(true);
        }
        initDangerPulse();
    }

    /** Prepara a {@link Timeline} de pulsação do indicador de perigo. */
    private void initDangerPulse() {
        if (dangerLabel == null) return;
        dangerPulseTimeline = new Timeline(
            new KeyFrame(Duration.ZERO,
                new KeyValue(dangerLabel.opacityProperty(), 1.0)),
            new KeyFrame(Duration.millis(600),
                new KeyValue(dangerLabel.opacityProperty(), 0.35))
        );
        dangerPulseTimeline.setAutoReverse(true);
        dangerPulseTimeline.setCycleCount(Animation.INDEFINITE);
    }

    /**
     * Chamado pelo {@link MainApp#showGame(GameEngine)} após carregar o FXML.
     *
     * <p>Para além de inicializar o engine e o renderer, passa a lista de
     * {@link model.ShortcutEdge} visíveis ao renderer via
     * {@link MapCanvasRenderer#setVisibleShortcuts(DoublyLinkedList)}, de modo
     * a que os atalhos sejam pintados com linha tracejada laranja sobre o mapa.
     * Os atalhos são também listados no log de eventos com o emoji ⚡.</p>
     *
     * @param engine engine do jogo já iniciado
     */
    public void initEngine(GameEngine engine) {
        this.engine = engine;

        // Cards FXML disponíveis (max 2 hardcoded no FXML)
        UnorderedListADT<VBox>        cards      = new ArrayUnorderedList<>();
        UnorderedListADT<Label>       nameLabels = new ArrayUnorderedList<>();
        UnorderedListADT<Label>       hpLabels   = new ArrayUnorderedList<>();
        UnorderedListADT<ProgressBar> bars       = new ArrayUnorderedList<>();
        cards.addToRear(player1Card);      cards.addToRear(player2Card);
        nameLabels.addToRear(player1NameLabel); nameLabels.addToRear(player2NameLabel);
        hpLabels.addToRear(player1HpLabel);     hpLabels.addToRear(player2HpLabel);
        bars.addToRear(hp1Bar);                 bars.addToRear(hp2Bar);

        int idx = 0;
        for (Player p : engine.getPlayers()) {
            orderedPlayers.addToRear(p);
            Location startLoc = p.getCurrentLocation();

            PlayerEntry pe = new PlayerEntry(p, startLoc);
            playerPositions.addToRear(pe);

            PlayerVisited pv = new PlayerVisited(p);
            if (startLoc != null) {
                pv.ids.addToRear(startLoc.getId());
                visitedIdsList.addToRear(startLoc.getId());
            }
            playerVisitedIds.addToRear(pv);

            // Associar card visual se disponível
            VBox        card      = getByIndex(cards,      idx);
            Label       nameLbl   = getByIndex(nameLabels, idx);
            Label       hpLbl     = getByIndex(hpLabels,   idx);
            ProgressBar bar       = getByIndex(bars,       idx);
            if (card != null) {
                playerCards.addToRear(new PlayerCardRef(card, nameLbl, hpLbl, bar));
            }
            idx++;
        }

        renderer = new MapCanvasRenderer(engine.getMap(), mapPane, engine.getObjective());

        // Tarefa 2: passar atalhos visíveis ao renderer para que sejam
        // pintados com linha tracejada laranja em drawShortcuts().
        DoublyLinkedList<ShortcutEdge> shortcuts = engine.getVisibleShortcuts();
        renderer.setVisibleShortcuts(shortcuts);

        // Tarefa 5: listar os atalhos descobertos no log de eventos.
        int shortcutCount = 0;
        for (ShortcutEdge se : shortcuts) {
            log("⚡ Atalho descoberto: " + se.getFrom().getName()
                    + " → " + se.getTo().getName());
            shortcutCount++;
        }
        if (shortcutCount == 0) {
            log("⚡ Nenhum atalho disponível neste mapa.");
        }

        mapPane.widthProperty().addListener((obs, o, n)  -> refreshCanvas());
        mapPane.heightProperty().addListener((obs, o, n) -> refreshCanvas());

        buildAllPlayersBar();
        updateStatusPanel();
        Platform.runLater(this::playTurn);
    }

    // ── Pausa / velocidade ──────────────────────────────────────────────

    @FXML
    private void onTogglePause() {
        paused = !paused;
        if (pauseButton != null) {
            pauseButton.setText(paused ? "▶ Retomar" : "⏸ Pausa");
        }
        if (!paused) Platform.runLater(this::playTurn);
    }

    private double currentBotDelay() {
        if (speedSlider == null) return BASE_BOT_DELAY;
        return Math.max(0.10, BASE_BOT_DELAY / Math.max(0.25, speedSlider.getValue()));
    }

    // ── Loop de turnos ───────────────────────────────────────────────

    private void playTurn() {
        if (!engine.isRunning()) { navigateToGameOver(); return; }

        Player current = engine.getCurrentPlayer();
        boolean isBot  = PlayerStrategy.isBot(current);

        if (paused && isBot) return;

        turnLabel.setText("Turno " + (++turnCount));
        currentPlayerLabel.setText(current.getName() + (isBot ? " 🤖" : " 🧑"));
        highlightAllPlayersBar(current);
        highlightCurrentPlayerCard(current);
        updateDangerIndicator(current);

        if (isBot) playBotTurn(current);
        else       showHumanButtons(current);
    }

    /**
     * Executa o turno de um bot, incluindo a resolução automática de
     * lever rooms.
     *
     * <p>Pipeline:</p>
     * <ol>
     *   <li>Chama {@link GameEngine#getBotMove} para obter o resultado
     *       do movimento.</li>
     *   <li><b>B8 — Lever room:</b> se o resultado for
     *       {@link MoveResult#isLeverRoom()}, o bot percorre
     *       {@link MoveResult#getPendingDoors()} e escolhe imediatamente
     *       a porta correcta via {@link GameEngine#resolveLeverDoor}.
     *       O {@code result} é substituído pelo resultado da resolução,
     *       garantindo que o fluxo de actualização de posição abaixo
     *       recebe sempre um resultado terminal.</li>
     *   <li>Actualiza posição, canvas e painel de estado.</li>
     *   <li>Verifica condição de vitória e avança o turno.</li>
     * </ol>
     *
     * @param bot jogador bot cujo turno é agora
     */
    private void playBotTurn(Player bot) {
        BotStrategy strategy = PlayerStrategy.get(bot);
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(currentBotDelay()), e -> {
            MoveResult result = engine.getBotMove(bot, strategy);
            logResult(bot, result);

            // B8: resolver lever room imediatamente — o bot nunca fica
            // preso à espera de input humano.
            if (result.isLeverRoom()) {
                String locId = result.getDestination().getId();
                MoveResult leverResult = null;
                for (Door door : result.getPendingDoors()) {
                    if (door.isCorrect()) {
                        leverResult = engine.resolveLeverDoor(
                                bot, locId, door.getId(), null);
                        break;
                    }
                }
                if (leverResult == null) {
                    leverResult = MoveResult.blocked(
                            MoveResult.BlockReason.NOT_ADJACENT);
                }
                logResult(bot, leverResult);
                result = leverResult;
            }

            if (result.isSuccess()) {
                Location current = bot.getCurrentLocation();
                setPlayerPosition(bot, current);
                if (result.respawned()) clearPlayerVisitedIds(bot);
                else                    trackVisited(bot, current);
            }
            refreshCanvas();
            updateStatusPanel();
            updateDangerIndicator(bot);
            if (!engine.isRunning()) navigateToGameOver();
            else advanceTurn();
        }));
        timeline.play();
    }

    /**
     * Constrói os botões de movimento para um jogador humano.
     *
     * <p>Apresenta primeiro os vizinhos normais do grafo e, depois, os
     * atalhos visíveis a partir da posição actual do jogador. Os botões
     * de atalho têm estilo distinto (borda laranja) para serem facilmente
     * identificados.</p>
     *
     * @param player jogador humano cujo turno é agora
     */
    private void showHumanButtons(Player player) {
        actionButtons.getChildren().clear();

        // ── Vizinhos normais ──────────────────────────────────────────────────
        for (Location adj : engine.getMap().getNeighbors(player.getCurrentLocation())) {
            boolean alreadyVisited =
                engine.getOrCreateState(player, adj.getId()).isVisited();

            String label = alreadyVisited
                    ? "⚠️ " + adj.getName() + " (-" + GameEngine.REVISIT_DAMAGE + " HP)"
                    : "→ " + adj.getName();

            Button btn = new Button(label);
            if (alreadyVisited) {
                btn.setStyle("-fx-background-color: #7B4F00; -fx-text-fill: #FFD966;");
            }
            btn.setOnAction(e -> handleHumanMove(player, adj));
            actionButtons.getChildren().add(btn);
        }

        // ── Atalhos visíveis a partir da posição actual ──────────────────────
        DoublyLinkedList<ShortcutEdge> visShortcuts = engine.getVisibleShortcuts();
        for (ShortcutEdge se : visShortcuts) {
            Location scFrom = se.getFrom();
            Location scTo   = se.getTo();
            Location scDest = null;
            if (scFrom.equals(player.getCurrentLocation())) scDest = scTo;
            else if (scTo.equals(player.getCurrentLocation())) scDest = scFrom;
            if (scDest == null) continue;

            final Location finalDest = scDest;
            String label = "⚡ Atalho → " + scDest.getName();
            Button btn = new Button(label);
            btn.setStyle(
                "-fx-background-color: #1A3A1A; -fx-text-fill: #FF9800; " +
                "-fx-border-color: #FF9800; -fx-border-radius: 6; " +
                "-fx-background-radius: 6; -fx-font-size: 12; -fx-padding: 8 16;");
            btn.setOnMouseEntered(e -> btn.setStyle(
                "-fx-background-color: #2A5A2A; -fx-text-fill: #FFD700; " +
                "-fx-border-color: #FFD700; -fx-border-radius: 6; " +
                "-fx-background-radius: 6; -fx-font-size: 12; -fx-padding: 8 16;"));
            btn.setOnMouseExited(e -> btn.setStyle(
                "-fx-background-color: #1A3A1A; -fx-text-fill: #FF9800; " +
                "-fx-border-color: #FF9800; -fx-border-radius: 6; " +
                "-fx-background-radius: 6; -fx-font-size: 12; -fx-padding: 8 16;"));
            btn.setOnAction(e -> handleHumanMove(player, finalDest));
            actionButtons.getChildren().add(btn);
        }
    }

    /**
     * Processa o movimento de um jogador humano para um destino.
     *
     * <p>Pipeline de decisão (por ordem de prioridade):</p>
     * <ol>
     *   <li><b>Atalho com ENIGMA</b> — se o destino é atingido via atalho com
     *       evento {@code ENIGMA}, apresenta o enigma do atalho e retorna.
     *       Evita conflito com o enigma normal da sala.</li>
     *   <li><b>LEVER já atribuído ou LEVER_ROOM estática</b> — se o
     *       {@link LocationState#getAssignedEventType()} do destino for
     *       {@link EventType#LEVER}, ou a sala tiver {@code role == LEVER_ROOM},
     *       avança directamente para {@link #executeMoveAndAdvance} sem mostrar
     *       nenhum painel de enigma. O engine devolve
     *       {@link MoveResult#isLeverRoom()} e o fluxo normal de lever room
     *       trata do resto.</li>
     *   <li><b>Enigma normal da sala</b> — se a sala tem enigma não resolvido e
     *       nenhuma das condições anteriores se aplica, apresenta o painel de
     *       enigma.</li>
     *   <li><b>Movimento directo</b> — caso contrário.</li>
     * </ol>
     *
     * @param player      jogador a mover
     * @param destination localização destino
     */
    private void handleHumanMove(Player player, Location destination) {
        actionButtons.getChildren().clear();

        // ── Passo 1: atalho com evento ENIGMA ─────────────────────────────────
        Enigma scEnigma = engine.getShortcutEnigma(
                player.getCurrentLocation(), destination);
        if (scEnigma != null) {
            showEnigmaPanelWithCallback(player, destination, scEnigma);
            return;
        }

        // ── Passo 2: B6 — LEVER já atribuído ou sala LEVER_ROOM estática ─────
        LocationState destState = engine.getOrCreateState(player, destination.getId());
        if (destState.getAssignedEventType() == EventType.LEVER
                || destination.isLeverRoom()) {
            executeMoveAndAdvance(player, destination, null);
            return;
        }

        // ── Passo 3: enigma normal da sala ─────────────────────────────────
        boolean enigmaResolved = destState.isEnigmaResolved();
        if (destination.hasEnigmaByLevel() && !enigmaResolved) {
            Enigma enigma = engine.getEnigmaForPlayer(player, destination.getId());
            showEnigmaPanelWithCallback(player, destination, enigma);
        } else {
            executeMoveAndAdvance(player, destination, null);
        }
    }

    /**
     * Apresenta o painel de enigma em overlay e, após a seleção, executa o movimento.
     *
     * @param player      jogador
     * @param destination sala destino
     * @param enigma      enigma a apresentar (pode ser {@code null})
     */
    private void showEnigmaPanelWithCallback(Player player,
                                              Location destination,
                                              Enigma enigma) {
        VBox overlay = buildEnigmaOverlay(destination, enigma, chosenAnswer -> {
            mapPane.getChildren().removeIf(n -> "enigmaOverlay".equals(n.getId()));
            executeMoveAndAdvance(player, destination, chosenAnswer);
        });
        overlay.setId("enigmaOverlay");
        mapPane.getChildren().add(overlay);
    }

    /**
     * Constrói o painel de overlay do enigma com botões de opção A/B/C/D
     * ou, em modo legado, com um {@link TextField}.
     *
     * @param destination sala onde o enigma se encontra
     * @param enigma      enigma (pode ser {@code null})
     * @param onAnswer    callback chamado com a resposta escolhida
     * @return painel VBox pronto a ser adicionado ao {@link #mapPane}
     */
    private VBox buildEnigmaOverlay(Location destination, Enigma enigma,
                                     Consumer<String> onAnswer) {
        String overlayStyle =
            "-fx-background-color: rgba(20,10,5,0.93); " +
            "-fx-border-color: #C8A96E; -fx-border-width: 2; " +
            "-fx-border-radius: 10; -fx-background-radius: 10; " +
            "-fx-padding: 20; -fx-spacing: 12;";

        VBox panel = new VBox(12);
        panel.setStyle(overlayStyle);
        panel.setMaxWidth(480);
        panel.setMaxHeight(400);
        panel.setAlignment(Pos.CENTER);

        Label titleLbl = new Label("⚡ Enigma em " + destination.getName()
                + "  [Nível " + destination.getDangerLevel() + "]");
        titleLbl.setStyle("-fx-text-fill: #FFD700; -fx-font-size: 15; -fx-font-weight: bold;");
        titleLbl.setWrapText(true);

        String questionText = (enigma != null) ? enigma.getQuestion()
                : "Esta localização está guardada por um enigma.";
        Label questionLbl = new Label(questionText);
        questionLbl.setStyle("-fx-text-fill: #E8DCC8; -fx-font-size: 13;");
        questionLbl.setWrapText(true);
        questionLbl.setMaxWidth(440);

        panel.getChildren().addAll(titleLbl, questionLbl);

        if (enigma != null && enigma.hasHint()) {
            Label hintLbl = new Label("💡 " + enigma.getHint());
            hintLbl.setStyle("-fx-text-fill: #90CAF9; -fx-font-size: 11; -fx-font-style: italic;");
            hintLbl.setWrapText(true);
            panel.getChildren().add(hintLbl);
        }

        if (enigma != null && enigma.isMultipleChoice()) {
            String[] letters = {"A", "B", "C", "D", "E"};
            int i = 0;
            for (String opt : enigma.getOptions()) {
                final String letter = letters[i % letters.length];
                Button optBtn = new Button(letter + ")  " + opt);
                optBtn.setMaxWidth(Double.MAX_VALUE);
                String normalStyle =
                    "-fx-background-color: #2D1B0E; -fx-text-fill: #E8DCC8; " +
                    "-fx-border-color: #5C4033; -fx-border-radius: 6; " +
                    "-fx-background-radius: 6; -fx-font-size: 12; -fx-padding: 8 16;";
                String hoverStyle =
                    "-fx-background-color: #3D2B1A; -fx-text-fill: #FFD700; " +
                    "-fx-border-color: #C8A96E; -fx-border-radius: 6; " +
                    "-fx-background-radius: 6; -fx-font-size: 12; -fx-padding: 8 16;";
                optBtn.setStyle(normalStyle);
                optBtn.setOnMouseEntered(e -> optBtn.setStyle(hoverStyle));
                optBtn.setOnMouseExited(e -> optBtn.setStyle(normalStyle));
                optBtn.setOnAction(e -> onAnswer.accept(letter));
                panel.getChildren().add(optBtn);
                i++;
            }
        } else {
            TextField input = new TextField();
            input.setPromptText("A tua resposta...");
            input.setStyle(
                "-fx-background-color: #1A0F0A; -fx-text-fill: #E8DCC8; " +
                "-fx-border-color: #5C4033; -fx-prompt-text-fill: #7a6a5a;");
            Button confirmBtn = new Button("✔ Confirmar");
            confirmBtn.setStyle(
                "-fx-background-color: #C8A96E; -fx-text-fill: #1A0F0A; " +
                "-fx-font-weight: bold; -fx-padding: 6 20; -fx-background-radius: 6;");
            confirmBtn.setOnAction(e -> onAnswer.accept(input.getText()));
            input.setOnAction(e -> onAnswer.accept(input.getText()));
            panel.getChildren().addAll(input, confirmBtn);
        }

        panel.layoutXProperty().bind(
            mapPane.widthProperty().subtract(panel.maxWidthProperty()).divide(2));
        panel.layoutYProperty().bind(
            mapPane.heightProperty().subtract(380).divide(2));

        return panel;
    }

    /**
     * Executa o movimento no engine e avança o turno.
     *
     * @param player      jogador
     * @param destination sala destino
     * @param answer      resposta ao enigma (pode ser {@code null})
     */
    private void executeMoveAndAdvance(Player player, Location destination, String answer) {
        MoveResult result = engine.moveTo(player, destination, answer);
        logResult(player, result);

        // ── Lever Room ──────────────────────────────────────────────────
        if (result.isLeverRoom()) {
            pendingLeverRoomLocationId = result.getDestination().getId();
            showLeverRoomUI(result.getDestination(), result.getPendingDoors());
            return;
        }

        // ── Rapto ───────────────────────────────────────────────────────────
        if (result.wasKidnapped()) {
            pendingLeverRoomLocationId = null;
            showKidnapMessage(result.getDestination());
            updatePlayerPosition(player, result.getDestination());
            return;
        }

        if (result.respawned()) {
            Location spawn = player.getCurrentLocation();
            if (spawn == null) spawn = getPlayerPosition(player);
            setPlayerPosition(player, spawn);
            clearPlayerVisitedIds(player);
            trackVisited(player, spawn);
            refreshCanvas();
            updateStatusPanel();
            updateDangerIndicator(player);
            advanceTurn();
        } else if (result.isSuccess()) {
            Location newLoc = player.getCurrentLocation();
            if (newLoc == null) newLoc = getPlayerPosition(player);
            setPlayerPosition(player, newLoc);
            trackVisited(player, newLoc);
            refreshCanvas();
            updateStatusPanel();
            updateDangerIndicator(player);
            if (!engine.isRunning()) navigateToGameOver();
            else advanceTurn();
        } else if (result.hadEnigma()) {
            if (!result.isSuccess() && result.getDamageTaken() == 0) {
                Enigma enigma = engine.getShortcutEnigma(
                        player.getCurrentLocation(), destination);
                if (enigma == null) {
                    enigma = engine.getEnigmaForPlayer(player, destination.getId());
                }
                final Location dest       = destination;
                final Enigma  finalEnigma = enigma;
                showEnigmaPanelWithCallback(player, dest, finalEnigma);
            } else {
                updateStatusPanel();
                if (result.tookDamage()) {
                    log("💔 Dano sofrido: -" + result.getDamageTaken()
                            + " HP | HP restante: " + player.getHealth());
                }
                log("❌ Resposta errada! Podes tentar de novo no próximo turno.");
                showHumanButtons(player);
                advanceTurn();
            }
        } else {
            log("🚫 Movimento bloqueado: " + result.getBlockReason().name());
            advanceTurn();
        }
    }

    // ── Lever Rooms ─────────────────────────────────────────────────

    /**
     * Apresenta as portas de uma lever room ao jogador humano.
     *
     * @param loc   localização da lever room
     * @param doors portas disponíveis
     */
    private void showLeverRoomUI(Location loc, DoublyLinkedList<Door> doors) {
        actionButtons.getChildren().clear();

        Label promptLbl = new Label("🚪 Sala de Alavancas — " + loc.getName()
                + "\nEscolhe uma porta:");
        promptLbl.setStyle(
            "-fx-text-fill: #FFD700; -fx-font-size: 13; -fx-font-weight: bold; " +
            "-fx-wrap-text: true;");
        actionButtons.getChildren().add(promptLbl);

        String[] doorLabels = {"A", "B", "C", "D", "E", "F"};
        int idx = 0;
        for (Door door : doors) {
            final String doorId  = door.getId();
            final String btnText = "Porta " + doorLabels[idx % doorLabels.length];

            Button btn = new Button(btnText);
            btn.setStyle(
                "-fx-background-color: #3D2B1A; -fx-text-fill: #E8DCC8; " +
                "-fx-border-color: #C8A96E; -fx-border-radius: 6; " +
                "-fx-background-radius: 6; -fx-font-size: 13; -fx-padding: 8 20;");
            btn.setOnMouseEntered(e -> btn.setStyle(
                "-fx-background-color: #5C3D1E; -fx-text-fill: #FFD700; " +
                "-fx-border-color: #FFD700; -fx-border-radius: 6; " +
                "-fx-background-radius: 6; -fx-font-size: 13; -fx-padding: 8 20;"));
            btn.setOnMouseExited(e -> btn.setStyle(
                "-fx-background-color: #3D2B1A; -fx-text-fill: #E8DCC8; " +
                "-fx-border-color: #C8A96E; -fx-border-radius: 6; " +
                "-fx-background-radius: 6; -fx-font-size: 13; -fx-padding: 8 20;"));
            btn.setOnAction(e -> handleDoorChoice(doorId));
            actionButtons.getChildren().add(btn);
            idx++;
        }

        log("🚪 " + engine.getCurrentPlayer().getName()
                + " entrou na Sala de Alavancas: " + loc.getName());
    }

    /**
     * Processa a escolha de uma porta numa lever room pelo jogador humano.
     *
     * @param doorId id da porta escolhida
     */
    private void handleDoorChoice(String doorId) {
        Player player = engine.getCurrentPlayer();
        actionButtons.getChildren().clear();

        MoveResult result = engine.resolveLeverDoor(
                player, pendingLeverRoomLocationId, doorId, null);
        logResult(player, result);

        if (result.isLeverRoom()) {
            pendingLeverRoomLocationId = result.getDestination().getId();
            showLeverRoomUI(result.getDestination(), result.getPendingDoors());
            return;
        }

        if (result.wasKidnapped()) {
            pendingLeverRoomLocationId = null;
            showKidnapMessage(result.getDestination());
            updatePlayerPosition(player, result.getDestination());
            return;
        }

        if (result.hadEnigma() && !result.isSuccess()) {
            final String locIdSnapshot = pendingLeverRoomLocationId;
            Enigma enigma = engine.getEnigmaForPlayer(
                    player, player.getCurrentLocation().getId());

            VBox overlay = buildEnigmaOverlay(
                    player.getCurrentLocation(), enigma, enigmaAnswer -> {
                        mapPane.getChildren().removeIf(
                                n -> "leverEnigmaOverlay".equals(n.getId()));
                        MoveResult r2 = engine.resolveLeverDoor(
                                player, locIdSnapshot, doorId, enigmaAnswer);
                        logResult(player, r2);
                        processLeverResult(player, r2);
                    });
            overlay.setId("leverEnigmaOverlay");
            mapPane.getChildren().add(overlay);
            return;
        }

        processLeverResult(player, result);
    }

    /**
     * Processa o {@link MoveResult} final de uma lever room.
     *
     * @param player jogador
     * @param result resultado da resolução da porta
     */
    private void processLeverResult(Player player, MoveResult result) {
        pendingLeverRoomLocationId = null;

        if (result.respawned()) {
            Location spawn = player.getCurrentLocation();
            if (spawn == null) spawn = getPlayerPosition(player);
            setPlayerPosition(player, spawn);
            clearPlayerVisitedIds(player);
            trackVisited(player, spawn);
            refreshCanvas();
            updateStatusPanel();
            updateDangerIndicator(player);
            advanceTurn();
        } else if (result.isSuccess()) {
            Location newLoc = player.getCurrentLocation();
            if (newLoc == null) newLoc = getPlayerPosition(player);
            setPlayerPosition(player, newLoc);
            trackVisited(player, newLoc);
            refreshCanvas();
            updateStatusPanel();
            updateDangerIndicator(player);
            if (!engine.isRunning()) navigateToGameOver();
            else advanceTurn();
        } else if (result.tookDamage()) {
            Location newLoc = player.getCurrentLocation();
            if (newLoc == null) newLoc = getPlayerPosition(player);
            setPlayerPosition(player, newLoc);
            trackVisited(player, newLoc);
            log("💔 Resposta errada! -" + result.getDamageTaken()
                    + " HP | HP restante: " + player.getHealth());
            refreshCanvas();
            updateStatusPanel();
            updateDangerIndicator(player);
            advanceTurn();
        } else {
            log("🚫 Bloqueado: " + result.getBlockReason().name());
            advanceTurn();
        }
    }

    // ── Rapto ───────────────────────────────────────────────────────────

    /**
     * Apresenta a mensagem de rapto ao jogador e actualiza a UI.
     *
     * @param dest localização para onde o jogador foi teleportado
     */
    private void showKidnapMessage(Location dest) {
        String destName = (dest != null) ? dest.getName() : "local desconhecido";
        log("🌀 Foste raptado! Teleportado para " + destName);

        VBox overlay = new VBox(12);
        overlay.setAlignment(Pos.CENTER);
        overlay.setStyle(
            "-fx-background-color: rgba(60,0,80,0.92); " +
            "-fx-border-color: #9B59B6; -fx-border-width: 2; " +
            "-fx-border-radius: 10; -fx-background-radius: 10; " +
            "-fx-padding: 24;");
        overlay.setMaxWidth(400);
        overlay.setMaxHeight(180);
        overlay.setId("kidnapOverlay");

        Label icon = new Label("🌀");
        icon.setStyle("-fx-font-size: 40;");

        Label msg = new Label("Foste raptado!");
        msg.setStyle("-fx-text-fill: #E040FB; -fx-font-size: 18; -fx-font-weight: bold;");

        Label dest2 = new Label("Teleportado para: " + destName);
        dest2.setStyle("-fx-text-fill: #E8DCC8; -fx-font-size: 13;");
        dest2.setWrapText(true);

        overlay.getChildren().addAll(icon, msg, dest2);
        overlay.layoutXProperty().bind(
            mapPane.widthProperty().subtract(overlay.maxWidthProperty()).divide(2));
        overlay.layoutYProperty().bind(
            mapPane.heightProperty().subtract(180).divide(2));

        mapPane.getChildren().add(overlay);

        Timeline hideTimer = new Timeline(
            new KeyFrame(Duration.seconds(2), e -> {
                mapPane.getChildren().removeIf(
                        n -> "kidnapOverlay".equals(n.getId()));
                advanceTurn();
            }));
        hideTimer.play();
    }

    /**
     * Actualiza a posição de um jogador após rapto ou teleporte.
     *
     * @param player jogador teleportado
     * @param dest   nova localização
     */
    private void updatePlayerPosition(Player player, Location dest) {
        if (dest == null) return;
        setPlayerPosition(player, dest);
        trackVisited(player, dest);
        refreshCanvas();
        updateStatusPanel();
        updateDangerIndicator(player);
    }

    private void advanceTurn() {
        engine.nextTurn();
        Platform.runLater(this::playTurn);
    }

    // ── Gestão de posições ────────────────────────────────────────────────

    /**
     * Atualiza a posição de um jogador na lista {@link #playerPositions}.
     *
     * @param player   jogador
     * @param location nova localização
     */
    private void setPlayerPosition(Player player, Location location) {
        for (PlayerEntry pe : playerPositions) {
            if (pe.player.equals(player)) { pe.location = location; return; }
        }
    }

    /**
     * Devolve a localização actual de um jogador conforme registada em
     * {@link #playerPositions}.
     *
     * @param player jogador
     * @return localização registada, ou {@code null} se não encontrado
     */
    private Location getPlayerPosition(Player player) {
        for (PlayerEntry pe : playerPositions) {
            if (pe.player.equals(player)) return pe.location;
        }
        return null;
    }

    // ── Indicador de perigo ───────────────────────────────────────────────

    /**
     * Atualiza o {@code dangerLabel} com o multiplicador do jogador atual.
     *
     * @param player jogador cujo multiplicador deve ser apresentado
     */
    private void updateDangerIndicator(Player player) {
        if (dangerLabel == null || engine == null) return;

        double multiplier = engine.getProximityMultiplier(player);
        String emoji;
        String style;

        if (multiplier >= CombatResolver.HIGH_DANGER_THRESHOLD) {
            emoji = "🔴";
            style = DANGER_STYLE_HIGH;
            startDangerPulse();
        } else if (multiplier >= 1.0) {
            emoji = "🟡";
            style = DANGER_STYLE_WARNING;
            stopDangerPulse();
        } else {
            emoji = "🟢";
            style = DANGER_STYLE_NEUTRAL;
            stopDangerPulse();
        }

        dangerLabel.setText(String.format("%s Perigo: ×%.2f", emoji, multiplier));
        dangerLabel.setStyle(style);
    }

    private void startDangerPulse() {
        if (dangerPulseTimeline == null) return;
        if (dangerPulseTimeline.getStatus() != Animation.Status.RUNNING) {
            dangerLabel.setOpacity(1.0);
            dangerPulseTimeline.play();
        }
    }

    private void stopDangerPulse() {
        if (dangerPulseTimeline == null) return;
        if (dangerPulseTimeline.getStatus() == Animation.Status.RUNNING) {
            dangerPulseTimeline.stop();
            if (dangerLabel != null) dangerLabel.setOpacity(1.0);
        }
    }

    // ── Gestão de visitedIds por jogador ────────────────────────────────────

    private void trackVisited(Player player, Location location) {
        if (location == null) return;
        for (PlayerVisited pv : playerVisitedIds) {
            if (pv.player.equals(player)) {
                pv.ids.addToRear(location.getId());
                break;
            }
        }
        boolean alreadyGlobal = false;
        for (String id : visitedIdsList) {
            if (id.equals(location.getId())) { alreadyGlobal = true; break; }
        }
        if (!alreadyGlobal) visitedIdsList.addToRear(location.getId());
    }

    /**
     * Limpa apenas a lista individual do jogador que fez respawn.
     *
     * <p><b>B9 — fix:</b> antes deste fix, este método também chamava
     * {@code clearList(visitedIdsList)} e depois reconstruía a union
     * global — mas já tinha apagado {@code pv.ids} do jogador moribundo,
     * pelo que essa reconstrução ficava correcta <em>em teoria</em>.
     * O problema real era que, com jogadores diferentes a partilharem
     * salas, a reconstrução poderia perder salas vistas pelo jogador
     * moribundo que o outro jogador <em>não</em> visitou, causando
     * inconsistência visual no canvas.
     *
     * <p>A solução é simples: limpar apenas {@code pv.ids} do jogador
     * e deixar {@link #refreshCanvas()} reconstruir a união em tempo real
     * a partir de todos os {@link PlayerVisited#ids}, tornando
     * {@link #visitedIdsList} irrelevante para o renderer.</p>
     *
     * @param player jogador que fez respawn
     */
    private void clearPlayerVisitedIds(Player player) {
        for (PlayerVisited pv : playerVisitedIds) {
            if (pv.player.equals(player)) {
                clearList(pv.ids);
                return;  // não tocar em visitedIdsList — refreshCanvas() reconstrói
            }
        }
    }

    // ── allPlayersBar ───────────────────────────────────────────────

    private void buildAllPlayersBar() {
        if (allPlayersBar == null) return;
        allPlayersBar.getChildren().clear();
        allPlayersBar.setSpacing(8);
        allPlayersBar.setAlignment(Pos.CENTER_LEFT);
        int i = 0;
        for (Player p : orderedPlayers) {
            String color = PLAYER_CSS_COLORS[i % PLAYER_CSS_COLORS.length];
            Circle dot = new Circle(6);
            dot.setFill(Color.web(color));
            dot.setStroke(Color.WHITE);
            dot.setStrokeWidth(1.0);
            Label lbl = new Label(p.getName() + (p.isBot() ? " 🤖" : ""));
            lbl.setStyle("-fx-text-fill: #E8DCC8; -fx-font-size: 11;");
            HBox pill = new HBox(5, dot, lbl);
            pill.setAlignment(Pos.CENTER_LEFT);
            pill.setStyle("-fx-padding: 3 8; -fx-background-radius: 12; -fx-background-color: transparent;");
            pill.setUserData(p);
            allPlayersBar.getChildren().add(pill);
            i++;
        }
    }

    private void highlightAllPlayersBar(Player current) {
        if (allPlayersBar == null) return;
        int i = 0;
        for (var node : allPlayersBar.getChildren()) {
            if (!(node instanceof HBox pill)) { i++; continue; }
            Player p     = getByIndex(orderedPlayers, i);
            if (p == null) { i++; continue; }
            String color = PLAYER_CSS_COLORS[i % PLAYER_CSS_COLORS.length];
            boolean active = p.equals(current);
            pill.setStyle("-fx-padding: 3 8; -fx-background-radius: 12;"
                + (active
                   ? "-fx-background-color: " + color + "22; -fx-border-color: "
                     + color + "; -fx-border-radius: 12; -fx-border-width: 1;"
                   : "-fx-background-color: transparent;"));
            i++;
        }
    }

    // ── UI helpers ───────────────────────────────────────────────

    /**
     * Reconstrói a lista de IDs visitados a partir de todos os jogadores
     * e chama o renderer.
     *
     * <p><b>B9:</b> a lista {@code visited} passada ao renderer é agora
     * construída aqui em cada render, fazendo a união de todos os
     * {@link PlayerVisited#ids}. Isto elimina qualquer dessincronização
     * entre {@link #visitedIdsList} e o estado real, garantindo que as
     * salas visitadas por qualquer jogador são sempre mostradas no canvas,
     * mesmo após um respawn de outro jogador.</p>
     *
     * <p><b>B10 (null-guard):</b> se a localização de um jogador for
     * {@code null} (e.g. imediatamente após respawn ou antes de setup
     * completo), tenta-se o fallback {@code pe.player.getCurrentLocation()}.
     * Se ainda for {@code null}, o jogador é omitido do render desta frame
     * sem lançar exceção.</p>
     */
    private void refreshCanvas() {
        if (renderer == null) return;

        // B10: null-guard — skip players with unknown location
        DoublyLinkedList<MapCanvasRenderer.PlayerLocationEntry> positions =
                new DoublyLinkedList<>();
        for (PlayerEntry pe : playerPositions) {
            Location loc = getPlayerPosition(pe.player);
            if (loc == null) loc = pe.player.getCurrentLocation(); // fallback to model
            if (loc == null) continue;                             // truly unknown — skip
            positions.addLast(
                new MapCanvasRenderer.PlayerLocationEntry(pe.player, loc));
        }

        // B9: rebuild visited union on every render from per-player lists
        DoublyLinkedList<String> visited = new DoublyLinkedList<>();
        for (PlayerVisited pv : playerVisitedIds) {
            for (String id : pv.ids) {
                boolean already = false;
                for (String existing : visited) {
                    if (existing.equals(id)) { already = true; break; }
                }
                if (!already) visited.addLast(id);
            }
        }

        renderer.render(positions, visited);
    }

    private void updateStatusPanel() {
        int idx = 0;
        for (PlayerEntry pe : playerPositions) {
            PlayerCardRef ref = getByIndex(playerCards, idx);
            if (ref == null) break;
            int hp = pe.player.getHealth();
            ref.nameLabel().setText(pe.player.getName());
            ref.hpLabel().setText("❤ " + hp + "/100");
            ref.hpBar().setProgress(hp / 100.0);
            idx++;
        }
    }

    private void highlightCurrentPlayerCard(Player current) {
        int idx = 0;
        for (PlayerEntry pe : playerPositions) {
            PlayerCardRef ref = getByIndex(playerCards, idx);
            if (ref == null) break;
            VBox card  = ref.card();
            Location loc = getPlayerPosition(pe.player);
            boolean active = pe.player.equals(current) && loc != null;
            card.setStyle(active
                    ? "-fx-border-color: #FFD700; -fx-border-width: 2; " +
                      "-fx-background-color: #3D2B1F; -fx-padding: 8; -fx-background-radius: 6;"
                    : "-fx-border-color: #5C4033; -fx-border-width: 1; " +
                      "-fx-background-color: #2D1B0E; -fx-padding: 8; -fx-background-radius: 6;");
            idx++;
        }
    }

    /**
     * Remove todos os elementos de uma lista da API_ED.
     *
     * @param <T>  tipo dos elementos
     * @param list lista a esvaziar
     */
    private <T> void clearList(ListADT<T> list) {
        while (!list.isEmpty()) {
            try { list.removeFirst(); }
            catch (Exception ignored) {}
        }
    }

    /**
     * Utilitário: devolve o elemento de uma {@link UnorderedListADT} por índice.
     *
     * @param <T>   tipo dos elementos
     * @param list  lista a percorrer
     * @param index índice desejado (0-based)
     * @return elemento, ou {@code null} se o índice estiver fora dos limites
     */
    private <T> T getByIndex(UnorderedListADT<T> list, int index) {
        int i = 0;
        for (T item : list) {
            if (i == index) return item;
            i++;
        }
        return null;
    }

    private void log(String msg) { eventLog.appendText(msg + "\n"); }

    /**
     * Formata e regista o resultado de um movimento no log.
     *
     * @param player jogador
     * @param result resultado do movimento
     */
    private void logResult(Player player, MoveResult result) {
        if (result.isLeverRoom()) {
            log("🚪 " + player.getName() + " entrou na Sala de Alavancas: "
                    + result.getDestination().getName());
        } else if (result.wasKidnapped()) {
            log("🌀 " + player.getName() + " foi raptado para: "
                    + result.getDestination().getName());
        } else if (result.respawned()) {
            log("☠️ " + player.getName() + " morreu! Dano fatal: -"
                    + result.getDamageTaken() + " HP");
            log("💀 Respawn em " + result.getRespawnLocation().getName()
                    + " | ❤ HP restaurado para " + player.getHealth()
                    + " | 🗺️ Progresso de sala limpo");
        } else if (result.isSuccess() && !result.hadCombat() && !result.hadEnigma()) {
            if (result.tookDamage()) {
                log("🔁 " + player.getName() + " voltou a "
                        + result.getDestination().getName()
                        + " | 💔 -" + result.getDamageTaken() + " HP (revisita)");
            } else {
                log("✅ " + player.getName() + " move para "
                        + result.getDestination().getName());
            }
        } else if (result.hadCombat()) {
            log("⚔️ " + player.getName() + " combate em "
                    + result.getDestination().getName()
                    + " — dano: " + result.getCombatResult().getDamage()
                    + " | HP restante: " + player.getHealth());
        } else if (result.hadEnigma()) {
            boolean correct = result.getEnigmaResult().isCorrect();
            String dmgInfo = (!correct && result.tookDamage())
                    ? " | 💔 -" + result.getDamageTaken() + " HP (perigo)" : "";
            log((correct ? "🔓" : "🔐") + " " + player.getName()
                    + " enigma em " + result.getDestination().getName()
                    + (correct ? " — correto!" : " — errado!" + dmgInfo));
        } else {
            log("🚫 " + player.getName() + " bloqueado: "
                    + result.getBlockReason().name());
        }
    }

    private void navigateToGameOver() {
        MainApp.showGameOver(engine.getWinner(), engine);
    }
}