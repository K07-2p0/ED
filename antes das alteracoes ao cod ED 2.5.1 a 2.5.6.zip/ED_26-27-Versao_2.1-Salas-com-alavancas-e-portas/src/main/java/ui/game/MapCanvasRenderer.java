package ui.game;

import Exceptions.EmptyCollectionException;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.util.Duration;
import model.GameMap;
import model.Location;
import model.Player;
import model.ShortcutEdge;
import Lists.DoublyLinkedList;
import Lists.ListADT;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Responsável <b>exclusivamente</b> por desenhar o estado do mapa num
 * {@link Pane} JavaFX.
 *
 * <p>Esta classe não conhece {@code GameEngine} nem lógica de turnos.
 * Recebe um snapshot do estado e redesenha o canvas de forma
 * <em>stateless</em>.</p>
 *
 * <h2>Sistema de cores data-driven</h2>
 * <p>A cor de cada sala é lida diretamente de {@link Location#getColor()}.
 * O renderer <b>nunca</b> infere cor a partir de {@link Location.LocationType}
 * nem faz switch por tipo. Se {@code getColor()} devolver {@code null}
 * (mapa sem campo {@code color}), aplica-se a cor de fallback
 * {@link #NODE_COLOR_FALLBACK}.</p>
 *
 * <p>Exceção intencional: salas com {@code dangerLevel == 5} recebem
 * um anel pulsante dourado, ativado <b>apenas pelo nível de perigo</b>,
 * independentemente do tema ou cor da sala.</p>
 *
 * <h2>Fundo Voronoi por biome (C2)</h2>
 * <p>Quando o mapa define o campo {@code "biome_types"} no JSON raiz,
 * o fundo do canvas é pintado com um diagrama de Voronoi em blocos de 4×4 px:
 * cada bloco é atribuído à {@link Location} mais próxima (distância
 * euclidiana ao quadrado) e colorido com as cores do biome dessa
 * localização — 75 % com a cor primária e 25 % com a secundária,
 * usando o hash determinístico {@code ((x*73856093)^(y*19349663))%100}.
 * O {@link Canvas} de fundo é adicionado como primeiro filho do pane,
 * imediatamente a seguir ao {@code clear()} que inicia cada render.
 * Quando o mapa não define {@code "biome_types"}, o método retorna
 * imediatamente e o fundo definido no CSS/FXML mantém-se
 * (retrocompatibilidade total).</p>
 *
 * <h2>Cores fixas (papel estrutural)</h2>
 * <ul>
 *   <li>Dourado ({@code #FFD700}) — borda ENDGAME</li>
 *   <li>Teal ({@code #1DE9B6})   — borda SPAWN</li>
 *   <li>Laranja ({@code #FF9800}) — atalho visível (tracejado)</li>
 *   <li>Laranja ({@code #FF9800}) — indicador de sala LEVER_ROOM</li>
 * </ul>
 *
 * <h2>Cores dos jogadores (até 4)</h2>
 * <ul>
 *   <li>Jogador 1 — ciano  ({@code #00E5FF})</li>
 *   <li>Jogador 2 — laranja ({@code #FF6B35})</li>
 *   <li>Jogador 3 — verde   ({@code #69FF47})</li>
 *   <li>Jogador 4 — amarelo ({@code #FFD700})</li>
 * </ul>
 *
 * <h2>Atalhos visíveis</h2>
 * <p>Os {@link ShortcutEdge} com {@code isVisible() == true} são desenhados
 * após as arestas normais em {@link #drawShortcuts()}, com linha tracejada
 * laranja e uma seta indicando a direção. A lista é fornecida via
 * {@link #setVisibleShortcuts(DoublyLinkedList)} antes de chamar
 * {@link #render(ListADT, ListADT)}.</p>
 *
 * <h2>Salas LEVER_ROOM</h2>
 * <p>As localizações para as quais {@link Location#isLeverRoom()} devolve
 * {@code true} recebem um indicador visual extra no método
 * {@link #drawNode(Location, boolean, boolean)}: além da borda laranja,
 * é desenhado o ícone "🚪" sobre o círculo da sala. Isto permite distinguir
 * visualmente as lever rooms mantendo o sistema de cores já existente.</p>
 *
 * <h2>Sem coleções nativas Java</h2>
 * <p>O cache de posições de nós ({@code nodePositions}) e a lista de atalhos
 * ({@code visibleShortcuts}) usam {@link DoublyLinkedList} da API_ED em vez
 * de {@code java.util.HashMap} / {@code java.util.List}. O método
 * {@link #drawBiomeBackground(double, double)} usa apenas arrays primitivos
 * e {@link DoublyLinkedList} internamente.</p>
 *
 * <h2>B10 — null-guard em drawPlayer()</h2>
 * <p>{@link #drawPlayer(Player, Location, int)} devolve imediatamente se
 * {@code loc} for {@code null}, evitando um {@link NullPointerException}
 * em {@code loc.getId()} durante setup, respawn ou qualquer estado transitório
 * em que a localização do jogador ainda não foi definida.</p>
 */
public class MapCanvasRenderer {

    // ── Constantes visuais ────────────────────────────────────────────

    private static final double NODE_RADIUS   = 22.0;
    private static final double PLAYER_RADIUS = 10.0;
    private static final Color  EDGE_COLOR    = Color.web("#8B7355");

    /**
     * Cor da linha tracejada dos atalhos visíveis.
     * Laranja vibrante para se distinguir das arestas normais castanhas.
     */
    private static final Color SHORTCUT_COLOR = Color.web("#FF9800");

    /**
     * Cor estrutural usada para destacar salas LEVER_ROOM.
     * Mantém coerência com os atalhos visíveis, reutilizando o mesmo laranja.
     */
    private static final Color LEVER_ROOM_COLOR = Color.web("#FF9800");

    /**
     * Comprimento da seta desenhada na ponta dos atalhos.
     */
    private static final double ARROW_LENGTH = 10.0;

    /**
     * Cor de fallback quando a sala não tem {@code color} definida no JSON.
     * Usada apenas para retrocompatibilidade com mapas antigos.
     */
    private static final Color NODE_COLOR_FALLBACK = Color.web("#3D2B1F");

    private static final Color  NODE_VISITED  = Color.web("#5C4033");
    private static final Color  TEXT_COLOR    = Color.web("#E8DCC8");
    private static final Color  WEIGHT_COLOR  = Color.web("#B8A898");

    /** Cor do anel pulsante das salas room5 (dangerLevel == 5). */
    private static final Color BOSS_RING_COLOR = Color.web("#FFD700");

    /**
     * Passo de grid (px) para o Voronoi de biomes.
     * Cada passo corresponde a um bloco 4×4 de pixels pintado com
     * {@link GraphicsContext#fillRect}.
     */
    private static final int BIOME_STEP = 4;

    /**
     * Cores dos jogadores (até 4 entradas).
     * O índice do jogador usa {@code index % PLAYER_COLORS.length}.
     */
    private static final Color[] PLAYER_COLORS = {
        Color.web("#00E5FF"),  // Jogador 1 — ciano
        Color.web("#FF6B35"),  // Jogador 2 — laranja
        Color.web("#69FF47"),  // Jogador 3 — verde lima
        Color.web("#FFD700")   // Jogador 4 — dourado
    };

    /**
     * Offsets 2×2 para até 4 jogadores no mesmo nó.
     * <ul>
     *   <li>Índice 0 — (-8, -20) canto superior esquerdo</li>
     *   <li>Índice 1 — (+8, -20) canto superior direito</li>
     *   <li>Índice 2 — (-8,  -4) canto inferior esquerdo</li>
     *   <li>Índice 3 — (+8,  -4) canto inferior direito</li>
     * </ul>
     */
    private static final double[][] PLAYER_OFFSETS = {
        { -8, -20 },
        {  8, -20 },
        { -8,  -4 },
        {  8,  -4 }
    };

    // ── Legenda ──────────────────────────────────────────────────

    private static final double LEG_PAD    = 10.0;
    private static final double LEG_MARGIN = 12.0;
    private static final double LEG_SWATCH = 12.0;
    private static final double LEG_LINE_H = 18.0;

    /**
     * Entradas estáticas da legenda — apenas elementos do mapa.
     * As cores dos jogadores são mostradas no painel de turno (sidebar),
     * não aqui.
     */
    private static final Object[][] LEGEND_STATIC = {
        { Color.web("#FFD700"),        "Borda Dourada = ENDGAME"    },
        { Color.web("#1DE9B6"),        "Borda Teal = SPAWN"         },
        { Color.web("#FF9800"),        "Borda laranja = LEVER_ROOM" },
        { Color.web("#6A0DAD"),        "Enigma"                     },
        { Color.web("#5C4033"),        "Visitada (sem cor)"         },
        { Color.web("#3D2B1F"),        "Por descobrir (sem cor)"    },
        { Color.rgb(220, 60, 60, 0.8), "Anel = Perigo"              },
        { Color.web("#FFD700", 0.9),  "Anel pulsante = room5"      },
        { Color.web("#FF9800"),        "Atalho visível (tracejado)" },
    };

    // ── Estado ──────────────────────────────────────────────────

    private final GameMap  map;
    private final Pane     pane;
    private final Location objective;

    /**
     * Cache de posições pixel por id de localização.
     *
     * <p>Usa {@link DoublyLinkedList} de entradas {@link NodePosition}
     * em vez de {@code java.util.HashMap}, cumprindo a restrição de
     * não usar a API de coleções nativa do Java.</p>
     */
    private final DoublyLinkedList<NodePosition> nodePositions = new DoublyLinkedList<>();

    /**
     * Lista de atalhos visíveis a desenhar sobre o mapa.
     *
     * <p>Fornecida externamente via {@link #setVisibleShortcuts(DoublyLinkedList)}
     * antes de cada chamada a {@link #render(ListADT, ListADT)}.
     * Atalhos com {@code isVisible() == false} são ignorados.</p>
     */
    private DoublyLinkedList<ShortcutEdge> visibleShortcuts = new DoublyLinkedList<>();

    // ── Construtor ───────────────────────────────────────────────────

    /**
     * Cria o renderer associado a um {@link Pane} e um {@link GameMap}.
     *
     * @param map       mapa do jogo
     * @param pane      painel JavaFX onde se desenha
     * @param objective localização objetivo
     */
    public MapCanvasRenderer(GameMap map, Pane pane, Location objective) {
        this.map       = map;
        this.pane      = pane;
        this.objective = objective;
    }

    // ── API pública ─────────────────────────────────────────────────

    /**
     * Define a lista de atalhos visíveis a sobrepor ao mapa.
     *
     * @param shortcuts lista de {@link ShortcutEdge} a desenhar;
     *                  pode ser vazia mas nunca {@code null}
     */
    public void setVisibleShortcuts(DoublyLinkedList<ShortcutEdge> shortcuts) {
        this.visibleShortcuts = (shortcuts != null) ? shortcuts : new DoublyLinkedList<>();
    }

    /**
     * Apaga e redesenha todo o canvas com o estado fornecido.
     *
     * <p>Ordem de desenho:</p>
     * <ol>
     *   <li>Fundo Voronoi por biome</li>
     *   <li>Arestas normais do grafo</li>
     *   <li>Atalhos visíveis</li>
     *   <li>Nós (salas)</li>
     *   <li>Marcadores dos jogadores</li>
     *   <li>Legenda</li>
     * </ol>
     *
     * @param playerPositions lista de pares jogador/localização atual
     * @param visitedIds      lista de ids de localizações já visitadas
     */
    public void render(ListADT<PlayerLocationEntry> playerPositions,
                       ListADT<String> visitedIds) {
        pane.getChildren().clear();
        drainList(nodePositions);

        double w = pane.getWidth();
        double h = pane.getHeight();
        if (w < 10 || h < 10) return;

        for (Location loc : map.getAllLocations()) {
            putNodePosition(loc.getId(),
                new double[]{ loc.getMapX() * w, loc.getMapY() * h });
        }

        drawBiomeBackground(w, h);
        drawEdges();
        drawShortcuts();
        for (Location loc : map.getAllLocations()) {
            drawNode(loc, containsId(visitedIds, loc.getId()), loc.equals(objective));
        }
        int idx = 0;
        for (PlayerLocationEntry entry : playerPositions) {
            drawPlayer(entry.getPlayer(), entry.getLocation(), idx++);
        }
        drawLegend(w, h);
    }

    /**
     * Devolve a posição pixel {@code [x, y]} de um nó por id.
     *
     * @param locationId id da localização
     * @return array {@code [x, y]}, ou {@code null} se não encontrado
     */
    public double[] getNodePosition(String locationId) {
        for (NodePosition np : nodePositions) {
            if (np.getId().equals(locationId)) return np.getPos();
        }
        return null;
    }

    // ── Fundo Voronoi por biome ───────────────────────────────────────────

    /**
     * Pinta o fundo do canvas com um diagrama de Voronoi baseado nos biomes
     * das localizações.
     *
     * <p>Guard defensivo: antes de adicionar o canvas, o método verifica
     * se o primeiro filho já é um {@link Canvas} e, em caso afirmativo,
     * remove-o. Isto protege contra chamadas repetidas sem {@code clear()}
     * intermediário.</p>
     *
     * @param w largura do pane em pixels
     * @param h altura do pane em pixels
     */
    private void drawBiomeBackground(double w, double h) {
        JSONArray biomeTypes = map.getBiomeTypes();
        if (biomeTypes == null || biomeTypes.isEmpty()) return;

        int n = biomeTypes.length();
        String[] biomeIds       = new String[n];
        String[] biomePrimaries = new String[n];
        String[] biomeSecondaries = new String[n];
        for (int i = 0; i < n; i++) {
            JSONObject b = biomeTypes.getJSONObject(i);
            biomeIds[i]         = b.optString("id", "");
            biomePrimaries[i]   = b.optString("primary",   "#1A0F0A");
            biomeSecondaries[i] = b.optString("secondary", "#2D1B0E");
        }

        DoublyLinkedList<BiomePoint> points = new DoublyLinkedList<>();
        for (Location loc : map.getAllLocations()) {
            String biomeId = loc.getBiome();
            if (biomeId == null) continue;
            String primary = null, secondary = null;
            for (int i = 0; i < n; i++) {
                if (biomeIds[i].equals(biomeId)) {
                    primary   = biomePrimaries[i];
                    secondary = biomeSecondaries[i];
                    break;
                }
            }
            if (primary == null) continue;
            double px = loc.getMapX() * w;
            double py = loc.getMapY() * h;
            points.addLast(new BiomePoint(px, py, primary, secondary));
        }
        if (points.isEmpty()) return;

        int m = points.size();
        double[] bx  = new double[m];
        double[] by  = new double[m];
        String[] bp  = new String[m];
        String[] bs  = new String[m];
        int k = 0;
        for (BiomePoint pt : points) {
            bx[k] = pt.x; by[k] = pt.y;
            bp[k] = pt.primary; bs[k] = pt.secondary;
            k++;
        }

        Canvas bgCanvas = new Canvas(w, h);
        bgCanvas.setMouseTransparent(true);
        GraphicsContext gc = bgCanvas.getGraphicsContext2D();

        int iw = (int) Math.ceil(w / BIOME_STEP);
        int ih = (int) Math.ceil(h / BIOME_STEP);
        for (int gy = 0; gy < ih; gy++) {
            for (int gx = 0; gx < iw; gx++) {
                double cx = gx * BIOME_STEP + BIOME_STEP * 0.5;
                double cy = gy * BIOME_STEP + BIOME_STEP * 0.5;
                int best = 0;
                double bestDist = Double.MAX_VALUE;
                for (int i = 0; i < m; i++) {
                    double dx = cx - bx[i], dy = cy - by[i];
                    double d = dx * dx + dy * dy;
                    if (d < bestDist) { bestDist = d; best = i; }
                }
                int hash = Math.abs((gx * 73856093) ^ (gy * 19349663)) % 100;
                gc.setFill(Color.web(hash < 75 ? bp[best] : bs[best]));
                gc.fillRect(gx * BIOME_STEP, gy * BIOME_STEP, BIOME_STEP, BIOME_STEP);
            }
        }

        // Guard: remove stale bg canvas if present (resize protection)
        if (!pane.getChildren().isEmpty()
                && pane.getChildren().get(0) instanceof Canvas) {
            pane.getChildren().remove(0);
        }
        pane.getChildren().add(bgCanvas);
    }

    // ── Arestas ───────────────────────────────────────────────────────────

    /**
     * Desenha todas as arestas do grafo como linhas castanhas simples.
     * Cada aresta é desenhada uma vez (origem < destino por ID para evitar
     * duplicação no grafo não-dirigido).
     */
    private void drawEdges() {
        for (Location from : map.getAllLocations()) {
            double[] posFrom = getNodePosition(from.getId());
            if (posFrom == null) continue;
            for (Location to : map.getNeighbors(from)) {
                if (from.getId().compareTo(to.getId()) >= 0) continue;
                double[] posTo = getNodePosition(to.getId());
                if (posTo == null) continue;

                Line line = new Line(posFrom[0], posFrom[1], posTo[0], posTo[1]);
                line.setStroke(EDGE_COLOR);
                line.setStrokeWidth(2.0);

                double weight = map.getDistance(from, to);
                pane.getChildren().add(line);
                if (weight > 0) {
                    double mx = (posFrom[0] + posTo[0]) / 2.0;
                    double my = (posFrom[1] + posTo[1]) / 2.0;
                    Text wt = new Text(mx, my, String.valueOf((int) weight));
                    wt.setFill(WEIGHT_COLOR);
                    wt.setFont(Font.font("System", FontWeight.NORMAL, 10));
                    pane.getChildren().add(wt);
                }
            }
        }
    }

    // ── Atalhos visíveis ─────────────────────────────────────────────────

    /**
     * Desenha os atalhos visíveis com linha tracejada laranja e seta
     * de direcção.
     */
    private void drawShortcuts() {
        for (ShortcutEdge se : visibleShortcuts) {
            if (!se.isVisible()) continue;
            double[] posFrom = getNodePosition(se.getFrom().getId());
            double[] posTo   = getNodePosition(se.getTo().getId());
            if (posFrom == null || posTo == null) continue;

            Line line = new Line(posFrom[0], posFrom[1], posTo[0], posTo[1]);
            line.setStroke(SHORTCUT_COLOR);
            line.setStrokeWidth(2.5);
            line.getStrokeDashArray().addAll(10.0, 6.0);
            pane.getChildren().add(line);

            // Seta na ponta
            double dx = posTo[0] - posFrom[0];
            double dy = posTo[1] - posFrom[1];
            double len = Math.sqrt(dx * dx + dy * dy);
            if (len > 1e-9) {
                double ux = dx / len, uy = dy / len;
                double ax = posTo[0] - ARROW_LENGTH * ux;
                double ay = posTo[1] - ARROW_LENGTH * uy;
                double px =  uy * (ARROW_LENGTH / 2.0);
                double py = -ux * (ARROW_LENGTH / 2.0);

                Line a1 = new Line(posTo[0], posTo[1], ax + px, ay + py);
                Line a2 = new Line(posTo[0], posTo[1], ax - px, ay - py);
                a1.setStroke(SHORTCUT_COLOR); a1.setStrokeWidth(2.0);
                a2.setStroke(SHORTCUT_COLOR); a2.setStrokeWidth(2.0);
                pane.getChildren().addAll(a1, a2);
            }
        }
    }

    // ── Nós ──────────────────────────────────────────────────────────────

    /**
     * Desenha um nó (sala) com a cor definida no JSON, borda de papel
     * estrutural, e ícone de lever room se aplicável.
     *
     * @param loc       localização a desenhar
     * @param visited   true se a sala já foi visitada por algum jogador
     * @param isObjective true se é a sala objetivo (ENDGAME)
     */
    private void drawNode(Location loc, boolean visited, boolean isObjective) {
        double[] pos = getNodePosition(loc.getId());
        if (pos == null) return;

        double cx = pos[0], cy = pos[1];

        // Cor de fundo da sala
        Color baseColor;
        if (visited) {
            baseColor = NODE_VISITED;
        } else {
            String colorHex = loc.getColor();
            baseColor = (colorHex != null && !colorHex.isBlank())
                    ? tryParseColor(colorHex, NODE_COLOR_FALLBACK)
                    : NODE_COLOR_FALLBACK;
        }

        // Anel de perigo (nível > 0)
        int danger = loc.getDangerLevel();
        if (danger > 0 && danger < 5) {
            double alpha = 0.3 + 0.1 * danger;
            Circle ring = new Circle(cx, cy, NODE_RADIUS + 6);
            ring.setFill(Color.TRANSPARENT);
            ring.setStroke(Color.rgb(220, 60, 60, alpha));
            ring.setStrokeWidth(danger * 1.5);
            pane.getChildren().add(ring);
        }

        // Anel pulsante dourado para dangerLevel == 5 (boss room)
        if (danger == 5) {
            Circle bossRing = new Circle(cx, cy, NODE_RADIUS + 8);
            bossRing.setFill(Color.TRANSPARENT);
            bossRing.setStroke(BOSS_RING_COLOR);
            bossRing.setStrokeWidth(3.0);
            bossRing.setOpacity(0.9);
            Timeline pulse = new Timeline(
                new KeyFrame(Duration.ZERO,
                    new KeyValue(bossRing.opacityProperty(), 0.9)),
                new KeyFrame(Duration.millis(700),
                    new KeyValue(bossRing.opacityProperty(), 0.25))
            );
            pulse.setAutoReverse(true);
            pulse.setCycleCount(Timeline.INDEFINITE);
            pulse.play();
            pane.getChildren().add(bossRing);
        }

        // Círculo principal
        Circle node = new Circle(cx, cy, NODE_RADIUS);
        node.setFill(baseColor);

        // Borda de papel estrutural
        Color borderColor;
        double borderWidth;
        if (isObjective) {
            borderColor = Color.web("#FFD700");
            borderWidth = 3.5;
        } else if (loc.isSpawn()) {
            borderColor = Color.web("#1DE9B6");
            borderWidth = 2.5;
        } else if (loc.isLeverRoom()) {
            borderColor = LEVER_ROOM_COLOR;
            borderWidth = 2.5;
        } else if (loc.hasEnigmaByLevel()) {
            borderColor = Color.web("#6A0DAD");
            borderWidth = 2.0;
        } else {
            borderColor = EDGE_COLOR;
            borderWidth = 1.5;
        }
        node.setStroke(borderColor);
        node.setStrokeWidth(borderWidth);
        pane.getChildren().add(node);

        // Ícone de lever room
        if (loc.isLeverRoom()) {
            Text icon = new Text(cx - 7, cy + 5, "🚪");
            icon.setFont(Font.font("System", 14));
            pane.getChildren().add(icon);
        }

        // Nome da sala
        Text label = new Text(loc.getName());
        label.setFill(TEXT_COLOR);
        label.setFont(Font.font("System", FontWeight.BOLD, 10));
        double lw = label.getBoundsInLocal().getWidth();
        label.setX(cx - lw / 2.0);
        label.setY(cy + NODE_RADIUS + 13);
        pane.getChildren().add(label);
    }

    // ── Jogadores ─────────────────────────────────────────────────────────

    /**
     * Desenha o marcador de um jogador no nó correspondente à sua
     * localização actual.
     *
     * <p><b>B10 — null-guard:</b> se {@code loc} for {@code null}
     * (setup incompleto, respawn transitório ou jogador sem localização
     * atribuída), o método retorna imediatamente sem desenhar nada,
     * evitando o {@link NullPointerException} que ocorria em
     * {@code loc.getId()} antes deste fix.</p>
     *
     * @param player jogador a desenhar
     * @param loc    localização actual do jogador; pode ser {@code null}
     * @param index  índice do jogador (0-based) para cor e offset
     */
    private void drawPlayer(Player player, Location loc, int index) {
        if (loc == null) return;   // B10: guard — avoid NPE when location not yet set
        double[] pos = getNodePosition(loc.getId());
        if (pos == null) return;

        Color  color  = PLAYER_COLORS[index % PLAYER_COLORS.length];
        double[] off  = PLAYER_OFFSETS[index % PLAYER_OFFSETS.length];
        double  px    = pos[0] + off[0];
        double  py    = pos[1] + off[1];

        Circle marker = new Circle(px, py, PLAYER_RADIUS);
        marker.setFill(color);
        marker.setStroke(Color.WHITE);
        marker.setStrokeWidth(1.5);
        pane.getChildren().add(marker);

        // Inicial do jogador
        String initial = player.getName().isEmpty()
                ? "?" : String.valueOf(player.getName().charAt(0)).toUpperCase();
        Text initText = new Text(px - 4, py + 4, initial);
        initText.setFill(Color.web("#1A0F0A"));
        initText.setFont(Font.font("System", FontWeight.BOLD, 11));
        pane.getChildren().add(initText);
    }

    // ── Legenda ──────────────────────────────────────────────────────────

    /**
     * Desenha a legenda estática no canto inferior direito do canvas.
     *
     * @param w largura do pane
     * @param h altura do pane
     */
    private void drawLegend(double w, double h) {
        int rows = LEGEND_STATIC.length;
        double boxW = 210;
        double boxH = LEG_PAD * 2 + rows * LEG_LINE_H;
        double x0   = w - boxW - LEG_MARGIN;
        double y0   = h - boxH - LEG_MARGIN;

        Rectangle bg = new Rectangle(x0, y0, boxW, boxH);
        bg.setFill(Color.rgb(15, 8, 4, 0.82));
        bg.setStroke(Color.web("#5C4033"));
        bg.setStrokeWidth(1.0);
        bg.setArcWidth(8);
        bg.setArcHeight(8);
        pane.getChildren().add(bg);

        for (int i = 0; i < rows; i++) {
            Color  c    = (Color)  LEGEND_STATIC[i][0];
            String desc = (String) LEGEND_STATIC[i][1];
            double lx   = x0 + LEG_PAD;
            double ly   = y0 + LEG_PAD + i * LEG_LINE_H + LEG_LINE_H * 0.5;

            Rectangle swatch = new Rectangle(lx, ly - LEG_SWATCH * 0.5,
                                             LEG_SWATCH, LEG_SWATCH);
            swatch.setFill(c);
            swatch.setArcWidth(3); swatch.setArcHeight(3);
            pane.getChildren().add(swatch);

            Text t = new Text(lx + LEG_SWATCH + 6, ly + 4, desc);
            t.setFill(TEXT_COLOR);
            t.setFont(Font.font("System", 10));
            pane.getChildren().add(t);
        }
    }

    // ── Tipos de dados internos ───────────────────────────────────────────

    /**
     * Par (id, posição pixel) para o cache de posições de nós.
     * Substitui {@code java.util.HashMap.Entry}.
     */
    private static final class NodePosition {
        private final String   id;
        private final double[] pos;
        NodePosition(String id, double[] pos) { this.id = id; this.pos = pos; }
        String   getId()  { return id;  }
        double[] getPos() { return pos; }
    }

    /**
     * Ponto de biome: posição pixel e cores primária/secundária.
     * Usado internamente em {@link #drawBiomeBackground(double, double)}.
     */
    private static final class BiomePoint {
        final double x, y;
        final String primary, secondary;
        BiomePoint(double x, double y, String primary, String secondary) {
            this.x = x; this.y = y;
            this.primary = primary; this.secondary = secondary;
        }
    }

    /**
     * Par imutável (Player, Location) passado ao renderer pelo controller.
     *
     * <p>Substitui {@code Map.Entry<Player, Location>} da API nativa,
     * cumprindo a restrição de não usar coleções nativas do Java.</p>
     */
    public static final class PlayerLocationEntry {
        private final Player   player;
        private final Location location;

        /**
         * Cria uma entrada de posição de jogador.
         *
         * @param player   jogador
         * @param location localização actual (pode ser {@code null} —
         *                 {@link MapCanvasRenderer#drawPlayer} trata o caso)
         */
        public PlayerLocationEntry(Player player, Location location) {
            this.player   = player;
            this.location = location;
        }

        /** @return jogador */
        public Player   getPlayer()   { return player;   }
        /** @return localização actual, possivelmente {@code null} */
        public Location getLocation() { return location; }
    }

    // ── Utilitários ─────────────────────────────────────────────────────

    private void putNodePosition(String id, double[] pos) {
        nodePositions.addLast(new NodePosition(id, pos));
    }

    private boolean containsId(ListADT<String> list, String id) {
        for (String s : list) if (s.equals(id)) return true;
        return false;
    }

    private <T> void drainList(DoublyLinkedList<T> list) {
        while (!list.isEmpty()) {
            try { list.removeFirst(); } catch (EmptyCollectionException ignored) {}
        }
    }

    private Color tryParseColor(String hex, Color fallback) {
        try { return Color.web(hex); }
        catch (Exception e) { return fallback; }
    }
}