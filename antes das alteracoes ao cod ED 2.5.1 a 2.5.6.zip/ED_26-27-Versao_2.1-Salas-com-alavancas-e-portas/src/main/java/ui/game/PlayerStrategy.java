package ui.game;

import engine.strategy.BotStrategy;
import model.Player;
import Lists.DoublyLinkedList;

/**
 * Registo externo de {@link BotStrategy} por {@link Player}.
 *
 * <p>O modelo {@link Player} é imutável no que toca a estratégias —
 * não tem campo {@code strategy} para não contaminar o domínio com
 * conceitos de UI/engine. Esta classe mantém o mapeamento fora do modelo,
 * usando uma {@link DoublyLinkedList} de pares (sem java.util.HashMap).</p>
 *
 * <p>Ciclo de vida: registado pelo {@code GameSetupController} e
 * consultado pelo {@code GameViewController} durante o loop de turnos.</p>
 */
public class PlayerStrategy {

    /**
     * Par (jogador, estratégia) para a lista interna.
     */
    private static class Entry {
        final Player      player;
        final BotStrategy strategy;
        Entry(Player p, BotStrategy s) { player = p; strategy = s; }
    }

    /** Lista de pares registados — substituiu java.util.HashMap. */
    private static final DoublyLinkedList<Entry> entries = new DoublyLinkedList<>();

    /**
     * Regista a estratégia de um jogador.
     *
     * @param player   jogador
     * @param strategy estratégia a associar (pode ser {@code null} para humano)
     */
    public static void register(Player player, BotStrategy strategy) {
        // Remove entrada anterior se existir
        Entry toRemove = null;
        for (Entry e : entries) {
            if (e.player.equals(player)) { toRemove = e; break; }
        }
        try {
            if (toRemove != null) entries.remove(toRemove);
        } catch (Exception ignored) { }
        entries.addLast(new Entry(player, strategy));
    }

    /**
     * Devolve a estratégia associada a um jogador.
     *
     * @param player jogador a consultar
     * @return estratégia, ou {@code null} se for humano ou não registado
     */
    public static BotStrategy get(Player player) {
        for (Entry e : entries) {
            if (e.player.equals(player)) return e.strategy;
        }
        return null;
    }

    /**
     * Indica se um jogador tem estratégia de bot registada.
     *
     * @param player jogador a verificar
     * @return {@code true} se tiver estratégia não-nula
     */
    public static boolean isBot(Player player) {
        return get(player) != null;
    }

    /** Limpa todos os registos (útil ao reiniciar o jogo). */
    public static void clear() {
        while (!entries.isEmpty()) {
            try { entries.removeFirst(); } catch (Exception ignored) { break; }
        }
    }
}
