package ui.gameover;

import engine.GameEngine;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import model.Location;
import model.Player;
import ui.MainApp;
import ui.game.PlayerStrategy;
import Lists.DoublyLinkedList;

/**
 * Controller do Ecrã 3 — Fim de jogo.
 *
 * <p>Responsabilidades:</p>
 * <ul>
 *   <li>Receber o vencedor e o engine</li>
 *   <li>Mostrar o resultado final com estatísticas completas:
 *       HP final, passos totais e caminho percorrido por cada jogador,
 *       incluindo ciclos de vida anteriores a mortes/respawns.</li>
 *   <li>Reiniciar ({@link MainApp#showSetup()}) ou sair</li>
 * </ul>
 *
 * <h2>Historial usado</h2>
 * <p>Este controller usa exclusivamente {@link Player#getFullPathHistory()},
 * que é uma {@link DoublyLinkedList} permanente e nunca limpa, mesmo após
 * mortes e respawns. Entradas {@code null} na lista marcam os pontos de
 * morte/respawn e são exibidas como separadores visuais no caminho.</p>
 *
 * <p>Não usa {@code getMovementHistory()} (a {@link Queues_Stacks.LinkedStack}
 * que é limpa no respawn e serve apenas para backtrack interno).</p>
 */
public class GameOverController {

    @FXML private Label    winnerLabel;
    @FXML private Label    summaryLabel;
    @FXML private TextArea statsArea;

    /**
     * Inicializa o ecrã com o resultado da partida.
     *
     * @param winner jogador vencedor (pode ser {@code null} em caso de empate)
     * @param engine engine da partida terminada
     */
    public void initResult(Player winner, GameEngine engine) {

        // ── Título
        winnerLabel.setText(winner != null
                ? "🏆 " + winner.getName() + " venceu!"
                : "🤝 Empate!");

        // ── Resumo rápido: uma linha por jogador
        // Usa fullPathHistory para contar o total de passos reais (todos os ciclos)
        StringBuilder sb = new StringBuilder();
        for (Player p : engine.getPlayers()) {
            int totalSteps = countRealSteps(p.getFullPathHistory());
            sb.append(p.getName())
              .append(" — HP: ").append(p.getHealth())
              .append(" | Passos: ").append(totalSteps)
              .append("\n");
        }
        summaryLabel.setText(sb.toString().trim());

        // ── Bloco de estatísticas detalhadas
        if (statsArea != null) {
            statsArea.setEditable(false);
            statsArea.setWrapText(true);
            statsArea.setText(buildStats(engine));
        }
    }

    /**
     * Conta o número de passos reais no caminho completo,
     * excluindo as entradas {@code null} (marcadores de morte/respawn).
     *
     * @param history historial completo do jogador
     * @return número de localizações visitadas (excluindo marcadores)
     */
    private int countRealSteps(DoublyLinkedList<Location> history) {
        if (history == null) return 0;
        int count = 0;
        for (Location loc : history) {
            if (loc != null) count++;
        }
        // Subtrai 1 para não contar a posição inicial como "passo"
        return Math.max(0, count - 1);
    }

    /**
     * Constrói o texto de estatísticas detalhadas para todos os jogadores.
     *
     * <p>Itera {@link Player#getFullPathHistory()} diretamente (a
     * {@link DoublyLinkedList} é {@code Iterable}) sem necessidade de
     * stack auxiliar. Entradas {@code null} são exibidas como separadores
     * de morte/respawn.</p>
     *
     * @param engine engine da partida terminada
     * @return texto formatado pronto a exibir
     */
    private String buildStats(GameEngine engine) {
        StringBuilder out = new StringBuilder();

        for (Player p : engine.getPlayers()) {
            out.append("══════════════════════════════\n");
            out.append("👤 ").append(p.getName()).append("\n");
            out.append("  ❤ HP final : ").append(p.getHealth()).append("/100\n");

            DoublyLinkedList<Location> history = p.getFullPathHistory();
            int totalSteps = countRealSteps(history);
            out.append("  👣 Passos   : ").append(totalSteps).append(" (total, todos os ciclos de vida)\n");

            if (history != null && !history.isEmpty()) {
                out.append("  🗺️ Caminho completo (inicial → final):\n");
                appendFullPath(out, history);
            } else {
                out.append("  🗺️ Caminho: (sem movimentos registados)\n");
            }
        }

        out.append("══════════════════════════════\n");
        return out.toString();
    }

    /**
     * Itera e imprime o caminho contido no historial completo.
     *
     * <p>Como {@link DoublyLinkedList} é {@code Iterable}, a iteração
     * é directa. Entradas {@code null} são exibidas como um separador
     * de morte/respawn no meio do caminho.</p>
     *
     * @param out     {@link StringBuilder} onde o caminho é escrito
     * @param history historial completo do jogador
     */
    private void appendFullPath(StringBuilder out, DoublyLinkedList<Location> history) {
        int step = 0;
        for (Location loc : history) {
            if (loc == null) {
                // Marcador de morte/respawn inserido por Player.respawn()
                out.append("      ☠️ ---- MORTE / RESPAWN ----\n");
            } else {
                // Primeiro elemento é o spawn (não conta como passo)
                if (step == 0) {
                    out.append("      ").append("🔵 ").append(loc.getName())
                       .append(" (início)\n");
                } else {
                    out.append("      ").append(step).append(". ")
                       .append(loc.getName()).append("\n");
                }
                step++;
            }
        }
    }

    /**
     * Volta ao ecrã de configuração para jogar novamente.
     */
    @FXML
    private void onPlayAgain() {
        PlayerStrategy.clear();
        MainApp.showSetup();
    }

    /**
     * Fecha a aplicação.
     */
    @FXML
    private void onExit() {
        javafx.application.Platform.exit();
    }
}
