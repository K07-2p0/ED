package ui.setup;

import engine.GameDifficulty;
import engine.GameEngine;
import engine.strategy.BotStrategy;
import engine.strategy.DijkstraBot;
import engine.strategy.HybridBot;
import engine.strategy.RandomBot;
import io.MapLoader;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import model.GameMap;
import model.Location;
import model.Player;
import ui.MainApp;
import ui.game.PlayerStrategy;
import Lists.ArrayUnorderedList;
import Lists.ListADT;
import Lists.UnorderedListADT;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * Controller do Ecrã de Configuração de jogo.
 *
 * <p>Suporta 1 a 4 jogadores de forma dinâmica. O número de jogadores
 * é seleccionado via {@link #playerCountSpinner}; o método
 * {@link #rebuildPlayerRows(int)} reconstrói o contentor
 * {@link #playersContainer} com uma {@link PlayerConfigRow} por jogador.</p>
 *
 * <p>O campo <em>Localização Objetivo</em> foi substituído por
 * {@link #enigmaThemeCombo}, que permite ao jogador escolher o tema
 * dos enigmas. O caminho do ficheiro de enigmas correspondente é
 * passado ao {@link GameEngine} no início da partida.</p>
 *
 * <p><b>Temas disponíveis:</b></p>
 * <ul>
 *   <li>Todos — enigmas.json (ficheiro misto de retrocompatibilidade)</li>
 *   <li>Minecraft — enigmas_minecraft.json</li>
 *   <li>Cultura Geral — enigmas_general.json</li>
 *   <li>Cibersegurança — enigmas_cybersecurity.json</li>
 * </ul>
 *
 * <p>Nenhuma coleção nativa do Java é usada nesta classe.
 * Todas as estruturas provêm da API_ED.</p>
 */
public class GameSetupController implements Initializable {

    // ── Campos FXML ───────────────────────────────────────────────────────────

    @FXML private Spinner<Integer>  playerCountSpinner;
    @FXML private HBox              playersContainer;
    @FXML private ComboBox<String>  mapCombo;
    /** Combo de seleção do tema dos enigmas (substitui objectiveCombo). */
    @FXML private ComboBox<String>  enigmaThemeCombo;
    /** Combo de seleção da dificuldade do jogo. */
    @FXML private ComboBox<String>  difficultyCombo;
    @FXML private Label             errorLabel;

    // ── Constantes ────────────────────────────────────────────────────────────

    private static final String[] PLAYER_TYPES  =
        { "Humano", "RandomBot", "HybridBot", "DijkstraBot" };
    /** Cores de label de cada jogador (ciano, laranja, verde, amarelo). */
    private static final String[] PLAYER_COLORS =
        { "#00E5FF", "#FF6B35", "#69FF47", "#FFD700" };
    private static final String   MAPS_DIR      = "maps/";
    private static final int      DEFAULT_PLAYERS = 2;

    /**
     * Mapeamento de nome de tema visível → caminho do ficheiro de enigmas
     * (relativo à raiz do classpath).
     */
    private static final String[][] ENIGMA_THEMES = {
        { "Todos",           "enigmas/enigmas.json"              },
        { "Minecraft",       "enigmas/enigmas_minecraft.json"    },
        { "Cultura Geral",   "enigmas/enigmas_general.json"      },
        { "Cibersegurança",  "enigmas/enigmas_cybersecurity.json"}
    };

    /**
     * Mapeamento de nome visível → constante {@link GameDifficulty}.
     */
    private static final Object[][] DIFFICULTY_OPTIONS = {
        { "Easy",    GameDifficulty.EASY    },
        { "Normal",   GameDifficulty.NORMAL   },
        { "Hard",  GameDifficulty.HARD  },
        { "Hardcore", GameDifficulty.HARDCORE }
    };

    // ── Estado dinâmico ──────────────────────────────────────────────────────

    /**
     * Lista dinâmica de rows de jogadores (API_ED);
     * reconstruída em {@link #rebuildPlayerRows}.
     */
    private final UnorderedListADT<PlayerConfigRow> playerRows = new ArrayUnorderedList<>();

    /** Último mapa carregado com sucesso; usado para popular startCombos. */
    private GameMap cachedMap;

    // ── Inicialização ────────────────────────────────────────────────────

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        errorLabel.setVisible(false);

        // Spinner 1-4 jogadores
        SpinnerValueFactory<Integer> svf =
            new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 4, DEFAULT_PLAYERS);
        playerCountSpinner.setValueFactory(svf);
        playerCountSpinner.valueProperty().addListener(
            (obs, oldV, newV) -> rebuildPlayerRows(newV));

        // CRITICO: registar onAction ANTES de setValue
        mapCombo.setOnAction(e -> {
            GameMap map = loadSelectedMap();
            if (map != null) { cachedMap = map; populateStartCombos(map); }
            else             populateFallbackStartCombos();
        });

        populateMapCombo();
        populateEnigmaThemeCombo();
        populateDifficultyCombo();
        rebuildPlayerRows(DEFAULT_PLAYERS);
    }

    // ── Construção dinâmica das rows ───────────────────────────────────────

    /**
     * Reconstrói o {@link #playersContainer} com {@code n} colunas de jogador.
     *
     * @param n número de jogadores (1–4)
     */
    private void rebuildPlayerRows(int n) {
        playersContainer.getChildren().clear();
        clearList(playerRows);

        for (int i = 0; i < n; i++) {
            String color = PLAYER_COLORS[i % PLAYER_COLORS.length];
            PlayerConfigRow row = new PlayerConfigRow(i + 1, color);

            row.typeCombo.setItems(FXCollections.observableArrayList(PLAYER_TYPES));
            row.typeCombo.setValue(i == 0 ? "Humano" : (i == 1 ? "DijkstraBot" : "RandomBot"));

            playerRows.addToRear(row);
            playersContainer.getChildren().add(row.container);
        }

        if (cachedMap != null) populateStartCombos(cachedMap);
    }

    // ── População dos combos ─────────────────────────────────────────────

    /**
     * Preenche o {@link #mapCombo} com os ficheiros JSON da directoria de mapas.
     */
    private void populateMapCombo() {
        UnorderedListADT<String> mapNames = new ArrayUnorderedList<>();
        try {
            URL mapsUrl = getClass().getClassLoader().getResource(MAPS_DIR);
            if (mapsUrl == null)
                mapsUrl = getClass().getResource("/" + MAPS_DIR);
            if (mapsUrl != null) {
                File dir  = new File(mapsUrl.toURI());
                File[] js = dir.listFiles((d, nm) -> nm.endsWith(".json"));
                if (js != null) for (File f : js) mapNames.addToRear(f.getName());
            }
        } catch (Exception e) {
            System.err.println("[Setup] Erro a listar mapas: " + e.getMessage());
        }
        if (mapNames.isEmpty()) mapNames.addToRear("map_default.json");

        // Converte para ObservableList (necessário para JavaFX ComboBox)
        javafx.collections.ObservableList<String> obs =
                FXCollections.observableArrayList();
        for (String name : mapNames) obs.add(name);
        mapCombo.setItems(obs);
        mapCombo.setValue(obs.get(0));

        Platform.runLater(() -> {
            if (!playerRows.isEmpty() &&
                    getFirstRow().startCombo.getItems().isEmpty()) {
                GameMap map = loadSelectedMap();
                if (map != null) { cachedMap = map; populateStartCombos(map); }
                else             populateFallbackStartCombos();
            }
        });
    }

    /**
     * Preenche o {@link #enigmaThemeCombo} com os temas disponíveis,
     * derivados de {@link #ENIGMA_THEMES}.
     */
    private void populateEnigmaThemeCombo() {
        UnorderedListADT<String> labels = new ArrayUnorderedList<>();
        for (String[] pair : ENIGMA_THEMES) labels.addToRear(pair[0]);

        javafx.collections.ObservableList<String> obs =
                FXCollections.observableArrayList();
        for (String lbl : labels) obs.add(lbl);
        enigmaThemeCombo.setItems(obs);
        enigmaThemeCombo.setValue(obs.get(0));
    }

    /**
     * Preenche o startCombo de cada row com as salas SPAWN do mapa.
     *
     * @param map mapa carregado
     */
    private void populateStartCombos(GameMap map) {
        UnorderedListADT<String> entries = new ArrayUnorderedList<>();
        for (Location loc : map.getAllLocations()) {
            if (loc.isSpawn())
                entries.addToRear(loc.getId() + " — " + loc.getName());
        }
        if (entries.isEmpty()) {
            for (Location loc : map.getAllLocations())
                entries.addToRear(loc.getId() + " — " + loc.getName());
        }

        javafx.collections.ObservableList<String> obs =
                FXCollections.observableArrayList();
        for (String e : entries) obs.add(e);

        int i = 0;
        for (PlayerConfigRow row : playerRows) {
            row.startCombo.setItems(obs);
            row.startCombo.setValue(obs.isEmpty() ? null : obs.get(i % obs.size()));
            i++;
        }
    }

    /**
     * Preenche os combos de entrada com valores de fallback quando
     * nenhum mapa está disponível.
     */
    private void populateFallbackStartCombos() {
        UnorderedListADT<String> entries = new ArrayUnorderedList<>();
        entries.addToRear("aldeia — Aldeia Central");
        entries.addToRear("floresta — Floresta Sombria");
        entries.addToRear("minas — Minas de Pedra");
        entries.addToRear("caverna — Caverna Gelada");

        javafx.collections.ObservableList<String> obs =
                FXCollections.observableArrayList();
        for (String e : entries) obs.add(e);

        int i = 0;
        for (PlayerConfigRow row : playerRows) {
            row.startCombo.setItems(obs);
            row.startCombo.setValue(obs.get(i % obs.size()));
            i++;
        }
    }

    // ── Botão Iniciar ────────────────────────────────────────────────────

    /**
     * Valida os campos dinâmicos, cria o {@link GameEngine} com o
     * ficheiro de enigmas do tema selecionado e navega para o jogo.
     */
    @FXML
    private void onStartGame() {
        errorLabel.setVisible(false);

        GameMap map = loadSelectedMap();
        if (map == null) { showError("Não foi possível carregar o mapa."); return; }

        Location objective = resolveObjective(map);
        if (objective == null) { showError("O mapa não tem localização objetivo definida."); return; }

        String enigmasPath = resolveEnigmasPath();
        GameDifficulty diff = resolveDifficulty();
        GameEngine engine   = new GameEngine(map, objective, enigmasPath, diff);

        int i = 0;
        for (PlayerConfigRow row : playerRows) {
            String name = row.nameField.getText().trim();
            if (name.isEmpty()) name = "Jogador " + (i + 1);

            Location start = resolveStartLocation(map, row.startCombo, name);
            if (start == null) return;

            if (start.equals(objective)) {
                showError(name + " não pode começar no objetivo.");
                return;
            }

            boolean isBot = !row.typeCombo.getValue().equals("Humano");
            Player  p     = new Player("p" + (i + 1), name, isBot, start);
            engine.addPlayer(p);
            PlayerStrategy.register(p, buildStrategy(row.typeCombo.getValue()));
            i++;
        }

        engine.start();
        MainApp.showGame(engine);
    }

    // ── Helpers ─────────────────────────────────────────────────────────

    /**
     * Devolve a primeira {@link PlayerConfigRow} da lista.
     * Usado para verificar se o startCombo já foi populado.
     *
     * @return primeira row, ou {@code null} se a lista estiver vazia
     */
    private PlayerConfigRow getFirstRow() {
        for (PlayerConfigRow row : playerRows) return row;
        return null;
    }

    /**
     * Devolve o caminho do ficheiro de enigmas correspondente ao tema
     * selecionado no {@link #enigmaThemeCombo}.
     *
     * @return caminho relativo ao classpath
     */
    private String resolveEnigmasPath() {
        String selected = enigmaThemeCombo.getValue();
        for (String[] pair : ENIGMA_THEMES) {
            if (pair[0].equals(selected)) return pair[1];
        }
        return ENIGMA_THEMES[0][1];
    }

    /**
     * Preenche o {@link #difficultyCombo} com os nomes das dificuldades.
     */
    private void populateDifficultyCombo() {
        javafx.collections.ObservableList<String> obs =
                FXCollections.observableArrayList();
        for (Object[] pair : DIFFICULTY_OPTIONS) obs.add((String) pair[0]);
        difficultyCombo.setItems(obs);
        difficultyCombo.setValue("Normal");
    }

    /**
     * Devolve a {@link GameDifficulty} correspondente à seleção do
     * {@link #difficultyCombo}.
     *
     * @return dificuldade selecionada; {@link GameDifficulty#NORMAL} por defeito
     */
    private GameDifficulty resolveDifficulty() {
        String selected = difficultyCombo.getValue();
        for (Object[] pair : DIFFICULTY_OPTIONS) {
            if (pair[0].equals(selected)) return (GameDifficulty) pair[1];
        }
        return GameDifficulty.NORMAL;
    }

    /**
     * Determina a localização objetivo do mapa.
     * Prefere salas com {@code isEndgame() == true}; se não existir, usa a última sala iterada.
     *
     * @param map mapa carregado
     * @return localização objetivo, ou {@code null} se o mapa estiver vazio
     */
    private Location resolveObjective(GameMap map) {
        Location last = null;
        for (Location loc : map.getAllLocations()) {
            if (loc.isEndgame()) return loc;
            last = loc;
        }
        return last;
    }

    private Location resolveStartLocation(GameMap map,
                                           ComboBox<String> combo,
                                           String playerName) {
        String entry = combo.getValue();
        if (entry == null) { showError("Seleciona uma entrada para " + playerName + "."); return null; }
        String id = entry.split(" — ")[0].trim();
        try { return map.getById(id); }
        catch (Exception e) { showError("Entrada inválida para " + playerName + "."); return null; }
    }

    /**
     * Tenta carregar o mapa selecionado no {@link #mapCombo}.
     *
     * @return mapa carregado, ou {@code null} em caso de erro
     */
    private GameMap loadSelectedMap() {
        String fileName = mapCombo.getValue();
        if (fileName == null) return null;
        String[] paths = { MAPS_DIR + fileName, fileName };
        for (String path : paths) {
            try { return MapLoader.load(path); }
            catch (Exception e) {
                System.err.println("[Setup] path falhou (" + path + "): " + e.getMessage());
            }
        }
        return null;
    }

    private BotStrategy buildStrategy(String typeLabel) {
        return switch (typeLabel) {
            case "RandomBot"   -> new RandomBot();
            case "HybridBot"   -> new HybridBot();
            case "DijkstraBot" -> new DijkstraBot();
            default            -> null;
        };
    }

    private void showError(String msg) {
        errorLabel.setText(msg);
        errorLabel.setVisible(true);
    }

    /**
     * Remove todos os elementos de uma lista da API_ED.
     * Substitui o método {@code clear()} ausente na interface {@link ListADT}.
     *
     * @param <T>  tipo dos elementos
     * @param list lista a esvaziar
     */
    private <T> void clearList(ListADT<T> list) {
        while (!list.isEmpty()) {
            try { list.removeFirst(); }
            catch (Exception ignored) {}
        }
    }

    // ── Classe interna PlayerConfigRow ────────────────────────────────────

    /**
     * Agrupa os controlos de configuração de um jogador:
     * nome, tipo e localização de entrada.
     */
    static class PlayerConfigRow {

        final int    playerIndex;
        final VBox   container;
        final TextField        nameField;
        final ComboBox<String> typeCombo;
        final ComboBox<String> startCombo;

        /**
         * Cria a row com o índice e a cor de destaque do jogador.
         *
         * @param playerIndex índice 1-based
         * @param color       código CSS hex da cor do jogador
         */
        PlayerConfigRow(int playerIndex, String color) {
            this.playerIndex = playerIndex;

            String cardStyle =
                "-fx-background-color: #2D1B0E; -fx-border-color: " + color + ";" +
                "-fx-border-width: 2; -fx-border-radius: 6; -fx-background-radius: 6;" +
                "-fx-padding: 12;";
            String inputStyle =
                "-fx-background-color: #1A0F0A; -fx-text-fill: #E8DCC8;" +
                "-fx-border-color: #5C4033; -fx-prompt-text-fill: #7a6a5a;";

            Label header = new Label("Jogador " + playerIndex);
            header.setStyle("-fx-font-weight: bold; -fx-font-size: 13;" +
                            "-fx-text-fill: " + color + ";");

            Label nameLbl  = new Label("Nome:");
            nameLbl.setStyle("-fx-text-fill: #E8DCC8;");
            nameField = new TextField();
            nameField.setPromptText("Jogador " + playerIndex);
            nameField.setStyle(inputStyle);
            nameField.setPrefWidth(160);

            Label typeLbl  = new Label("Tipo:");
            typeLbl.setStyle("-fx-text-fill: #E8DCC8;");
            typeCombo = new ComboBox<>();
            typeCombo.setStyle("-fx-background-color: #1A0F0A;");
            typeCombo.setPrefWidth(160);

            Label startLbl = new Label("Entrada:");
            startLbl.setStyle("-fx-text-fill: #E8DCC8;");
            startCombo = new ComboBox<>();
            startCombo.setStyle("-fx-background-color: #1A0F0A;");
            startCombo.setPrefWidth(160);

            container = new VBox(6, header, nameLbl, nameField,
                                 typeLbl, typeCombo,
                                 startLbl, startCombo);
            container.setStyle(cardStyle);
        }
    }
}
