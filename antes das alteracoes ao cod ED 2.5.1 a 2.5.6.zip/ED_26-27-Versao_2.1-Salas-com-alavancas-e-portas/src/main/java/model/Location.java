package model;

/**
 * Representa uma localização no mapa do jogo (vértice do Network).
 *
 * <p>{@link Location} é <b>imutável</b> por design. Estado dinâmico do jogo
 * (\"visitado\", \"enigma resolvido\") não deve ser adicionado aqui —
 * deve ser mantido externamente pelo {@code GameEngine}.</p>
 *
 * <h2>Papel da sala ({@link LocationRole})</h2>
 * <p>Cada localização tem um papel <em>estrutural</em> no mapa, definido
 * pelo campo {@code "role"} no JSON. Omitir o campo equivale a
 * {@link LocationRole#DUNGEON}.</p>
 * <ul>
 *   <li>{@link LocationRole#SPAWN}      — ponto de entrada válido</li>
 *   <li>{@link LocationRole#DUNGEON}    — sala normal de passagem</li>
 *   <li>{@link LocationRole#ENDGAME}    — sala objetivo (nunca mais de 1)</li>
 *   <li>{@link LocationRole#LEVER_ROOM} — sala de alavanca com portas</li>
 * </ul>
 *
 * <h2>Sistema de cores data-driven</h2>
 * <p>A cor visual da sala é definida <b>exclusivamente no JSON</b>
 * (campo {@code "color"}). O código Java nunca infere cor a partir
 * do {@code dangerLevel} nem do {@code biome}.
 * Isto permite criar novos mapas com temas completamente diferentes
 * apenas alterando o ficheiro JSON.</p>
 *
 * <h2>Efeito especial room5</h2>
 * <p>A única exceção visual dependente de código é o efeito de destaque
 * ativado quando {@code dangerLevel == 5}, gerido pelo renderer.
 * A cor ({@code color}) continua a vir do JSON.</p>
 *
 * <h2>Enigmas por dangerLevel</h2>
 * <p>O campo {@code enigmaId} foi <b>removido</b> das salas. A seleção do
 * enigma a apresentar é feita pela {@link engine.EnigmaPool}, que filtra
 * os enigmas com {@code dangerLevel} igual ao da sala e garante que dois
 * jogadores diferentes não respondem ao mesmo enigma na mesma sala.</p>
 *
 * <p>Para verificar se uma sala tem enigma usa-se
 * {@link #hasEnigmaByLevel()}, que devolve {@code true} sempre que
 * {@code dangerLevel >= 1} (salas de nível 0 nunca têm enigma).</p>
 *
 * <h2>Biome</h2>
 * <p>O campo opcional {@code biome} permite ao renderer selecionar uma
 * imagem de fundo específica para a sala (ex: {@code "desert"},
 * {@code "nether"}, {@code "ice_plains"}). Quando {@code null}, o renderer
 * deve usar um fundo neutro. Definido exclusivamente no JSON.</p>
 */
public class Location {

    // ── Enums públicos ─────────────────────────────────────────────────────

    /**
     * Papel <em>estrutural</em> da localização no mapa.
     *
     * <p>Definido no JSON via {@code "role": "SPAWN"} (etc.).
     * Omitir o campo equivale a {@link #DUNGEON}.</p>
     */
    public enum LocationRole {
        /** Ponto de entrada válido — onde os jogadores podem começar. */
        SPAWN,
        /** Sala intermédia normal (pode ter enigma ou não). */
        DUNGEON,
        /** Sala objetivo — quem chegar primeiro ganha. Máximo 1 por mapa. */
        ENDGAME,
        /** Sala de alavanca — o jogador deve escolher uma porta. */
        LEVER_ROOM
    }

    // ── Campos ───────────────────────────────────────────────────────────

    private final String       id;
    private final String       name;
    private final LocationRole role;
    private final int          dangerLevel;
    private final String       description;
    private final String       icon;
    private final double       mapX;
    private final double       mapY;

    /**
     * Cor hexadecimal da sala para rendering (ex: {@code "#6FCF97"}).
     * Definida no JSON — o renderer usa este valor diretamente,
     * sem mapear tipo ou nível de perigo para cor.
     */
    private final String color;

    /**
     * Biome da sala para seleção de fundo pelo renderer
     * (ex: {@code "desert"}, {@code "nether"}, {@code "ice_plains"}).
     * Definido no JSON; pode ser {@code null} quando não definido.
     */
    private final String biome;

    // ── Construtor principal ──────────────────────────────────────────────

    /**
     * Construtor único de {@link Location}.
     *
     * @param id          identificador único (ex: {@code "desert"})
     * @param name        nome de exibição
     * @param role        papel estrutural da sala; {@code null} implica {@link LocationRole#DUNGEON}
     * @param dangerLevel nível de perigo (0-5, normalizado automaticamente para o intervalo)
     * @param description descrição de lore
     * @param icon        emoji representativo
     * @param mapX        coordenada X no mapa (0.0-1.0)
     * @param mapY        coordenada Y no mapa (0.0-1.0)
     * @param color       cor hexadecimal para rendering (ex: {@code "#C0392B"}); pode ser {@code null}
     * @param biome       identificador de biome para fundo visual; pode ser {@code null}
     */
    public Location(String id, String name, LocationRole role,
                    int dangerLevel, String description, String icon,
                    double mapX, double mapY,
                    String color, String biome) {
        this.id          = id;
        this.name        = name;
        this.role        = (role != null) ? role : LocationRole.DUNGEON;
        this.dangerLevel = Math.max(0, Math.min(5, dangerLevel));
        this.description = description;
        this.icon        = icon;
        this.mapX        = mapX;
        this.mapY        = mapY;
        this.color       = color;
        this.biome       = biome;
    }

    // ── Getters ─────────────────────────────────────────────────────────

    /**
     * Identificador único da sala, correspondente ao campo {@code "id"} no JSON.
     *
     * @return identificador único
     */
    public String getId() { return id; }

    /**
     * Nome de exibição da sala.
     *
     * @return nome de exibição
     */
    public String getName() { return name; }

    /**
     * Papel estrutural da sala.
     * Nunca {@code null} — por omissão é {@link LocationRole#DUNGEON}.
     *
     * @return papel da sala
     */
    public LocationRole getRole() { return role; }

    /**
     * Nível de perigo da sala, sempre no intervalo [0, 5].
     *
     * @return nível de perigo
     */
    public int getDangerLevel() { return dangerLevel; }

    /**
     * Descrição de lore da sala.
     *
     * @return descrição
     */
    public String getDescription() { return description; }

    /**
     * Emoji representativo da sala.
     *
     * @return emoji
     */
    public String getIcon() { return icon; }

    /**
     * Coordenada X normalizada (0.0–1.0) para posicionamento no canvas.
     *
     * @return coordenada X
     */
    public double getMapX() { return mapX; }

    /**
     * Coordenada Y normalizada (0.0–1.0) para posicionamento no canvas.
     *
     * @return coordenada Y
     */
    public double getMapY() { return mapY; }

    /**
     * Cor hexadecimal para rendering, definida no JSON.
     * Exemplo: {@code "#C0392B"}.
     * O renderer deve usar este valor diretamente — nunca inferir cor
     * a partir do {@code dangerLevel} ou do {@code biome}.
     * Pode ser {@code null} se o mapa não definir o campo.
     *
     * @return cor hex, ou {@code null}
     */
    public String getColor() { return color; }

    /**
     * Identificador de biome para seleção de imagem de fundo pelo renderer.
     * Exemplos: {@code "desert"}, {@code "nether"}, {@code "ice_plains"}.
     * Pode ser {@code null} se o mapa não definir o campo — nesse caso
     * o renderer deve usar um fundo neutro.
     *
     * @return biome, ou {@code null}
     */
    public String getBiome() { return biome; }

    /**
     * Atalho: verdadeiro se {@link #getRole()} for {@link LocationRole#SPAWN}.
     *
     * @return {@code true} se for ponto de entrada
     */
    public boolean isSpawn() { return role == LocationRole.SPAWN; }

    /**
     * Atalho: verdadeiro se {@link #getRole()} for {@link LocationRole#ENDGAME}.
     *
     * @return {@code true} se for a sala objetivo
     */
    public boolean isEndgame() { return role == LocationRole.ENDGAME; }

    /**
     * Atalho: verdadeiro se {@link #getRole()} for {@link LocationRole#LEVER_ROOM}.
     *
     * @return {@code true} se for uma sala de alavanca
     */
    public boolean isLeverRoom() { return role == LocationRole.LEVER_ROOM; }

    /**
     * Indica se esta sala deve apresentar um enigma ao jogador.
     *
     * <p>Salas com {@code dangerLevel >= 1} têm sempre enigma (desde que
     * existam enigmas com esse nível no JSON). Salas de nível 0 (spawns e
     * endgame) nunca têm enigma.</p>
     *
     * @return {@code true} se a sala tem nível de perigo >= 1
     */
    public boolean hasEnigmaByLevel() { return dangerLevel >= 1; }

    /**
     * Verdadeiro se a sala tiver uma cor definida no JSON ({@code color != null}).
     *
     * @return {@code true} se a cor estiver definida
     */
    public boolean hasColor() { return color != null && !color.isBlank(); }

    // ── Utilitário ───────────────────────────────────────────────────────

    /**
     * Descrição textual do nível de perigo.
     *
     * @return label do nível de perigo
     */
    public String getDangerLabel() {
        return switch (dangerLevel) {
            case 0 -> "Seguro";
            case 1 -> "Baixo";
            case 2 -> "Médio";
            case 3 -> "Alto";
            case 4 -> "Muito Alto";
            case 5 -> "Extremo";
            default -> "Desconhecido";
        };
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Location other)) return false;
        return id.equals(other.id);
    }

    @Override
    public int hashCode() { return id.hashCode(); }

    @Override
    public String toString() {
        return String.format("%s %s [%s | Perigo: %s]",
                icon, name, role, getDangerLabel());
    }
}
