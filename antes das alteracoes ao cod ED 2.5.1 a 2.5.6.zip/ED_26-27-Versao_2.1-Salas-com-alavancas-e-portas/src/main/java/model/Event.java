package model;

/**
 * Classe-base abstrata para todos os eventos do labirinto.
 *
 * <p>Um evento é qualquer acontecimento que bloqueia ou penaliza a
 * passagem de um jogador por uma sala: enigma, alavanca ou rapto.
 * Subclasses concretas especializam o comportamento.</p>
 *
 * <h2>Hierarquia</h2>
 * <pre>
 * Event  (abstract)
 * ├── Enigma        (type == ENIGMA)
 * ├── LeverEvent (type == LEVER)
 * └── KidnapEvent   (type == KIDNAP)
 * </pre>
 *
 * @see EventType
 */
public abstract class Event {

    /** Identificador único do evento. */
    protected final String    id;

    /**
     * Nível de perigo associado ao evento (1-5).
     * Usado pelo {@link engine.EnigmaPool} para filtrar eventos por nível.
     */
    protected final int       dangerLevel;

    /** Classificação do tipo de evento. */
    protected final EventType type;

    // ── Construtor ────────────────────────────────────────────────────────

    /**
     * Inicializa os campos comuns a todos os eventos.
     *
     * @param id          identificador único
     * @param dangerLevel nível de perigo (1-5; valores fora do intervalo são normalizados)
     * @param type        tipo de evento (não pode ser {@code null})
     * @throws IllegalArgumentException se {@code type} for {@code null}
     */
    protected Event(String id, int dangerLevel, EventType type) {
        if (type == null) throw new IllegalArgumentException("EventType cannot be null");
        this.id          = id;
        this.dangerLevel = Math.max(1, Math.min(5, dangerLevel));
        this.type        = type;
    }

    // ── Getters ───────────────────────────────────────────────────────────

    /**
     * Identificador único do evento.
     *
     * @return id
     */
    public String getId() { return id; }

    /**
     * Nível de perigo do evento (1-5).
     *
     * @return dangerLevel
     */
    public int getDangerLevel() { return dangerLevel; }

    /**
     * Tipo do evento.
     *
     * @return {@link EventType}
     */
    public EventType getType() { return type; }

    // ── Contrato abstrato ─────────────────────────────────────────────────

    /**
     * Representação textual do evento (para logs e UI).
     *
     * @return string descritiva
     */
    @Override
    public abstract String toString();
}
