package model;

import Lists.ArrayUnorderedList;
import Lists.UnorderedListADT;

/**
 * Representa um enigma do jogo.
 *
 * <p>Estende {@link Event} com {@code type == EventType.ENIGMA}.
 * Mantém todos os campos originais (questão, resposta, dica, opções)
 * e a compatibilidade retroativa com os construtores {@code @Deprecated}
 * usados pelo MapLoader.</p>
 *
 * <h2>Modo múltipla escolha</h2>
 * <p>Quando o campo {@code options} é não-vazio, o enigma está em modo
 * de múltipla escolha. A resposta pode ser fornecida como:
 * <ul>
 *   <li>Letra da opção: {@code "A"}, {@code "B"}, {@code "C"}, {@code "D"}</li>
 *   <li>Índice numérico (0-based): {@code "0"} = A, {@code "1"} = B, …</li>
 *   <li>Texto completo da opção (case-insensitive)</li>
 * </ul>
 * </p>
 *
 * <h2>Modo texto livre (legado)</h2>
 * <p>Quando {@code options} está vazio, a resposta é comparada
 * como texto normalizado (trim + lowercase).</p>
 */
public class Enigma extends Event {

    private final String                  question;
    private final String                  answer;
    private final String                  hint;
    private final UnorderedListADT<String> options;

    // ── Construtores ────────────────────────────────────────────────────

    /**
     * Construtor completo com opções de múltipla escolha.
     *
     * @param id          identificador único
     * @param question    texto da pergunta
     * @param answer      resposta correcta (letra, índice ou texto completo)
     * @param hint        dica (pode ser {@code null})
     * @param dangerLevel nível de dificuldade (1–5)
     * @param options     lista de opções da API_ED; {@code null} para modo texto livre
     */
    public Enigma(String id, String question, String answer,
                  String hint, int dangerLevel, UnorderedListADT<String> options) {
        super(id, dangerLevel, EventType.ENIGMA);
        this.question = question;
        this.answer   = answer;
        this.hint     = hint;
        if (options != null) {
            this.options = options;
        } else {
            this.options = new ArrayUnorderedList<>();
        }
    }

    /**
     * Construtor legado sem opções (modo texto livre).
     *
     * @param id          identificador único
     * @param question    texto da pergunta
     * @param answer      resposta correcta
     * @param hint        dica (pode ser {@code null})
     * @param dangerLevel nível de dificuldade
     */
    public Enigma(String id, String question, String answer,
                  String hint, int dangerLevel) {
        this(id, question, answer, hint, dangerLevel, null);
    }

    // ── Getters ────────────────────────────────────────────────────────

    /** @return texto da pergunta */
    public String getQuestion()    { return question; }

    /** @return resposta correcta tal como definida no JSON */
    public String getAnswer()      { return answer; }

    /** @return dica, ou {@code null} se não definida */
    public String getHint()        { return hint; }

    /** @return {@code true} se o enigma tiver uma dica definida */
    public boolean hasHint()       { return hint != null && !hint.isBlank(); }

    /**
     * Lista de opções de múltipla escolha (API_ED).
     * Vazia se o enigma for de texto livre.
     *
     * @return lista de opções
     */
    public UnorderedListADT<String> getOptions() { return options; }

    /**
     * Indica se este enigma está em modo de múltipla escolha.
     *
     * @return {@code true} se tiver pelo menos uma opção definida
     */
    public boolean isMultipleChoice() { return !options.isEmpty(); }

    // ── Validação de resposta ──────────────────────────────────────────

    /**
     * Verifica se a resposta fornecida está correcta.
     *
     * <p>Para enigmas de múltipla escolha aceita:</p>
     * <ul>
     *   <li>Letra: {@code "A"} = opção 0, {@code "B"} = opção 1, …</li>
     *   <li>Índice numérico: {@code "0"} = opção 0, …</li>
     *   <li>Texto completo da opção (case-insensitive)</li>
     * </ul>
     * <p>Para enigmas de texto livre compara a resposta normalizada
     * (trim + lowercase).</p>
     *
     * @param given resposta fornecida pelo jogador (pode ser {@code null})
     * @return {@code true} se a resposta estiver correcta
     */
    public boolean isCorrect(String given) {
        if (given == null) return false;
        String givenNorm  = given.trim().toLowerCase();
        String answerNorm = answer.trim().toLowerCase();

        if (isMultipleChoice()) {
            int correctIdx = resolveOptionIndex(answerNorm);
            int givenIdx   = resolveOptionIndex(givenNorm);
            if (correctIdx >= 0 && givenIdx >= 0) {
                return correctIdx == givenIdx;
            }
            return answerNorm.equals(givenNorm);
        }

        return answerNorm.equals(givenNorm);
    }

    /**
     * Resolve uma string para um índice de opção (0-based).
     * Percorre a lista de opções da API_ED com um iterador.
     *
     * @param s string a resolver (já em lowercase/trim)
     * @return índice (0–N-1), ou -1 se não resolvível
     */
    private int resolveOptionIndex(String s) {
        int size = options.size();

        // Letra: "a"→0, "b"→1, "c"→2, "d"→3, "e"→4
        if (s.length() == 1 && s.charAt(0) >= 'a' && s.charAt(0) <= 'e') {
            int idx = s.charAt(0) - 'a';
            return idx < size ? idx : -1;
        }
        // Índice numérico
        try {
            int idx = Integer.parseInt(s);
            return (idx >= 0 && idx < size) ? idx : -1;
        } catch (NumberFormatException ignored) {}
        // Texto completo — percorre com iterador
        int i = 0;
        for (String opt : options) {
            if (opt.trim().toLowerCase().equals(s)) return i;
            i++;
        }
        return -1;
    }

    /**
     * Devolve a opção pelo seu índice (0-based).
     *
     * @param index índice da opção
     * @return texto da opção
     * @throws IndexOutOfBoundsException se o índice for inválido
     */
    public String getOption(int index) {
        int i = 0;
        for (String opt : options) {
            if (i == index) return opt;
            i++;
        }
        throw new IndexOutOfBoundsException("Índice de opção inválido: " + index);
    }

    @Override
    public String toString() {
        return String.format("Enigma[%s | nivel=%d | mc=%b]",
                id, dangerLevel, isMultipleChoice());
    }
}
