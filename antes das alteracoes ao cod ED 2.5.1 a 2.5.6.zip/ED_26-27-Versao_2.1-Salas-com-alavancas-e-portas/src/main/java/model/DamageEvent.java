package model;

/**
 * Evento de dano direto — aplica dano ao jogador sem qualquer interação.
 *
 * <p>Ao contrário de {@link LeverEvent} (que exige resposta a um enigma)
 * ou de {@link KidnapEvent} (que teleporta o jogador), {@code DamageEvent}
 * não requer input do jogador: o {@link engine.GameEngine} aplica o dano
 * imediatamente ao processar a porta errada em
 * {@link engine.GameEngine#resolveLeverDoor}.</p>
 *
 * <h2>Hierarquia</h2>
 * <pre>
 * Event  (abstract)
 * ├── Enigma        (type == ENIGMA)
 * ├── LeverEvent    (type == LEVER)
 * ├── KidnapEvent   (type == KIDNAP)
 * └── DamageEvent   (type == DAMAGE)
 * </pre>
 *
 * @see EventType#DAMAGE
 * @see engine.GameEngine
 */
public class DamageEvent extends Event {

    /**
     * Cria um evento de dano direto.
     *
     * @param id          identificador único do evento
     * @param dangerLevel nível de perigo associado (1-5); determina o dano
     *                    base calculado pelo engine
     */
    public DamageEvent(String id, int dangerLevel) {
        super(id, dangerLevel, EventType.DAMAGE);
    }

    /**
     * Representação textual do evento para logs e UI.
     *
     * @return string descritiva com id e dangerLevel
     */
    @Override
    public String toString() {
        return String.format("DamageEvent[id=%s | dangerLevel=%d]", id, dangerLevel);
    }
}
