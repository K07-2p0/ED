package model;

/**
 * Evento de alavanca no labirinto.
 *
 * <p>Uma alavanca protege um conjunto de portas. O jogador deve adivinhar
 * a posição correcta para abrir as portas. Se errar, o evento fica
 * {@code resolved = false} e o jogador terá de tentar novamente numa
 * visita posterior.</p>
 *
 * <h2>Regras de resolução</h2>
 * <ul>
 *   <li>A alavanca tem {@code doorCount} portas associadas.</li>
 *   <li>Está resolvida quando {@link #isResolved()} devolver {@code true}.
 *       Pode ser marcada resolvida com {@link #resolve()}.</li>
 *   <li>O campo {@code type} é sempre {@link EventType#LEVER}.</li>
 * </ul>
 */
public class LeverEvent extends Event {

    /** Número de portas controladas por esta alavanca. */
    private final int     doorCount;

    /** {@code true} se o jogador já resolveu a alavanca correctamente. */
    private       boolean resolved;

    // ── Construtor ────────────────────────────────────────────────────────

    /**
     * Cria um evento de alavanca.
     *
     * @param id          identificador único
     * @param dangerLevel nível de perigo (1-5)
     * @param doorCount   número de portas controladas (mínimo 1)
     */
    public LeverEvent(String id, int dangerLevel, int doorCount) {
        super(id, dangerLevel, EventType.LEVER);
        this.doorCount = Math.max(1, doorCount);
        this.resolved = false;
    }

    // ── Getters / Setters ─────────────────────────────────────────────────

    /**
     * Número de portas controladas por esta alavanca.
     *
     * @return número de portas
     */
    public int getDoorCount() { return doorCount; }

    /**
     * Indica se o jogador já resolveu a alavanca.
     *
     * @return {@code true} se resolvida
     */
    public boolean isResolved() { return resolved; }

    /**
     * Marca a alavanca como resolvida (portas abertas).
     */
    public void resolve() { this.resolved = true; }

    /**
     * Repõe o estado para não-resolvido (usado no respawn do jogador).
     */
    public void reset() { this.resolved = false; }

    @Override
    public String toString() {
        return String.format("LeverEvent[%s | nivel=%d | portas=%d | resolvido=%b]",
                id, dangerLevel, doorCount, resolved);
    }
}
