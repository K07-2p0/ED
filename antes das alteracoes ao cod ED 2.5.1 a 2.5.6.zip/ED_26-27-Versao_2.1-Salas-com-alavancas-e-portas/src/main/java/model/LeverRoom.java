package model;

import Lists.DoublyLinkedList;
import engine.SimpleRandom;

/**
 * Sala de alavanca — apresenta ao jogador um conjunto de portas,
 * das quais apenas uma é correcta.
 *
 * <p>O número de portas é determinado pelo {@code dangerLevel} da sala,
 * conforme definido em {@code event_config.json}:</p>
 * <ul>
 *   <li>dangerLevel 2 → 2 portas</li>
 *   <li>dangerLevel 3 → 3 portas</li>
 *   <li>dangerLevel 4 → 4 portas</li>
 *   <li>dangerLevel 5 → 4 portas</li>
 *   <li>outro valor   → 2 portas (fallback seguro)</li>
 * </ul>
 *
 * <h2>Eventos de portas erradas</h2>
 * <p>Cada porta errada recebe um dos três eventos com distribuição
 * aproximadamente igual (~33% cada):</p>
 * <ul>
 *   <li>{@link LeverEvent}  — exige resposta a enigma antes de resolver</li>
 *   <li>{@link KidnapEvent} — teletransporte forçado</li>
 *   <li>{@link DamageEvent} — dano direto, sem interação</li>
 * </ul>
 *
 * <h2>Terceira porta em salas de nível 3+</h2>
 * <p>Quando {@code dangerLevel >= 3} e existem 3 ou mais portas, a
 * terceira porta (índice 2) apresenta um enigma antes de resolver.
 * Resposta correcta → o jogador avança; resposta errada → dano e
 * recuo N passos (N = dangerLevel).</p>
 *
 * <h2>Recursão em HARDCORE</h2>
 * <p>Numa sala com {@code dangerLevel == 4} em profundidade raiz, uma das
 * portas erradas pode abrir uma nova {@link LeverRoom} cujo número de
 * portas também é determinado por {@link #getDoorCount(int)}
 * (máximo 1 nível de recursão).</p>
 *
 * @see Door
 * @see engine.GameEngine
 */
public class LeverRoom {

    /** A localização (sala) a que esta lever room está associada. */
    private final Location location;

    /** Lista de portas disponíveis (API_ED). */
    private final DoublyLinkedList<Door> doors;

    /**
     * Se uma porta errada abrir uma sub-lever-room, fica aqui guardada.
     * {@code null} se não houver recursão.
     */
    private final LeverRoom nestedRoom;

    /**
     * ID da porta que abre a sub-lever-room aninhada, ou {@code null}
     * se não existir sub-lever-room. Permite ao {@link engine.GameEngine}
     * detectar a porta aninhada de forma precisa, sem recorrer a
     * heurísticas baseadas em prefixos ou dangerLevel.
     */
    private final String nestedDoorId;

    // ── Construtor ────────────────────────────────────────────────────

    /**
     * Cria uma lever room com as portas já geradas.
     *
     * @param location     a sala do mapa
     * @param doors        lista de portas
     * @param nestedRoom   sub-lever-room (pode ser {@code null})
     * @param nestedDoorId ID da porta que abre a sub-lever-room, ou
     *                     {@code null} se não existir sub-lever-room
     */
    public LeverRoom(Location location, DoublyLinkedList<Door> doors,
                     LeverRoom nestedRoom, String nestedDoorId) {
        this.location     = location;
        this.doors        = doors;
        this.nestedRoom   = nestedRoom;
        this.nestedDoorId = nestedDoorId;
    }

    // ── Getters ──────────────────────────────────────────────────────────

    /** @return a localização associada */
    public Location getLocation() { return location; }

    /** @return lista de portas */
    public DoublyLinkedList<Door> getDoors() { return doors; }

    /** @return sub-lever-room, ou {@code null} */
    public LeverRoom getNestedRoom() { return nestedRoom; }

    /** @return {@code true} se existe uma sub-lever-room recursiva */
    public boolean hasNestedRoom() { return nestedRoom != null; }

    /**
     * Devolve o ID da porta que abre a sub-lever-room aninhada.
     *
     * <p>Usado pelo {@link engine.GameEngine} para detectar de forma
     * exacta qual a porta que leva à sub-lever-room, evitando
     * heurísticas baseadas em prefixos de ID ou dangerLevel.</p>
     *
     * @return ID da porta aninhada, ou {@code null} se não existir
     */
    public String getNestedDoorId() { return nestedDoorId; }

    /**
     * Procura uma porta pelo seu identificador.
     *
     * @param doorId id da porta
     * @return a porta, ou {@code null} se não encontrada
     */
    public Door findDoor(String doorId) {
        for (Door d : doors) {
            if (d.getId().equals(doorId)) return d;
        }
        return null;
    }

    // ── Factory method ──────────────────────────────────────────────────

    /**
     * Gera uma {@link LeverRoom} com o número de portas determinado pelo
     * {@code dangerLevel} da sala (conforme {@code event_config.json}).
     *
     * <p>A dificuldade deixa de controlar o número de portas. A terceira
     * porta em salas com {@code dangerLevel >= 3} apresenta um enigma
     * antes de resolver.</p>
     *
     * <p>Portas erradas recebem eventos aleatórios com distribuição
     * aproximadamente igual: ~33% {@link LeverEvent},
     * ~33% {@link KidnapEvent}, ~33% {@link DamageEvent}.</p>
     *
     * <p>Em {@code dangerLevel == 4} (profundidade raiz), uma porta
     * errada abre uma sub-lever-room (máximo 1 nível de recursão).</p>
     *
     * @param loc        a sala do mapa
     * @param map        mapa do jogo (para obter vizinhos como destino)
     * @param rng        gerador aleatório
     * @return lever room gerada
     */
    public static LeverRoom generate(Location loc, GameMap map, SimpleRandom rng) {
        return generate(loc, map, rng, 0);
    }

    /**
     * Implementação recursiva com controlo de profundidade.
     *
     * @param loc   a sala do mapa
     * @param map   mapa do jogo
     * @param rng   gerador aleatório
     * @param depth profundidade actual de recursão (0 = raiz)
     * @return lever room gerada
     */
    private static LeverRoom generate(Location loc, GameMap map, SimpleRandom rng,
                                       int depth) {
        int dangerLevel  = loc.getDangerLevel();
        int numDoors     = getDoorCount(dangerLevel);
        int correctIndex = rng.nextInt(numDoors);

        // Obter vizinhos para usar como destinos das portas
        DoublyLinkedList<Location> neighbors = new DoublyLinkedList<>();
        for (Location n : map.getNeighbors(loc)) {
            neighbors.addLast(n);
        }
        if (neighbors.isEmpty()) {
            neighbors.addLast(loc);
        }

        // Baralhar vizinhos para que os destinos das portas sejam aleatórios.
        // O int[]/Location[] é uma estrutura algorítmica temporária, não uma
        // coleção de dados do jogo — o seu uso é permitido pelas regras do projeto.
        int nSize = neighbors.size();
        if (nSize > 1) {
            Location[] tempArr = new Location[nSize];
            int ti = 0;
            for (Location n : neighbors) {
                tempArr[ti++] = n;
            }
            for (int fi = nSize - 1; fi > 0; fi--) {
                int fj = rng.nextInt(fi + 1);
                Location tmp = tempArr[fi];
                tempArr[fi] = tempArr[fj];
                tempArr[fj] = tmp;
            }
            neighbors = new DoublyLinkedList<>();
            for (int fi = 0; fi < nSize; fi++) {
                neighbors.addLast(tempArr[fi]);
            }
        }

        DoublyLinkedList<Door> doors = new DoublyLinkedList<>();
        LeverRoom nestedRoom   = null;
        String    nestedDoorId = null;
        boolean   nestedCreated = false;

        for (int i = 0; i < numDoors; i++) {
            String   doorId = "door_" + loc.getId() + "_" + i;
            Location dest   = pickByIndex(neighbors, i % neighbors.size());

            if (i == correctIndex) {
                // Porta correcta — sem evento
                doors.addLast(new Door(doorId, null, true, dest));

            } else if (!nestedCreated && depth == 0 && dangerLevel == 4) {
                // Porta errada em sala dangerLevel 4 (profundidade raiz):
                // abre uma sub-lever-room.
                LeverRoom nested = generate(loc, map, rng, depth + 1);
                nestedRoom    = nested;
                nestedDoorId  = doorId;
                nestedCreated = true;
                LeverEvent nestedEvent = new LeverEvent(
                        "lever_nested_" + loc.getId(), dangerLevel, 0);
                doors.addLast(new Door(doorId, nestedEvent, false, dest));

            } else if (dangerLevel >= 3 && i == 2) {
                // Terceira porta (índice 2) em salas dangerLevel >= 3:
                // exige enigma antes de resolver.
                LeverEvent enigmaDoorEvent = new LeverEvent(
                        "lever_enigma_door_" + loc.getId(), dangerLevel, dangerLevel);
                doors.addLast(new Door(doorId, enigmaDoorEvent, false, dest));

            } else {
                // Porta errada normal — distribuição ~33/33/33
                Event event = generateRandomEvent(loc, rng);
                doors.addLast(new Door(doorId, event, false, dest));
            }
        }

        return new LeverRoom(loc, doors, nestedRoom, nestedDoorId);
    }

    // ── Helpers privados ───────────────────────────────────────────────────────────

    /**
     * Número de portas determinado pelo {@code dangerLevel} da sala,
     * conforme os valores definidos em {@code event_config.json}.
     *
     * <ul>
     *   <li>dangerLevel 2 → 2 portas</li>
     *   <li>dangerLevel 3 → 3 portas</li>
     *   <li>dangerLevel 4 → 4 portas</li>
     *   <li>dangerLevel 5 → 4 portas</li>
     *   <li>outro valor   → 2 portas (fallback seguro)</li>
     * </ul>
     *
     * @param dangerLevel nível de perigo da sala
     * @return número de portas (2–4)
     */
    private static int getDoorCount(int dangerLevel) {
        return switch (dangerLevel) {
            case 2 -> 2;
            case 3 -> 3;
            case 4 -> 4;
            case 5 -> 4;
            default -> 2;
        };
    }

    /**
     * Gera um evento aleatório para uma porta errada, com distribuição
     * aproximadamente igual entre os três tipos possíveis:
     *
     * <ul>
     *   <li>roll ∈ [0.00, 0.33) → {@link LeverEvent}  (~33%)</li>
     *   <li>roll ∈ [0.33, 0.66) → {@link KidnapEvent} (~33%)</li>
     *   <li>roll ∈ [0.66, 1.00) → {@link DamageEvent} (~33%)</li>
     * </ul>
     *
     * @param loc sala cujo dangerLevel é usado no evento gerado
     * @param rng gerador aleatório
     * @return evento gerado ({@link LeverEvent}, {@link KidnapEvent} ou
     *         {@link DamageEvent})
     */
    private static Event generateRandomEvent(Location loc, SimpleRandom rng) {
        double roll = rng.nextDouble();
        int    dl   = loc.getDangerLevel();
        int    uid  = rng.nextInt(10000);

        if (roll < 0.33) {
            // ~33% — Alavanca: stepsBack = dangerLevel da sala
            return new LeverEvent(
                    "lever_" + loc.getId() + "_" + uid, dl, dl);
        } else if (roll < 0.66) {
            // ~33% — Rapto
            return new KidnapEvent(
                    "kidnap_" + loc.getId() + "_" + uid, dl);
        } else {
            // ~33% — Dano direto
            return new DamageEvent(
                    "damage_" + loc.getId() + "_" + uid, dl);
        }
    }

    /**
     * Seleciona um elemento de uma lista pelo índice (iteração linear).
     *
     * @param <T>   tipo dos elementos
     * @param list  lista
     * @param index índice (0-based)
     * @return elemento no índice
     */
    private static <T> T pickByIndex(DoublyLinkedList<T> list, int index) {
        int i = 0;
        for (T item : list) {
            if (i == index) return item;
            i++;
        }
        return null;
    }

    @Override
    public String toString() {
        return String.format("LeverRoom[%s | %d doors | nested=%b]",
                location.getId(), doors.size(), nestedRoom != null);
    }
}
