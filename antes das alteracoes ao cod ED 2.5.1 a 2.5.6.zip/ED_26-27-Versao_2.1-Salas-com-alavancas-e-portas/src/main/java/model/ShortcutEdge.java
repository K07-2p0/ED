package model;

/**
 * Representa uma aresta de atalho entre duas localizações no mapa.
 *
 * <p>Os atalhos são gerados automaticamente pelo {@link io.MapLoader}
 * após o carregamento do mapa, ligando salas de {@code dangerLevel == 2}
 * às salas de {@code dangerLevel == 4} mais próximas.</p>
 *
 * <p>Apenas metade dos atalhos são visíveis para o jogador — a
 * visibilidade é determinada aleatoriamente com base numa seed
 * configurável.</p>
 *
 * <p>Um atalho pode, opcionalmente, transportar um {@link Event} que é
 * acionado quando um jogador o atravessa. Se {@code event} for
 * {@code null}, a passagem pelo atalho não desencadeia qualquer
 * acontecimento especial.</p>
 *
 * @see io.MapLoader
 */
public class ShortcutEdge {

    /** Identificador único do atalho. */
    private final String id;

    /** Localização de origem do atalho. */
    private final Location from;

    /** Localização de destino do atalho. */
    private final Location to;

    /**
     * {@code true} se o atalho é visível para o jogador na UI.
     * Atalhos invisíveis existem mas não são mostrados no mapa.
     */
    private final boolean visible;

    /**
     * Evento associado a este atalho, ou {@code null} se não houver evento.
     * Quando não é {@code null}, o evento é acionado ao atravessar o atalho.
     */
    private final Event event;

    // ── Construtores ──────────────────────────────────────────────────────

    /**
     * Cria uma aresta de atalho com um evento associado.
     *
     * @param id      identificador único do atalho
     * @param from    localização de origem
     * @param to      localização de destino
     * @param visible {@code true} se visível para o jogador
     * @param event   evento acionado ao atravessar o atalho,
     *                ou {@code null} se não houver evento
     */
    public ShortcutEdge(String id, Location from, Location to, boolean visible, Event event) {
        this.id      = id;
        this.from    = from;
        this.to      = to;
        this.visible = visible;
        this.event   = event;
    }

    /**
     * Cria uma aresta de atalho sem evento associado.
     *
     * <p>Equivalente a {@code new ShortcutEdge(id, from, to, visible, null)}.</p>
     *
     * @param id      identificador único do atalho
     * @param from    localização de origem
     * @param to      localização de destino
     * @param visible {@code true} se visível para o jogador
     */
    public ShortcutEdge(String id, Location from, Location to, boolean visible) {
        this(id, from, to, visible, null);
    }

    // ── Getters ──────────────────────────────────────────────────────────

    /** @return identificador único do atalho */
    public String getId() { return id; }

    /** @return localização de origem */
    public Location getFrom() { return from; }

    /** @return localização de destino */
    public Location getTo() { return to; }

    /** @return {@code true} se visível para o jogador */
    public boolean isVisible() { return visible; }

    /**
     * Evento associado a este atalho.
     *
     * @return evento acionado ao atravessar o atalho,
     *         ou {@code null} se não houver evento
     */
    public Event getEvent() { return event; }

    // ── Object ───────────────────────────────────────────────────────────

    @Override
    public String toString() {
        String eventPart = (event != null)
                ? " | event=" + event.getType()
                : "";
        return String.format("Shortcut[%s: %s → %s | visible=%b%s]",
                id, from.getId(), to.getId(), visible, eventPart);
    }
}
