package model;

/**
 * Evento de rapto no labirinto.
 *
 * <p>Quando um jogador entra numa sala com um evento de rapto, é
 * teletransportado para uma localização aleatória (ou definida pelo
 * engine). O comportamento concreto do rapto é da responsabilidade do
 * {@code GameEngine} — este evento limita-se a sinalizar que o rapto
 * deve ocorrer.</p>
 *
 * <p>O campo {@code type} é sempre {@link EventType#KIDNAP}.
 * Não tem campos extra para já; campos adicionais (ex: destino fixo)
 * podem ser acrescentados sem quebrar retrocompatibilidade.</p>
 */
public class KidnapEvent extends Event {

    // ── Construtor ────────────────────────────────────────────────────────

    /**
     * Cria um evento de rapto.
     *
     * @param id          identificador único
     * @param dangerLevel nível de perigo (1-5)
     */
    public KidnapEvent(String id, int dangerLevel) {
        super(id, dangerLevel, EventType.KIDNAP);
    }

    @Override
    public String toString() {
        return String.format("KidnapEvent[%s | nivel=%d]", id, dangerLevel);
    }
}
