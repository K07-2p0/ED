package model;

/**
 * Representa uma porta dentro de uma {@link LeverRoom}.
 *
 * <p>Cada porta tem um identificador, um evento opcional associado,
 * uma flag que indica se é a porta correcta e um destino.</p>
 *
 * <ul>
 *   <li>A porta correcta tem {@code event == null} e {@code isCorrect == true}</li>
 *   <li>Portas erradas têm um {@link LeverEvent} ou {@link KidnapEvent}
 *       que é activado quando o jogador a escolhe</li>
 * </ul>
 *
 * @see LeverRoom
 */
public class Door {

    /** Identificador único da porta (ex: "door_1"). */
    private final String   id;

    /**
     * Evento que ocorre ao entrar por esta porta.
     * {@code null} se for a porta correcta.
     */
    private final Event   event;

    /** {@code true} se esta for a porta correcta. */
    private final boolean  isCorrect;

    /** Localização de destino ao abrir esta porta. */
    private final Location destination;

    // ── Construtor ────────────────────────────────────────────────────────

    /**
     * Cria uma porta.
     *
     * @param id          identificador único
     * @param event       evento associado ({@code null} se correcta)
     * @param isCorrect   {@code true} se for a porta correcta
     * @param destination localização de destino
     */
    public Door(String id, Event event, boolean isCorrect, Location destination) {
        this.id          = id;
        this.event       = event;
        this.isCorrect   = isCorrect;
        this.destination = destination;
    }

    // ── Getters ──────────────────────────────────────────────────────────

    /** @return identificador único da porta */
    public String getId() { return id; }

    /**
     * Evento que ocorre ao escolher esta porta.
     *
     * @return evento, ou {@code null} se for a porta correcta
     */
    public Event getEvent() { return event; }

    /** @return {@code true} se for a porta correcta */
    public boolean isCorrect() { return isCorrect; }

    /** @return localização de destino */
    public Location getDestination() { return destination; }

    /** @return {@code true} se tiver um evento associado */
    public boolean hasEvent() { return event != null; }

    @Override
    public String toString() {
        return String.format("Door[%s | correct=%b | event=%s | dest=%s]",
                id, isCorrect,
                event != null ? event.getType() : "none",
                destination != null ? destination.getId() : "null");
    }
}
