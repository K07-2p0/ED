package model;

/**
 * Classifica o tipo de evento que pode ocorrer numa sala do labirinto.
 *
 * <ul>
 *   <li>{@link #ENIGMA} — pergunta com resposta certa/errada</li>
 *   <li>{@link #LEVER}  — alavanca com portas a desbloquear</li>
 *   <li>{@link #KIDNAP} — jogador é raptado/teletransportado</li>
 *   <li>{@link #DAMAGE} — dano direto sem interação necessária</li>
 * </ul>
 */
public enum EventType {
    /** Evento de enigma: pergunta e resposta. */
    ENIGMA,
    /** Evento de alavanca: abre/fecha portas. */
    LEVER,
    /** Evento de rapto: teletransporte forçado. */
    KIDNAP,
    /** Evento de dano direto: sem interação, aplica dano imediatamente. */
    DAMAGE
}
