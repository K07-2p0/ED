package model;

import Graphs.Network;
import Exceptions.EmptyCollectionException;
import Lists.DoublyLinkedList;
import Lists.ListADT;
import org.json.JSONArray;
import java.util.Iterator;

/**
 * Mapa do jogo — grafo ponderado de {@link Location} construído
 * dinamicamente pelo {@link io.MapLoader} a partir de um ficheiro JSON.
 *
 * <p>Nenhuma estrutura nativa do Java (java.util) é usada nesta classe.
 * Todas as coleções são da API_ED.</p>
 *
 * <h2>Convenção de caminhos impossíveis</h2>
 * <p>{@link #shortestPathCost(Location, Location)} devolve
 * {@link Double#POSITIVE_INFINITY} quando não existe caminho entre dois
 * vértices. <b>O {@code GameEngine} deve sempre verificar
 * {@code Double.isInfinite(cost)} antes de permitir qualquer movimento.</b>
 * Exemplo de uso correto:</p>
 * <pre>
 *   double cost = map.shortestPathCost(origin, destination);
 *   if (Double.isInfinite(cost)) {
 *       // caminho impossível — não mover o jogador
 *   }
 * </pre>
 *
 * <h2>Estado externo por localização</h2>
 * <p>{@link Location} é imutável por design. Estado dinâmico do jogo
 * ("esta localização já foi visitada", "enigma já resolvido") deve ser
 * mantido externamente pelo {@code GameEngine} num mapa de estado indexado
 * pelo {@link Location#getId()}. Nunca adicionar estado mutável a
 * {@link Location}.</p>
 *
 * <h2>Biome types</h2>
 * <p>O campo opcional {@code biomeTypes} é preenchido pelo
 * {@link io.MapLoader} quando o JSON de mapa define o array
 * {@code "biome_types"}. O renderer usa este campo para saber quais
 * fundos visuais estão disponíveis; se {@code null}, usa fundo neutro.</p>
 *
 * <p>Ciclo de vida típico:</p>
 * <pre>
 *   GameMap map = MapLoader.load("maps/map_default.json");
 * </pre>
 */
public class GameMap {

    /** Grafo ponderado que representa o mapa. */
    private final Network<Location> network;

    /**
     * Lista interna de localizações na ordem de inserção.
     * Evita depender de {@code getVertices()} que não existe na API_ED.
     */
    private final DoublyLinkedList<Location> locationList;

    /**
     * Array opcional de biomes definidos no JSON do mapa
     * (campo {@code "biome_types"}).
     * {@code null} quando o mapa não define biomes.
     */
    private JSONArray biomeTypes;

    // ── Construtor ──────────────────────────────────────────────────

    /**
     * Cria um mapa vazio. Os dados devem ser carregados pelo
     * {@link io.MapLoader#load(String, GameMap)}.
     */
    public GameMap() {
        this.network      = new Network<>();
        this.locationList = new DoublyLinkedList<>();
        this.biomeTypes   = null;
    }

    // ── Construção do mapa (chamada pelo MapLoader) ────────────────────

    /**
     * Adiciona uma localização ao grafo e à lista interna.
     * Chamado pelo {@link io.MapLoader} durante o carregamento do JSON.
     *
     * @param loc localização a adicionar
     * @throws IllegalArgumentException se já existir uma localização
     *         com o mesmo {@link Location#getId()}
     */
    public void addLocation(Location loc) {
        for (Location existing : locationList) {
            if (existing.getId().equals(loc.getId())) {
                throw new IllegalArgumentException(
                    "ID duplicado no mapa: '" + loc.getId() + "'. " +
                    "Cada localização deve ter um id único.");
            }
        }
        network.addVertex(loc);
        locationList.addLast(loc);
    }

    /**
     * Adiciona uma aresta bidirecional ponderada entre duas localizações.
     * Chamado pelo {@link io.MapLoader} durante o carregamento do JSON.
     *
     * @param a      primeira localização
     * @param b      segunda localização
     * @param weight custo/distância da ligação (deve ser positivo)
     */
    public void addEdge(Location a, Location b, double weight) {
        network.addEdge(a, b, weight);
    }

    // ── Biome types ────────────────────────────────────────────────

    /**
     * Devolve o array de biomes definidos no JSON do mapa, ou
     * {@code null} se o mapa não definir o campo {@code "biome_types"}.
     *
     * @return {@link JSONArray} de biomes, ou {@code null}
     */
    public JSONArray getBiomeTypes() { return biomeTypes; }

    /**
     * Define os biome types do mapa.
     * Chamado pelo {@link io.MapLoader} quando o JSON inclui
     * o campo {@code "biome_types"}.
     *
     * @param biomeTypes array de identificadores de biome
     */
    public void setBiomeTypes(JSONArray biomeTypes) { this.biomeTypes = biomeTypes; }

    // ── API pública ─────────────────────────────────────────────────────

    /**
     * Retorna o caminho mais curto entre duas localizações (Dijkstra).
     *
     * @param from localização de origem
     * @param to   localização de destino
     * @return {@link ListADT} com as localizações da rota; lista vazia se
     *         não existir caminho
     */
    public ListADT<Location> shortestPath(Location from, Location to) {
        try {
            return iteratorToList(network.iteratorShortestPath(from, to));
        } catch (EmptyCollectionException e) {
            return new DoublyLinkedList<>();
        }
    }

    /**
     * Custo total do caminho mais curto entre duas localizações.
     *
     * <p><b>Convenção:</b> devolve {@link Double#POSITIVE_INFINITY} quando
     * não existe caminho. O chamador deve sempre verificar
     * {@code Double.isInfinite(cost)} antes de usar o resultado.</p>
     *
     * @param from localização de origem
     * @param to   localização de destino
     * @return soma dos pesos do caminho mínimo, ou
     *         {@link Double#POSITIVE_INFINITY} se não existir caminho
     */
    public double shortestPathCost(Location from, Location to) {
        return network.shortestPathWeight(from, to);
    }

    /**
     * Indica se existe caminho entre duas localizações.
     * Atalho para {@code !Double.isInfinite(shortestPathCost(from, to))}.
     *
     * @param from localização de origem
     * @param to   localização de destino
     * @return {@code true} se existir pelo menos um caminho
     */
    public boolean hasPath(Location from, Location to) {
        return !Double.isInfinite(shortestPathCost(from, to));
    }

    /**
     * Retorna os vizinhos diretos de uma localização.
     *
     * @param location localização de origem
     * @return {@link ListADT} com as localizações vizinhas
     */
    public ListADT<Location> getNeighbors(Location location) {
        return network.getNeighbors(location);
    }

    /**
     * Verifica se existe aresta direta entre duas localizações.
     *
     * <p>Implementado via {@link Network#getEdgeWeight(Object, Object)}:
     * usa diretamente a matriz de adjacência do grafo (O(1) após lookup
     * de índice), evitando a criação de uma nova {@link DoublyLinkedList}
     * de vizinhos a cada chamada — o que acontecia na implementação
     * anterior baseada em {@code getNeighbors()}.</p>
     *
     * @param a primeira localização
     * @param b segunda localização
     * @return {@code true} se forem adjacentes (aresta direta)
     */
    public boolean areConnected(Location a, Location b) {
        try {
            network.getEdgeWeight(a, b);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    /**
     * Peso da aresta direta entre duas localizações vizinhas.
     *
     * @param a primeira localização
     * @param b segunda localização
     * @return peso, ou {@link Double#POSITIVE_INFINITY} se não forem vizinhos
     */
    public double getDistance(Location a, Location b) {
        try {
            return network.getEdgeWeight(a, b);
        } catch (IllegalArgumentException e) {
            return Double.POSITIVE_INFINITY;
        }
    }

    /**
     * Retorna todas as localizações do mapa na ordem de inserção.
     *
     * @return {@link ListADT} com todas as {@link Location}
     */
    public ListADT<Location> getAllLocations() {
        return locationList;
    }

    /**
     * Travessia BFS a partir de uma localização.
     *
     * @param start localização inicial
     * @return {@link ListADT} na ordem BFS
     */
    public ListADT<Location> bfsFrom(Location start) {
        try {
            return iteratorToList(network.iteratorBFS(start));
        } catch (EmptyCollectionException e) {
            return new DoublyLinkedList<>();
        }
    }

    /**
     * Travessia DFS a partir de uma localização.
     *
     * @param start localização inicial
     * @return {@link ListADT} na ordem DFS
     */
    public ListADT<Location> dfsFrom(Location start) {
        try {
            return iteratorToList(network.iteratorDFS(start));
        } catch (EmptyCollectionException e) {
            return new DoublyLinkedList<>();
        }
    }

    /**
     * Verifica se o mapa é totalmente conexo.
     * Todos os vértices devem ser alcançáveis a partir de qualquer outro.
     *
     * @return {@code true} se o grafo for conexo
     */
    public boolean isFullyConnected() {
        try {
            return network.isConnected();
        } catch (EmptyCollectionException e) {
            return false;
        }
    }

    /**
     * Devolve a {@link Location} com o identificador dado.
     *
     * <p><b>Custo:</b> O(n) por pesquisa linear. Chamado durante o
     * carregamento do mapa ({@code parseEdges}) e pontualmente pela UI.
     * Sem impacto prático para mapas com dezenas de nós.</p>
     *
     * @param id identificador único da localização
     * @return a localização correspondente
     * @throws IllegalArgumentException se nenhuma localização tiver esse id
     */
    public Location getById(String id) {
        for (Location loc : locationList) {
            if (loc.getId().equals(id)) return loc;
        }
        throw new IllegalArgumentException("Localização não encontrada: '" + id + "'");
    }

    /**
     * Número de localizações no mapa.
     *
     * @return contagem de vértices
     */
    public int size() {
        return locationList.size();
    }

    /**
     * Indica se o mapa não tem nenhuma localização.
     *
     * @return {@code true} se o mapa estiver vazio
     */
    public boolean isEmpty() {
        return locationList.isEmpty();
    }

    /**
     * Expõe o {@link Network} subjacente para uso na camada de UI (JavaFX).
     *
     * @return o grafo ponderado do mapa
     */
    public Network<Location> getNetwork() { return network; }

    // ── Utilitário ─────────────────────────────────────────────────────

    /**
     * Converte um {@link Iterator} numa {@link DoublyLinkedList} da API_ED.
     *
     * @param <E>      tipo dos elementos
     * @param iterator iterador a converter
     * @return lista com todos os elementos do iterador
     */
    private <E> DoublyLinkedList<E> iteratorToList(Iterator<E> iterator) {
        DoublyLinkedList<E> list = new DoublyLinkedList<>();
        while (iterator.hasNext()) {
            list.addLast(iterator.next());
        }
        return list;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(
            "GameMap [" + locationList.size() + " localizações | conexo: "
            + isFullyConnected() + "]\n");
        for (Location loc : locationList) {
            sb.append("  ").append(loc.getName()).append(" → ");
            ListADT<Location> neighbors = getNeighbors(loc);
            boolean first = true;
            for (Location n : neighbors) {
                if (!first) sb.append(", ");
                sb.append(n.getName())
                  .append("(").append(getDistance(loc, n)).append(")");
                first = false;
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}
