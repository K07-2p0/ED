package model;

import Exceptions.ElementNotFoundException;
import Exceptions.EmptyCollectionException;
import Queues_Stacks.LinkedStack;
import Lists.DoublyLinkedList;

/**
 * Representa um jogador (humano ou bot) no Labirinto da Glória.
 *
 * <p>O historial de movimento usa uma {@link LinkedStack}{@code <Location>}
 * da API_ED, permitindo backtrack via {@code pop()} em O(1).
 * O inventário usa {@link DoublyLinkedList}{@code <String>} para
 * inserção e remoção eficiente em ambas as extremidades.</p>
 *
 * <p>{@link Player} é <b>mutável</b> — o {@code GameEngine} altera
 * {@link #currentLocation} e {@link #health} durante o jogo.</p>
 *
 * <h2>Dois históricos distintos</h2>
 * <ul>
 *   <li>{@link #movementHistory} ({@link LinkedStack}) — regista apenas
 *       o caminho do ciclo de vida atual (desde o último spawn). É limpo
 *       no respawn para que {@link #goBack()} não permita sair do spawn
 *       imediatamente sem custo.</li>
 *   <li>{@link #fullPathHistory} ({@link DoublyLinkedList}) — registo
 *       <b>permanente e completo</b> de todas as localizações visitadas,
 *       incluindo ciclos de vida anteriores e eventos de respawn.
 *       <b>Nunca é limpo.</b> Usado exclusivamente para o relatório final.</li>
 * </ul>
 *
 * <h2>Morte e Respawn</h2>
 * <p>Quando a vida do jogador atinge 0 (ver {@link #isDead()}), o engine
 * chama {@link #respawn()} para o repor na sala de spawn com HP máximo.
 * O jogador <b>não</b> é eliminado — a morte é uma penalização com
 * regresso ao ponto de partida.</p>
 */
public class Player {

    /** Saúde máxima de um jogador. */
    public static final int MAX_HEALTH = 100;

    /** Saúde mínima (morte). */
    public static final int MIN_HEALTH = 0;

    private final String  id;
    private final String  name;
    private final boolean isBot;

    private int      health;
    private Location currentLocation;

    /**
     * Sala de spawn — localização onde o jogador começa o jogo e para
     * onde regressa após cada morte. Imutável após construção.
     */
    private final Location spawnLocation;

    /**
     * Historial de navegação do ciclo de vida atual (desde o último spawn).
     *
     * <p>Usado por {@link #goBack()} para backtrack em O(1).<br>
     * <b>É limpo no respawn</b> — impede que o jogador use goBack() para
     * sair do spawn sem custo após uma morte.</p>
     *
     * <p>Não deve ser usado para o relatório final — usar
     * {@link #fullPathHistory} para esse efeito.</p>
     */
    private final LinkedStack<Location> movementHistory;

    /**
     * Historial completo e permanente de todas as localizações visitadas.
     *
     * <p>Regista <b>cada {@link #moveTo(Location)}</b>, cada
     * {@link #goBack()} e cada {@link #respawn()},
     * incluindo os ciclos de vida anteriores à morte.
     * <b>Nunca é limpo</b> — é o único historial que deve ser usado
     * para gerar o relatório final da partida.</p>
     *
     * <p>Entradas especiais inseridas automaticamente:</p>
     * <ul>
     *   <li>{@code null} — marca o ponto de morte/respawn; o relatório
     *       pode usar {@code null} como separador de "vida"</li>
     * </ul>
     */
    private final DoublyLinkedList<Location> fullPathHistory;

    /** Inventário de itens. */
    private final DoublyLinkedList<String> inventory;

    /** Número de turnos extra acumulados por eventos de corredor. */
    private int bonusTurns;

    // ── Construtor ──────────────────────────────────────────────────────────

    /**
     * Cria um jogador na localização inicial com saúde máxima.
     *
     * @param id            identificador único
     * @param name          nome de exibição
     * @param isBot         {@code true} se for controlado por bot
     * @param startLocation localização inicial (também usada como spawn)
     */
    public Player(String id, String name, boolean isBot, Location startLocation) {
        this.id              = id;
        this.name            = name;
        this.isBot           = isBot;
        this.health          = MAX_HEALTH;
        this.currentLocation = startLocation;
        // A sala de spawn é fixada na construção e nunca muda.
        this.spawnLocation   = startLocation;
        this.movementHistory = new LinkedStack<>();
        this.fullPathHistory = new DoublyLinkedList<>();
        this.inventory       = new DoublyLinkedList<>();
        this.bonusTurns      = 0;
        // Regista a posição inicial em ambos os históricos.
        movementHistory.push(startLocation);
        fullPathHistory.addLast(startLocation);
    }

    // ── Movimento ───────────────────────────────────────────────────────────

    /**
     * Move o jogador para uma nova localização, registando em ambos os
     * históricos.
     *
     * @param location nova localização
     */
    public void moveTo(Location location) {
        this.currentLocation = location;
        // Historial navegável do ciclo atual (para goBack)
        movementHistory.push(location);
        // Historial completo permanente (para relatório)
        fullPathHistory.addLast(location);
    }

    /**
     * Recua o jogador para a localização anterior (backtrack).
     *
     * <p>Remove o topo do {@link #movementHistory} e regista o recuo
     * no {@link #fullPathHistory} para que o relatório mostre que o
     * jogador voltou atrás.</p>
     *
     * @return {@code true} se o backtrack foi bem-sucedido
     */
    public boolean goBack() {
        if (movementHistory.size() <= 1) return false;
        try {
            movementHistory.pop();
            currentLocation = movementHistory.peek();
            // Regista o recuo no historial completo (a sala destino do recuo)
            fullPathHistory.addLast(currentLocation);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ── Saúde e Respawn ────────────────────────────────────────────────────

    /**
     * Aplica dano ao jogador.
     *
     * @param amount quantidade de dano (positivo)
     */
    public void takeDamage(int amount) {
        health = Math.max(MIN_HEALTH, health - Math.abs(amount));
    }

    /**
     * Cura o jogador.
     *
     * @param amount quantidade de cura (positivo)
     */
    public void heal(int amount) {
        health = Math.min(MAX_HEALTH, health + Math.abs(amount));
    }

    /** @return {@code true} se a saúde chegou a zero */
    public boolean isDead() { return health <= MIN_HEALTH; }

    /**
     * Repõe o jogador no estado de respawn:
     * <ol>
     *   <li>HP restaurado ao máximo ({@value #MAX_HEALTH})</li>
     *   <li>Posição reposta na sala de spawn</li>
     *   <li>{@link #movementHistory} limpo e reiniciado com o spawn
     *       (impede goBack() de sair do spawn sem custo)</li>
     *   <li>{@link #fullPathHistory} <b>preservado</b> — o evento de
     *       respawn é marcado com {@code null} seguido do spawn, para
     *       que o relatório mostre claramente a separação entre vidas</li>
     * </ol>
     */
    public void respawn() {
        // Repõe HP ao máximo
        health = MAX_HEALTH;
        // Volta à sala de spawn
        currentLocation = spawnLocation;

        // Limpa o historial navegável (ciclo atual) — impede goBack() barato
        try {
            while (movementHistory.size() > 0) movementHistory.pop();
        } catch (Exception ignored) {}
        movementHistory.push(spawnLocation);

        // Regista o evento de morte/respawn no historial COMPLETO:
        //   null  → separador de "morte" para o relatório
        //   spawn → nova posição após respawn
        fullPathHistory.addLast(null);
        fullPathHistory.addLast(spawnLocation);
    }

    // ── Inventário ──────────────────────────────────────────────────────────

    /**
     * Adiciona um item ao inventário.
     *
     * @param item nome do item
     */
    public void addItem(String item) { inventory.addLast(item); }

    /**
     * Remove a primeira ocorrência de um item do inventário.
     * Delega em {@link DoublyLinkedList#remove(Object)}, que já remove
     * a primeira ocorrência em O(n) e lança
     * {@link Exceptions.ElementNotFoundException} se não existir.
     *
     * @param item nome do item a remover
     * @return {@code true} se o item existia e foi removido
     */
    public boolean removeItem(String item) {
        try {
            inventory.remove(item);
            return true;
        } catch (ElementNotFoundException | EmptyCollectionException e) {
            return false;
        }
    }

    /** @return {@code true} se o inventário contém o item */
    public boolean hasItem(String item) { return inventory.contains(item); }

    // ── Turnos extra ────────────────────────────────────────────────────────

    /**
     * Adiciona turnos extra (evento de corredor).
     *
     * @param turns número de turnos a adicionar
     */
    public void addBonusTurns(int turns) { bonusTurns += turns; }

    /**
     * Consome um turno extra, se disponível.
     *
     * @return {@code true} se havia turnos extra e foi consumido um
     */
    public boolean consumeBonusTurn() {
        if (bonusTurns <= 0) return false;
        bonusTurns--;
        return true;
    }

    // ── Getters ─────────────────────────────────────────────────────────────

    /** @return identificador único do jogador */
    public String getId() { return id; }

    /** @return nome de exibição */
    public String getName() { return name; }

    /** @return {@code true} se for controlado por bot */
    public boolean isBot() { return isBot; }

    /** @return saúde atual (0-100) */
    public int getHealth() { return health; }

    /** @return localização atual */
    public Location getCurrentLocation() { return currentLocation; }

    /**
     * Sala de spawn do jogador — onde começa e para onde regressa após
     * cada morte. Nunca muda ao longo do jogo.
     *
     * @return localização de spawn
     */
    public Location getSpawnLocation() { return spawnLocation; }

    /**
     * Historial navegável do ciclo de vida atual (desde o último spawn).
     * Usado por {@link #goBack()} — <b>não usar para o relatório final</b>.
     *
     * @return LinkedStack com o caminho atual
     * @see #getFullPathHistory()
     */
    public LinkedStack<Location> getMovementHistory() { return movementHistory; }

    /**
     * Historial completo e permanente de todas as localizações visitadas
     * ao longo de toda a partida, incluindo os ciclos de vida anteriores.
     *
     * <p>Entradas {@code null} marcam os pontos de morte/respawn.</p>
     *
     * <p><b>Este é o historial a usar para gerar o relatório final.</b></p>
     *
     * @return DoublyLinkedList com o caminho completo
     */
    public DoublyLinkedList<Location> getFullPathHistory() { return fullPathHistory; }

    /** @return inventário (API_ED DoublyLinkedList) */
    public DoublyLinkedList<String> getInventory() { return inventory; }

    /** @return turnos extra disponíveis */
    public int getBonusTurns() { return bonusTurns; }

    @Override
    public String toString() {
        return String.format("[%s] %s | ❤ %d | 📍 %s%s",
            isBot ? "BOT" : "HUM",
            name, health,
            currentLocation.getName(),
            bonusTurns > 0 ? " | +" + bonusTurns + " turnos" : "");
    }
}
