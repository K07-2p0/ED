# Requirements — Labirinto da Glória

## System Requirements

| Requirement    | Version        |
|----------------|----------------|
| Java (OpenJDK) | 21+            |
| Apache Maven   | 3.9.16         |
| JavaFX         | 21.0.3         |

## Local Libraries (included in `lib/`)

| Library              | Version  | Description                              |
|----------------------|----------|------------------------------------------|
| `API_ED.jar`         | 1.0      | Data Structures API (provided by course) |
| `json-20251224.jar`  | 20251224 | JSON parsing (org.json)                  |

## Test Dependencies (auto-downloaded by Maven)

| Library        | Version |
|----------------|---------|
| JUnit Jupiter  | 5.11.4  |

---

## Installation

### macOS

```bash
# Install Homebrew (if not already installed)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Add Homebrew to PATH (Apple Silicon M1/M2/M3/M4)
echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zshrc
source ~/.zshrc

# Install Java 21 and Maven
brew install openjdk@21
brew install maven

# Configure Java 21
echo 'export JAVA_HOME=$(/usr/libexec/java_home -v 21)' >> ~/.zshrc
echo 'export PATH="$JAVA_HOME/bin:$PATH"' >> ~/.zshrc
source ~/.zshrc

# Verify installation
java -version
mvn -version
```

### Linux (Debian/Ubuntu)

> ⚠️ The version of Maven available via `apt` may be outdated. If `mvn -version` shows a version older than 3.9.x, install manually from [maven.apache.org](https://maven.apache.org/download.cgi).

```bash
# Update package list
sudo apt update

# Install Java 21 and Maven
sudo apt install -y openjdk-21-jdk maven

# Verify installation
java -version
mvn -version
```

### Windows

> Open **PowerShell as Administrator** (right-click Start Menu → "Windows PowerShell (Admin)")

```powershell
# 1. Install Chocolatey (package manager)
Set-ExecutionPolicy Bypass -Scope Process -Force
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))

# 2. Verify Chocolatey
choco -v

# 3. Install OpenJDK 21
choco install openjdk21 -y

# 4. Install Apache Maven 3.9.16
choco install maven --version=3.9.16 -y

# 5. Reload environment variables (no restart needed)
$env:Path = [System.Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [System.Environment]::GetEnvironmentVariable('Path','User')

# 6. Verify installation
java -version
mvn -version
```

Alternatively, download and install manually:
- [Java 21 (OpenJDK)](https://adoptium.net/)
- [Apache Maven 3.9.16](https://maven.apache.org/download.cgi)

---

## Running the Project

```bash
mvn javafx:run                  # Launch the application
mvn compile                     # Compile only
mvn clean package -DskipTests   # Build fat JAR
# Output: target/labirinto-gloria-1.0-SNAPSHOT-shaded.jar
```