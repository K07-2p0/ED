package core.game;

import Lists.ListADT;
import Queues_Stacks.QueueADT;
import Exceptions.EmptyCollectionException;
import core.model.ator.Jogador;
import core.model.ator.JogadorHumano;
import core.model.divisao.Divisao;
import core.model.divisao.SalaAlavanca;
import core.model.divisao.SalaEnigma;
import core.model.divisao.SalaTesouro;
import core.model.itens.Corredor;
import java.util.Scanner;
import java.util.Random; // Necessário para a probabilidade

public class TurnProcessor {

    private final GestorMapa gestorMapa;
    private final QueueADT<Jogador> filaDeTurnos;
    private final PlayerInteraction interaction;
    private boolean isRunning;
    private final Random random = new Random(); // Para o sorteio do desabamento

    public TurnProcessor(GestorMapa gestorMapa, QueueADT<Jogador> filaDeTurnos, PlayerInteraction interaction) {
        this.gestorMapa = gestorMapa;
        this.filaDeTurnos = filaDeTurnos;
        this.interaction = interaction;
        this.isRunning = true;
    }

    public boolean isRunning() { return isRunning; }
    public void stopGame() { this.isRunning = false; }
    public void reset() { this.isRunning = true; while(!filaDeTurnos.isEmpty()){ try{filaDeTurnos.dequeue();}catch(Exception e){} } }

    private void limparEcra() { System.out.println("\n\n"); }

    public void processarTurno(Scanner scanner) {
        if (filaDeTurnos.isEmpty()) { System.out.println("Ninguém na fila."); return; }
        Jogador jogadorAtual;
        try { jogadorAtual = filaDeTurnos.dequeue(); } catch (EmptyCollectionException e) { return; }

        limparEcra();
        System.out.println(">>> TURNO: " + jogadorAtual.getNome());
        System.out.println("Local: " + jogadorAtual.getPosicaoAtual().getNome());

        if (jogadorAtual instanceof JogadorHumano) {
            System.out.println("ENTER para jogar...");
            String in = scanner.nextLine();
            if(in.equalsIgnoreCase("menu")) if(interaction.exibirMenuJogador(jogadorAtual, scanner)) { stopGame(); return; }
        }

        if (!jogadorAtual.tentarJogar()) {
            filaDeTurnos.enqueue(jogadorAtual);
            return;
        }

        if (jogadorAtual instanceof JogadorHumano) interaction.tratarEfeitosAcumulados(jogadorAtual, scanner);

        Divisao divisaoAtual = jogadorAtual.getPosicaoAtual();
        if (!divisaoAtual.processarEntrada(jogadorAtual)) {
            // Lógica de falha na sala atual (Enigmas/Alavancas)
            boolean recuperou = false;
            if (jogadorAtual instanceof JogadorHumano) {
                if (divisaoAtual instanceof SalaEnigma) recuperou = interaction.processarSalaEnigmaHumano((SalaEnigma)divisaoAtual, jogadorAtual, scanner);
                else if (divisaoAtual instanceof SalaAlavanca) recuperou = interaction.processarSalaAlavancaHumano((SalaAlavanca)divisaoAtual, jogadorAtual, scanner);
            }
            if (!recuperou) {
                filaDeTurnos.enqueue(jogadorAtual);
                System.out.println("Turno perdido. Enter.");
                if(jogadorAtual instanceof JogadorHumano) scanner.nextLine();
                return;
            }
        }
        
        // Movimento
        ListADT<Divisao> vizinhos = gestorMapa.obterVizinhos(divisaoAtual);
        Divisao destino = interaction.escolherDestino(jogadorAtual, vizinhos, scanner);
        
        if (destino != null) {
            Corredor corredor = gestorMapa.getCorredor(divisaoAtual, destino);
            if (corredor != null && corredor.atravessar(jogadorAtual)) {
                
                jogadorAtual.getPosicaoAtual().setJogadorAtual(null); 
                boolean entrou = destino.processarEntrada(jogadorAtual);
                
                // Fallback interação humano na nova sala
                if (!entrou && jogadorAtual instanceof JogadorHumano) {
                     if (destino instanceof SalaEnigma) entrou = interaction.processarSalaEnigmaHumano((SalaEnigma)destino, jogadorAtual, scanner);
                     else if (destino instanceof SalaAlavanca) entrou = interaction.processarSalaAlavancaHumano((SalaAlavanca)destino, jogadorAtual, scanner);
                }

                if (entrou) {
                    jogadorAtual.setPosicaoAtual(destino);
                    
                    // --- [ALTERAÇÃO: MANIPULAÇÃO DINÂMICA DO GRAFO] ---
                    // 30% de hipótese de o corredor desabar atrás do jogador
                    if (random.nextDouble() < 0.3) {
                        System.out.println("\n!!! ESTRONDO !!! O chão treme...");
                        gestorMapa.destruirCorredorEntre(divisaoAtual, destino);
                    }
                    // --------------------------------------------------

                    if (destino instanceof SalaTesouro) {
                        interaction.processarVitoria(jogadorAtual, scanner);
                        stopGame(); return;
                    }
                } else {
                    System.out.println("Não conseguiu entrar, recua.");
                }
            }
        }

        interaction.aplicarEfeitosNegativosPendentes(jogadorAtual);
        filaDeTurnos.enqueue(jogadorAtual);
        
        if(jogadorAtual instanceof JogadorHumano) {
            System.out.println("Fim do turno. Enter.");
            scanner.nextLine();
        }
    }
}